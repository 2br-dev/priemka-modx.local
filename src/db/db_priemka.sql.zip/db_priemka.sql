-- phpMyAdmin SQL Dump
-- version 5.1.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 08, 2026 at 11:13 AM
-- Server version: 5.7.24
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_priemka`
--

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_actiondom`
--

CREATE TABLE `modx_access_actiondom` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_category`
--

CREATE TABLE `modx_access_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_context`
--

CREATE TABLE `modx_access_context` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_access_context`
--

INSERT INTO `modx_access_context` (`id`, `target`, `principal_class`, `principal`, `authority`, `policy`) VALUES
(1, 'web', 'MODX\\Revolution\\modUserGroup', 0, 9999, 3),
(2, 'mgr', 'MODX\\Revolution\\modUserGroup', 1, 0, 2),
(3, 'web', 'MODX\\Revolution\\modUserGroup', 1, 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_elements`
--

CREATE TABLE `modx_access_elements` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_media_source`
--

CREATE TABLE `modx_access_media_source` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_menus`
--

CREATE TABLE `modx_access_menus` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_namespace`
--

CREATE TABLE `modx_access_namespace` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_permissions`
--

CREATE TABLE `modx_access_permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `template` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `value` tinyint(1) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_access_permissions`
--

INSERT INTO `modx_access_permissions` (`id`, `template`, `name`, `description`, `value`) VALUES
(1, 1, 'about', 'perm.about_desc', 1),
(2, 1, 'access_permissions', 'perm.access_permissions_desc', 1),
(3, 1, 'actions', 'perm.actions_desc', 1),
(4, 1, 'change_password', 'perm.change_password_desc', 1),
(5, 1, 'change_profile', 'perm.change_profile_desc', 1),
(6, 1, 'charsets', 'perm.charsets_desc', 1),
(7, 1, 'class_map', 'perm.class_map_desc', 1),
(8, 1, 'components', 'perm.components_desc', 1),
(9, 1, 'content_types', 'perm.content_types_desc', 1),
(10, 1, 'countries', 'perm.countries_desc', 1),
(11, 1, 'create', 'perm.create_desc', 1),
(12, 1, 'credits', 'perm.credits_desc', 1),
(13, 1, 'customize_forms', 'perm.customize_forms_desc', 1),
(14, 1, 'dashboards', 'perm.dashboards_desc', 1),
(15, 1, 'database', 'perm.database_desc', 1),
(16, 1, 'database_truncate', 'perm.database_truncate_desc', 1),
(17, 1, 'delete_category', 'perm.delete_category_desc', 1),
(18, 1, 'delete_chunk', 'perm.delete_chunk_desc', 1),
(19, 1, 'delete_context', 'perm.delete_context_desc', 1),
(20, 1, 'delete_document', 'perm.delete_document_desc', 1),
(21, 1, 'delete_weblink', 'perm.delete_weblink_desc', 1),
(22, 1, 'delete_symlink', 'perm.delete_symlink_desc', 1),
(23, 1, 'delete_static_resource', 'perm.delete_static_resource_desc', 1),
(24, 1, 'delete_eventlog', 'perm.delete_eventlog_desc', 1),
(25, 1, 'delete_plugin', 'perm.delete_plugin_desc', 1),
(26, 1, 'delete_propertyset', 'perm.delete_propertyset_desc', 1),
(27, 1, 'delete_snippet', 'perm.delete_snippet_desc', 1),
(28, 1, 'delete_template', 'perm.delete_template_desc', 1),
(29, 1, 'delete_tv', 'perm.delete_tv_desc', 1),
(30, 1, 'delete_role', 'perm.delete_role_desc', 1),
(31, 1, 'delete_user', 'perm.delete_user_desc', 1),
(32, 1, 'directory_chmod', 'perm.directory_chmod_desc', 1),
(33, 1, 'directory_create', 'perm.directory_create_desc', 1),
(34, 1, 'directory_list', 'perm.directory_list_desc', 1),
(35, 1, 'directory_remove', 'perm.directory_remove_desc', 1),
(36, 1, 'directory_update', 'perm.directory_update_desc', 1),
(37, 1, 'edit_category', 'perm.edit_category_desc', 1),
(38, 1, 'edit_chunk', 'perm.edit_chunk_desc', 1),
(39, 1, 'edit_context', 'perm.edit_context_desc', 1),
(40, 1, 'edit_document', 'perm.edit_document_desc', 1),
(41, 1, 'edit_weblink', 'perm.edit_weblink_desc', 1),
(42, 1, 'edit_symlink', 'perm.edit_symlink_desc', 1),
(43, 1, 'edit_static_resource', 'perm.edit_static_resource_desc', 1),
(44, 1, 'edit_locked', 'perm.edit_locked_desc', 1),
(45, 1, 'edit_plugin', 'perm.edit_plugin_desc', 1),
(46, 1, 'edit_propertyset', 'perm.edit_propertyset_desc', 1),
(47, 1, 'edit_role', 'perm.edit_role_desc', 1),
(48, 1, 'edit_snippet', 'perm.edit_snippet_desc', 1),
(49, 1, 'edit_template', 'perm.edit_template_desc', 1),
(50, 1, 'edit_tv', 'perm.edit_tv_desc', 1),
(51, 1, 'edit_user', 'perm.edit_user_desc', 1),
(52, 1, 'element_tree', 'perm.element_tree_desc', 1),
(53, 1, 'empty_cache', 'perm.empty_cache_desc', 1),
(54, 1, 'error_log_erase', 'perm.error_log_erase_desc', 1),
(55, 1, 'error_log_view', 'perm.error_log_view_desc', 1),
(56, 1, 'export_static', 'perm.export_static_desc', 1),
(57, 1, 'file_create', 'perm.file_create_desc', 1),
(58, 1, 'file_list', 'perm.file_list_desc', 1),
(59, 1, 'file_manager', 'perm.file_manager_desc', 1),
(60, 1, 'file_remove', 'perm.file_remove_desc', 1),
(61, 1, 'file_tree', 'perm.file_tree_desc', 1),
(62, 1, 'file_update', 'perm.file_update_desc', 1),
(63, 1, 'file_upload', 'perm.file_upload_desc', 1),
(64, 1, 'file_unpack', 'perm.file_unpack_desc', 1),
(65, 1, 'file_view', 'perm.file_view_desc', 1),
(66, 1, 'flush_sessions', 'perm.flush_sessions_desc', 1),
(67, 1, 'frames', 'perm.frames_desc', 1),
(68, 1, 'help', 'perm.help_desc', 1),
(69, 1, 'home', 'perm.home_desc', 1),
(70, 1, 'language', 'perm.language_desc', 1),
(71, 1, 'languages', 'perm.languages_desc', 1),
(72, 1, 'lexicons', 'perm.lexicons_desc', 1),
(73, 1, 'list', 'perm.list_desc', 1),
(74, 1, 'load', 'perm.load_desc', 1),
(75, 1, 'logout', 'perm.logout_desc', 1),
(76, 1, 'mgr_log_view', 'perm.mgr_log_view_desc', 1),
(77, 1, 'mgr_log_erase', 'perm.mgr_log_erase_desc', 1),
(78, 1, 'menu_reports', 'perm.menu_reports_desc', 1),
(79, 1, 'menu_security', 'perm.menu_security_desc', 1),
(80, 1, 'menu_site', 'perm.menu_site_desc', 1),
(81, 1, 'menu_support', 'perm.menu_support_desc', 1),
(82, 1, 'menu_system', 'perm.menu_system_desc', 1),
(83, 1, 'menu_tools', 'perm.menu_tools_desc', 1),
(84, 1, 'menu_trash', 'perm.menu_trash_desc', 1),
(85, 1, 'menu_user', 'perm.menu_user_desc', 1),
(86, 1, 'menus', 'perm.menus_desc', 1),
(87, 1, 'messages', 'perm.messages_desc', 1),
(88, 1, 'namespaces', 'perm.namespaces_desc', 1),
(89, 1, 'new_category', 'perm.new_category_desc', 1),
(90, 1, 'new_chunk', 'perm.new_chunk_desc', 1),
(91, 1, 'new_context', 'perm.new_context_desc', 1),
(92, 1, 'new_document', 'perm.new_document_desc', 1),
(93, 1, 'new_static_resource', 'perm.new_static_resource_desc', 1),
(94, 1, 'new_symlink', 'perm.new_symlink_desc', 1),
(95, 1, 'new_weblink', 'perm.new_weblink_desc', 1),
(96, 1, 'new_document_in_root', 'perm.new_document_in_root_desc', 1),
(97, 1, 'new_plugin', 'perm.new_plugin_desc', 1),
(98, 1, 'new_propertyset', 'perm.new_propertyset_desc', 1),
(99, 1, 'new_role', 'perm.new_role_desc', 1),
(100, 1, 'new_snippet', 'perm.new_snippet_desc', 1),
(101, 1, 'new_template', 'perm.new_template_desc', 1),
(102, 1, 'new_tv', 'perm.new_tv_desc', 1),
(103, 1, 'new_user', 'perm.new_user_desc', 1),
(104, 1, 'packages', 'perm.packages_desc', 1),
(105, 1, 'policy_delete', 'perm.policy_delete_desc', 1),
(106, 1, 'policy_edit', 'perm.policy_edit_desc', 1),
(107, 1, 'policy_new', 'perm.policy_new_desc', 1),
(108, 1, 'policy_save', 'perm.policy_save_desc', 1),
(109, 1, 'policy_view', 'perm.policy_view_desc', 1),
(110, 1, 'policy_template_delete', 'perm.policy_template_delete_desc', 1),
(111, 1, 'policy_template_edit', 'perm.policy_template_edit_desc', 1),
(112, 1, 'policy_template_new', 'perm.policy_template_new_desc', 1),
(113, 1, 'policy_template_save', 'perm.policy_template_save_desc', 1),
(114, 1, 'policy_template_view', 'perm.policy_template_view_desc', 1),
(115, 1, 'property_sets', 'perm.property_sets_desc', 1),
(116, 1, 'providers', 'perm.providers_desc', 1),
(117, 1, 'publish_document', 'perm.publish_document_desc', 1),
(118, 1, 'purge_deleted', 'perm.purge_deleted_desc', 1),
(119, 1, 'remove', 'perm.remove_desc', 1),
(120, 1, 'remove_locks', 'perm.remove_locks_desc', 1),
(121, 1, 'resource_duplicate', 'perm.resource_duplicate_desc', 1),
(122, 1, 'resourcegroup_delete', 'perm.resourcegroup_delete_desc', 1),
(123, 1, 'resourcegroup_edit', 'perm.resourcegroup_edit_desc', 1),
(124, 1, 'resourcegroup_new', 'perm.resourcegroup_new_desc', 1),
(125, 1, 'resourcegroup_resource_edit', 'perm.resourcegroup_resource_edit_desc', 1),
(126, 1, 'resourcegroup_resource_list', 'perm.resourcegroup_resource_list_desc', 1),
(127, 1, 'resourcegroup_save', 'perm.resourcegroup_save_desc', 1),
(128, 1, 'resourcegroup_view', 'perm.resourcegroup_view_desc', 1),
(129, 1, 'resource_quick_create', 'perm.resource_quick_create_desc', 1),
(130, 1, 'resource_quick_update', 'perm.resource_quick_update_desc', 1),
(131, 1, 'resource_tree', 'perm.resource_tree_desc', 1),
(132, 1, 'save', 'perm.save_desc', 1),
(133, 1, 'save_category', 'perm.save_category_desc', 1),
(134, 1, 'save_chunk', 'perm.save_chunk_desc', 1),
(135, 1, 'save_context', 'perm.save_context_desc', 1),
(136, 1, 'save_document', 'perm.save_document_desc', 1),
(137, 1, 'save_plugin', 'perm.save_plugin_desc', 1),
(138, 1, 'save_propertyset', 'perm.save_propertyset_desc', 1),
(139, 1, 'save_role', 'perm.save_role_desc', 1),
(140, 1, 'save_snippet', 'perm.save_snippet_desc', 1),
(141, 1, 'save_template', 'perm.save_template_desc', 1),
(142, 1, 'save_tv', 'perm.save_tv_desc', 1),
(143, 1, 'save_user', 'perm.save_user_desc', 1),
(144, 1, 'search', 'perm.search_desc', 1),
(145, 1, 'set_sudo', 'perm.set_sudo_desc', 1),
(146, 1, 'settings', 'perm.settings_desc', 1),
(147, 1, 'events', 'perm.events_desc', 1),
(148, 1, 'source_save', 'perm.source_save_desc', 1),
(149, 1, 'source_delete', 'perm.source_delete_desc', 1),
(150, 1, 'source_edit', 'perm.source_edit_desc', 1),
(151, 1, 'source_view', 'perm.source_view_desc', 1),
(152, 1, 'sources', 'perm.sources_desc', 1),
(153, 1, 'steal_locks', 'perm.steal_locks_desc', 1),
(154, 1, 'tree_show_element_ids', 'perm.tree_show_element_ids_desc', 1),
(155, 1, 'tree_show_resource_ids', 'perm.tree_show_resource_ids_desc', 1),
(156, 1, 'undelete_document', 'perm.undelete_document_desc', 1),
(157, 1, 'unpublish_document', 'perm.unpublish_document_desc', 1),
(158, 1, 'unlock_element_properties', 'perm.unlock_element_properties_desc', 1),
(159, 1, 'usergroup_delete', 'perm.usergroup_delete_desc', 1),
(160, 1, 'usergroup_edit', 'perm.usergroup_edit_desc', 1),
(161, 1, 'usergroup_new', 'perm.usergroup_new_desc', 1),
(162, 1, 'usergroup_save', 'perm.usergroup_save_desc', 1),
(163, 1, 'usergroup_user_edit', 'perm.usergroup_user_edit_desc', 1),
(164, 1, 'usergroup_user_list', 'perm.usergroup_user_list_desc', 1),
(165, 1, 'usergroup_view', 'perm.usergroup_view_desc', 1),
(166, 1, 'view', 'perm.view_desc', 1),
(167, 1, 'view_category', 'perm.view_category_desc', 1),
(168, 1, 'view_chunk', 'perm.view_chunk_desc', 1),
(169, 1, 'view_context', 'perm.view_context_desc', 1),
(170, 1, 'view_document', 'perm.view_document_desc', 1),
(171, 1, 'view_element', 'perm.view_element_desc', 1),
(172, 1, 'view_eventlog', 'perm.view_eventlog_desc', 1),
(173, 1, 'view_offline', 'perm.view_offline_desc', 1),
(174, 1, 'view_plugin', 'perm.view_plugin_desc', 1),
(175, 1, 'view_propertyset', 'perm.view_propertyset_desc', 1),
(176, 1, 'view_role', 'perm.view_role_desc', 1),
(177, 1, 'view_snippet', 'perm.view_snippet_desc', 1),
(178, 1, 'view_sysinfo', 'perm.view_sysinfo_desc', 1),
(179, 1, 'view_template', 'perm.view_template_desc', 1),
(180, 1, 'view_tv', 'perm.view_tv_desc', 1),
(181, 1, 'view_user', 'perm.view_user_desc', 1),
(182, 1, 'view_unpublished', 'perm.view_unpublished_desc', 1),
(183, 1, 'workspaces', 'perm.workspaces_desc', 1),
(184, 2, 'add_children', 'perm.add_children_desc', 1),
(185, 2, 'copy', 'perm.copy_desc', 1),
(186, 2, 'create', 'perm.create_desc', 1),
(187, 2, 'delete', 'perm.delete_desc', 1),
(188, 2, 'list', 'perm.list_desc', 1),
(189, 2, 'load', 'perm.load_desc', 1),
(190, 2, 'move', 'perm.move_desc', 1),
(191, 2, 'publish', 'perm.publish_desc', 1),
(192, 2, 'remove', 'perm.remove_desc', 1),
(193, 2, 'save', 'perm.save_desc', 1),
(194, 2, 'steal_lock', 'perm.steal_lock_desc', 1),
(195, 2, 'undelete', 'perm.undelete_desc', 1),
(196, 2, 'unpublish', 'perm.unpublish_desc', 1),
(197, 2, 'view', 'perm.view_desc', 1),
(198, 3, 'load', 'perm.load_desc', 1),
(199, 3, 'list', 'perm.list_desc', 1),
(200, 3, 'view', 'perm.view_desc', 1),
(201, 3, 'save', 'perm.save_desc', 1),
(202, 3, 'remove', 'perm.remove_desc', 1),
(203, 4, 'add_children', 'perm.add_children_desc', 1),
(204, 4, 'create', 'perm.create_desc', 1),
(205, 4, 'copy', 'perm.copy_desc', 1),
(206, 4, 'delete', 'perm.delete_desc', 1),
(207, 4, 'list', 'perm.list_desc', 1),
(208, 4, 'load', 'perm.load_desc', 1),
(209, 4, 'remove', 'perm.remove_desc', 1),
(210, 4, 'save', 'perm.save_desc', 1),
(211, 4, 'view', 'perm.view_desc', 1),
(212, 5, 'create', 'perm.create_desc', 1),
(213, 5, 'copy', 'perm.copy_desc', 1),
(214, 5, 'list', 'perm.list_desc', 1),
(215, 5, 'load', 'perm.load_desc', 1),
(216, 5, 'remove', 'perm.remove_desc', 1),
(217, 5, 'save', 'perm.save_desc', 1),
(218, 5, 'view', 'perm.view_desc', 1),
(219, 6, 'load', 'perm.load_desc', 1),
(220, 6, 'list', 'perm.list_desc', 1),
(221, 6, 'view', 'perm.view_desc', 1),
(222, 6, 'save', 'perm.save_desc', 1),
(223, 6, 'remove', 'perm.remove_desc', 1),
(224, 6, 'view_unpublished', 'perm.view_unpublished_desc', 1),
(225, 6, 'copy', 'perm.copy_desc', 1),
(226, 7, 'list', 'perm.list_desc', 1),
(227, 7, 'load', 'perm.load_desc', 1),
(228, 7, 'view', 'perm.view_desc', 1);

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_policies`
--

CREATE TABLE `modx_access_policies` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` mediumtext,
  `parent` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `template` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `class` varchar(191) NOT NULL DEFAULT '',
  `data` text,
  `lexicon` varchar(255) NOT NULL DEFAULT 'permissions'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_access_policies`
--

INSERT INTO `modx_access_policies` (`id`, `name`, `description`, `parent`, `template`, `class`, `data`, `lexicon`) VALUES
(1, 'Resource', 'policy_resource_desc', 0, 2, '', '{\"add_children\":true,\"create\":true,\"copy\":true,\"delete\":true,\"list\":true,\"load\":true,\"move\":true,\"publish\":true,\"remove\":true,\"save\":true,\"steal_lock\":true,\"undelete\":true,\"unpublish\":true,\"view\":true}', 'permissions'),
(2, 'Administrator', 'policy_administrator_desc', 0, 1, '', '{\"about\":true,\"access_permissions\":true,\"actions\":true,\"change_password\":true,\"change_profile\":true,\"charsets\":true,\"class_map\":true,\"components\":true,\"content_types\":true,\"countries\":true,\"create\":true,\"credits\":true,\"customize_forms\":true,\"dashboards\":true,\"database\":true,\"database_truncate\":true,\"delete_category\":true,\"delete_chunk\":true,\"delete_context\":true,\"delete_document\":true,\"delete_eventlog\":true,\"delete_plugin\":true,\"delete_propertyset\":true,\"delete_role\":true,\"delete_snippet\":true,\"delete_static_resource\":true,\"delete_symlink\":true,\"delete_template\":true,\"delete_tv\":true,\"delete_user\":true,\"delete_weblink\":true,\"directory_chmod\":true,\"directory_create\":true,\"directory_list\":true,\"directory_remove\":true,\"directory_update\":true,\"edit_category\":true,\"edit_chunk\":true,\"edit_context\":true,\"edit_document\":true,\"edit_locked\":true,\"edit_plugin\":true,\"edit_propertyset\":true,\"edit_role\":true,\"edit_snippet\":true,\"edit_static_resource\":true,\"edit_symlink\":true,\"edit_template\":true,\"edit_tv\":true,\"edit_user\":true,\"edit_weblink\":true,\"element_tree\":true,\"empty_cache\":true,\"error_log_erase\":true,\"error_log_view\":true,\"events\":true,\"export_static\":true,\"file_create\":true,\"file_list\":true,\"file_manager\":true,\"file_remove\":true,\"file_tree\":true,\"file_unpack\":true,\"file_update\":true,\"file_upload\":true,\"file_view\":true,\"flush_sessions\":true,\"frames\":true,\"help\":true,\"home\":true,\"language\":true,\"languages\":true,\"lexicons\":true,\"list\":true,\"load\":true,\"logout\":true,\"mgr_log_view\":true,\"mgr_log_erase\":true,\"menu_reports\":true,\"menu_security\":true,\"menu_site\":true,\"menu_support\":true,\"menu_system\":true,\"menu_tools\":true,\"menu_trash\":true,\"menu_user\":true,\"menus\":true,\"messages\":true,\"namespaces\":true,\"new_category\":true,\"new_chunk\":true,\"new_context\":true,\"new_document\":true,\"new_document_in_root\":true,\"new_plugin\":true,\"new_propertyset\":true,\"new_role\":true,\"new_snippet\":true,\"new_static_resource\":true,\"new_symlink\":true,\"new_template\":true,\"new_tv\":true,\"new_user\":true,\"new_weblink\":true,\"packages\":true,\"policy_delete\":true,\"policy_edit\":true,\"policy_new\":true,\"policy_save\":true,\"policy_template_delete\":true,\"policy_template_edit\":true,\"policy_template_new\":true,\"policy_template_save\":true,\"policy_template_view\":true,\"policy_view\":true,\"property_sets\":true,\"providers\":true,\"publish_document\":true,\"purge_deleted\":true,\"remove\":true,\"remove_locks\":true,\"resource_duplicate\":true,\"resource_quick_create\":true,\"resource_quick_update\":true,\"resource_tree\":true,\"resourcegroup_delete\":true,\"resourcegroup_edit\":true,\"resourcegroup_new\":true,\"resourcegroup_resource_edit\":true,\"resourcegroup_resource_list\":true,\"resourcegroup_save\":true,\"resourcegroup_view\":true,\"save\":true,\"save_category\":true,\"save_chunk\":true,\"save_context\":true,\"save_document\":true,\"save_plugin\":true,\"save_propertyset\":true,\"save_role\":true,\"save_snippet\":true,\"save_template\":true,\"save_tv\":true,\"save_user\":true,\"search\":true,\"set_sudo\":true,\"settings\":true,\"source_delete\":true,\"source_edit\":true,\"source_save\":true,\"source_view\":true,\"sources\":true,\"steal_locks\":true,\"tree_show_element_ids\":true,\"tree_show_resource_ids\":true,\"undelete_document\":true,\"unlock_element_properties\":true,\"unpublish_document\":true,\"usergroup_delete\":true,\"usergroup_edit\":true,\"usergroup_new\":true,\"usergroup_save\":true,\"usergroup_user_edit\":true,\"usergroup_user_list\":true,\"usergroup_view\":true,\"view\":true,\"view_category\":true,\"view_chunk\":true,\"view_context\":true,\"view_document\":true,\"view_element\":true,\"view_eventlog\":true,\"view_offline\":true,\"view_plugin\":true,\"view_propertyset\":true,\"view_role\":true,\"view_snippet\":true,\"view_sysinfo\":true,\"view_template\":true,\"view_tv\":true,\"view_unpublished\":true,\"view_user\":true,\"workspaces\":true}', 'permissions'),
(3, 'Load Only', 'policy_load_only_desc', 0, 3, '', '{\"load\":true}', 'permissions'),
(4, 'Load, List and View', 'policy_load_list_and_view_desc', 0, 3, '', '{\"load\":true,\"list\":true,\"view\":true}', 'permissions'),
(5, 'Object', 'policy_object_desc', 0, 3, '', '{\"load\":true,\"list\":true,\"view\":true,\"save\":true,\"remove\":true}', 'permissions'),
(6, 'Element', 'policy_element_desc', 0, 4, '', '{\"add_children\":true,\"create\":true,\"delete\":true,\"list\":true,\"load\":true,\"remove\":true,\"save\":true,\"view\":true,\"copy\":true}', 'permissions'),
(7, 'Content Editor', 'policy_content_editor_desc', 0, 1, '', '{\"change_profile\":true,\"class_map\":true,\"countries\":true,\"delete_document\":true,\"delete_static_resource\":true,\"delete_symlink\":true,\"delete_weblink\":true,\"edit_document\":true,\"edit_static_resource\":true,\"edit_symlink\":true,\"edit_weblink\":true,\"frames\":true,\"help\":true,\"home\":true,\"language\":true,\"list\":true,\"load\":true,\"logout\":true,\"menu_reports\":true,\"menu_site\":true,\"menu_support\":true,\"menu_tools\":true,\"menu_user\":true,\"new_document\":true,\"new_static_resource\":true,\"new_symlink\":true,\"new_weblink\":true,\"resource_duplicate\":true,\"resource_tree\":true,\"save_document\":true,\"source_view\":true,\"tree_show_resource_ids\":true,\"view\":true,\"view_document\":true,\"view_template\":true}', 'permissions'),
(8, 'Media Source Admin', 'policy_media_source_admin_desc', 0, 5, '', '{\"create\":true,\"copy\":true,\"load\":true,\"list\":true,\"save\":true,\"remove\":true,\"view\":true}', 'permissions'),
(9, 'Media Source User', 'policy_media_source_user_desc', 0, 5, '', '{\"load\":true,\"list\":true,\"view\":true}', 'permissions'),
(10, 'Developer', 'policy_developer_desc', 0, 1, '', '{\"about\":true,\"change_password\":true,\"change_profile\":true,\"charsets\":true,\"class_map\":true,\"components\":true,\"content_types\":true,\"countries\":true,\"create\":true,\"credits\":true,\"customize_forms\":true,\"dashboards\":true,\"database\":true,\"delete_category\":true,\"delete_chunk\":true,\"delete_context\":true,\"delete_document\":true,\"delete_eventlog\":true,\"delete_plugin\":true,\"delete_propertyset\":true,\"delete_role\":true,\"delete_snippet\":true,\"delete_template\":true,\"delete_tv\":true,\"delete_user\":true,\"directory_chmod\":true,\"directory_create\":true,\"directory_list\":true,\"directory_remove\":true,\"directory_update\":true,\"edit_category\":true,\"edit_chunk\":true,\"edit_context\":true,\"edit_document\":true,\"edit_locked\":true,\"edit_plugin\":true,\"edit_propertyset\":true,\"edit_role\":true,\"edit_snippet\":true,\"edit_static_resource\":true,\"edit_symlink\":true,\"edit_template\":true,\"edit_tv\":true,\"edit_user\":true,\"edit_weblink\":true,\"element_tree\":true,\"empty_cache\":true,\"error_log_erase\":true,\"error_log_view\":true,\"export_static\":true,\"file_create\":true,\"file_list\":true,\"file_manager\":true,\"file_remove\":true,\"file_tree\":true,\"file_unpack\":true,\"file_update\":true,\"file_upload\":true,\"file_view\":true,\"frames\":true,\"help\":true,\"home\":true,\"language\":true,\"languages\":true,\"lexicons\":true,\"list\":true,\"load\":true,\"logout\":true,\"mgr_log_view\":true,\"mgr_log_erase\":true,\"menu_reports\":true,\"menu_site\":true,\"menu_support\":true,\"menu_system\":true,\"menu_tools\":true,\"menu_user\":true,\"menus\":true,\"messages\":true,\"namespaces\":true,\"new_category\":true,\"new_chunk\":true,\"new_context\":true,\"new_document\":true,\"new_document_in_root\":true,\"new_plugin\":true,\"new_propertyset\":true,\"new_role\":true,\"new_snippet\":true,\"new_static_resource\":true,\"new_symlink\":true,\"new_template\":true,\"new_tv\":true,\"new_user\":true,\"new_weblink\":true,\"packages\":true,\"property_sets\":true,\"providers\":true,\"publish_document\":true,\"purge_deleted\":true,\"remove\":true,\"resource_duplicate\":true,\"resource_quick_create\":true,\"resource_quick_update\":true,\"resource_tree\":true,\"save\":true,\"save_category\":true,\"save_chunk\":true,\"save_context\":true,\"save_document\":true,\"save_plugin\":true,\"save_propertyset\":true,\"save_snippet\":true,\"save_template\":true,\"save_tv\":true,\"save_user\":true,\"search\":true,\"settings\":true,\"source_delete\":true,\"source_edit\":true,\"source_save\":true,\"source_view\":true,\"sources\":true,\"tree_show_element_ids\":true,\"tree_show_resource_ids\":true,\"undelete_document\":true,\"unlock_element_properties\":true,\"unpublish_document\":true,\"view\":true,\"view_category\":true,\"view_chunk\":true,\"view_context\":true,\"view_document\":true,\"view_element\":true,\"view_eventlog\":true,\"view_offline\":true,\"view_plugin\":true,\"view_propertyset\":true,\"view_role\":true,\"view_snippet\":true,\"view_sysinfo\":true,\"view_template\":true,\"view_tv\":true,\"view_unpublished\":true,\"view_user\":true,\"workspaces\":true}', 'permissions'),
(11, 'Context', 'policy_context_desc', 0, 6, '', '{\"load\":true,\"list\":true,\"view\":true,\"save\":true,\"remove\":true,\"copy\":true,\"view_unpublished\":true}', 'permissions'),
(12, 'Hidden Namespace', 'policy_hidden_namespace_desc', 0, 7, '', '{\"load\":false,\"list\":false,\"view\":true}', 'permissions');

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_policy_templates`
--

CREATE TABLE `modx_access_policy_templates` (
  `id` int(10) UNSIGNED NOT NULL,
  `template_group` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` mediumtext,
  `lexicon` varchar(255) NOT NULL DEFAULT 'permissions'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_access_policy_templates`
--

INSERT INTO `modx_access_policy_templates` (`id`, `template_group`, `name`, `description`, `lexicon`) VALUES
(1, 1, 'AdministratorTemplate', 'policy_template_administrator_desc', 'permissions'),
(2, 3, 'ResourceTemplate', 'policy_template_resource_desc', 'permissions'),
(3, 2, 'ObjectTemplate', 'policy_template_object_desc', 'permissions'),
(4, 4, 'ElementTemplate', 'policy_template_element_desc', 'permissions'),
(5, 5, 'MediaSourceTemplate', 'policy_template_mediasource_desc', 'permissions'),
(6, 7, 'ContextTemplate', 'policy_template_context_desc', 'permissions'),
(7, 6, 'NamespaceTemplate', 'policy_template_namespace_desc', 'permissions');

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_policy_template_groups`
--

CREATE TABLE `modx_access_policy_template_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_access_policy_template_groups`
--

INSERT INTO `modx_access_policy_template_groups` (`id`, `name`, `description`) VALUES
(1, 'Administrator', 'policy_template_group_administrator_desc'),
(2, 'Object', 'policy_template_group_object_desc'),
(3, 'Resource', 'policy_template_group_resource_desc'),
(4, 'Element', 'policy_template_group_element_desc'),
(5, 'MediaSource', 'policy_template_group_mediasource_desc'),
(6, 'Namespace', 'policy_template_group_namespace_desc'),
(7, 'Context', 'policy_template_group_context_desc');

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_resources`
--

CREATE TABLE `modx_access_resources` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_resource_groups`
--

CREATE TABLE `modx_access_resource_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_access_templatevars`
--

CREATE TABLE `modx_access_templatevars` (
  `id` int(10) UNSIGNED NOT NULL,
  `target` varchar(100) NOT NULL DEFAULT '',
  `principal_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modPrincipal',
  `principal` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999',
  `policy` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_actiondom`
--

CREATE TABLE `modx_actiondom` (
  `id` int(10) UNSIGNED NOT NULL,
  `set` int(11) NOT NULL DEFAULT '0',
  `action` varchar(191) NOT NULL DEFAULT '',
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` text,
  `xtype` varchar(100) NOT NULL DEFAULT '',
  `container` varchar(255) NOT NULL DEFAULT '',
  `rule` varchar(100) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  `constraint` varchar(255) NOT NULL DEFAULT '',
  `constraint_field` varchar(100) NOT NULL DEFAULT '',
  `constraint_class` varchar(100) NOT NULL DEFAULT '',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `for_parent` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `rank` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_actions_fields`
--

CREATE TABLE `modx_actions_fields` (
  `id` int(10) UNSIGNED NOT NULL,
  `action` varchar(191) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(100) NOT NULL DEFAULT 'field',
  `tab` varchar(191) NOT NULL DEFAULT '',
  `form` varchar(255) NOT NULL DEFAULT '',
  `other` varchar(255) NOT NULL DEFAULT '',
  `rank` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_actions_fields`
--

INSERT INTO `modx_actions_fields` (`id`, `action`, `name`, `type`, `tab`, `form`, `other`, `rank`) VALUES
(1, 'resource/update', 'modx-resource-settings', 'tab', '', 'modx-panel-resource', '', 0),
(2, 'resource/update', 'modx-resource-main-left', 'tab', '', 'modx-panel-resource', '', 1),
(3, 'resource/update', 'id', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 0),
(4, 'resource/update', 'pagetitle', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 1),
(5, 'resource/update', 'alias', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 2),
(6, 'resource/update', 'longtitle', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 3),
(7, 'resource/update', 'description', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 4),
(8, 'resource/update', 'introtext', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 5),
(9, 'resource/update', 'modx-resource-content', 'field', 'modx-resource-content', 'modx-panel-resource', '', 0),
(10, 'resource/update', 'modx-resource-content-above', 'tab', '', 'modx-panel-resource', '', 3),
(11, 'resource/update', 'modx-resource-content-below', 'tab', '', 'modx-panel-resource', '', 4),
(12, 'resource/update', 'modx-resource-main-right', 'tab', '', 'modx-panel-resource', '', 5),
(13, 'resource/update', 'modx-resource-main-right-top', 'tab', '', 'modx-panel-resource', '', 6),
(14, 'resource/update', 'published', 'field', 'modx-resource-main-right-top', 'modx-panel-resource', '', 0),
(15, 'resource/update', 'deleted', 'field', 'modx-resource-main-right-top', 'modx-panel-resource', '', 1),
(16, 'resource/update', 'publishedon', 'field', 'modx-resource-main-right-top', 'modx-panel-resource', '', 2),
(17, 'resource/update', 'pub_date', 'field', 'modx-resource-main-right-top', 'modx-panel-resource', '', 3),
(18, 'resource/update', 'unpub_date', 'field', 'modx-resource-main-right-top', 'modx-panel-resource', '', 4),
(19, 'resource/update', 'modx-resource-main-right-middle', 'tab', '', 'modx-panel-resource', '', 7),
(20, 'resource/update', 'template', 'field', 'modx-resource-main-right-middle', 'modx-panel-resource', '', 0),
(21, 'resource/update', 'modx-resource-main-right-bottom', 'tab', '', 'modx-panel-resource', '', 8),
(22, 'resource/update', 'hidemenu', 'field', 'modx-resource-main-right-bottom', 'modx-panel-resource', '', 0),
(23, 'resource/update', 'menutitle', 'field', 'modx-resource-main-right-bottom', 'modx-panel-resource', '', 1),
(24, 'resource/update', 'link_attributes', 'field', 'modx-resource-main-right-bottom', 'modx-panel-resource', '', 2),
(25, 'resource/update', 'menuindex', 'field', 'modx-resource-main-right-bottom', 'modx-panel-resource', '', 3),
(26, 'resource/update', 'modx-page-settings', 'tab', '', 'modx-panel-resource', '', 9),
(27, 'resource/update', 'modx-page-settings-left', 'tab', '', 'modx-panel-resource', '', 10),
(28, 'resource/update', 'class_key', 'field', 'modx-page-settings-left', 'modx-panel-resource', '', 0),
(29, 'resource/update', 'content_type', 'field', 'modx-page-settings-left', 'modx-panel-resource', '', 1),
(30, 'resource/update', 'modx-page-settings-right', 'tab', '', 'modx-panel-resource', '', 11),
(31, 'resource/update', 'parent-cmb', 'field', 'modx-page-settings-right', 'modx-panel-resource', '', 0),
(32, 'resource/update', 'content_dispo', 'field', 'modx-page-settings-right', 'modx-panel-resource', '', 1),
(33, 'resource/update', 'modx-page-settings-box-left', 'tab', '', 'modx-panel-resource', '', 12),
(34, 'resource/update', 'isfolder', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 0),
(35, 'resource/update', 'show_in_tree', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 1),
(36, 'resource/update', 'hide_children_in_tree', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 2),
(37, 'resource/update', 'alias_visible', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 3),
(38, 'resource/update', 'uri_override', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 4),
(39, 'resource/update', 'uri', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 5),
(40, 'resource/update', 'modx-page-settings-box-right', 'tab', '', 'modx-panel-resource', '', 13),
(41, 'resource/update', 'richtext', 'field', 'modx-page-settings-box-right', 'modx-panel-resource', '', 0),
(42, 'resource/update', 'cacheable', 'field', 'modx-page-settings-box-right', 'modx-panel-resource', '', 1),
(43, 'resource/update', 'searchable', 'field', 'modx-page-settings-box-right', 'modx-panel-resource', '', 2),
(44, 'resource/update', 'syncsite', 'field', 'modx-page-settings-box-right', 'modx-panel-resource', '', 3),
(45, 'resource/update', 'modx-panel-resource-tv', 'tab', '', 'modx-panel-resource', 'tv', 14),
(46, 'resource/update', 'modx-resource-access-permissions', 'tab', '', 'modx-panel-resource', '', 15),
(47, 'resource/create', 'modx-resource-settings', 'tab', '', 'modx-panel-resource', '', 0),
(48, 'resource/create', 'modx-resource-main-left', 'tab', '', 'modx-panel-resource', '', 1),
(49, 'resource/create', 'id', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 0),
(50, 'resource/create', 'pagetitle', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 1),
(51, 'resource/create', 'alias', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 2),
(52, 'resource/create', 'longtitle', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 3),
(53, 'resource/create', 'description', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 4),
(54, 'resource/create', 'introtext', 'field', 'modx-resource-main-left', 'modx-panel-resource', '', 5),
(55, 'resource/create', 'modx-resource-content', 'field', 'modx-resource-content', 'modx-panel-resource', '', 0),
(56, 'resource/create', 'modx-resource-main-right', 'tab', '', 'modx-panel-resource', '', 3),
(57, 'resource/create', 'modx-resource-main-right-top', 'tab', '', 'modx-panel-resource', '', 4),
(58, 'resource/create', 'published', 'field', 'modx-resource-main-right-top', 'modx-panel-resource', '', 0),
(59, 'resource/create', 'deleted', 'field', 'modx-resource-main-right-top', 'modx-panel-resource', '', 1),
(60, 'resource/create', 'publishedon', 'field', 'modx-resource-main-right-top', 'modx-panel-resource', '', 2),
(61, 'resource/create', 'pub_date', 'field', 'modx-resource-main-right-top', 'modx-panel-resource', '', 3),
(62, 'resource/create', 'unpub_date', 'field', 'modx-resource-main-right-top', 'modx-panel-resource', '', 4),
(63, 'resource/create', 'modx-resource-main-right-middle', 'tab', '', 'modx-panel-resource', '', 5),
(64, 'resource/create', 'template', 'field', 'modx-resource-main-right-middle', 'modx-panel-resource', '', 0),
(65, 'resource/create', 'modx-resource-main-right-bottom', 'tab', '', 'modx-panel-resource', '', 6),
(66, 'resource/create', 'hidemenu', 'field', 'modx-resource-main-right-bottom', 'modx-panel-resource', '', 0),
(67, 'resource/create', 'menutitle', 'field', 'modx-resource-main-right-bottom', 'modx-panel-resource', '', 1),
(68, 'resource/create', 'link_attributes', 'field', 'modx-resource-main-right-bottom', 'modx-panel-resource', '', 2),
(69, 'resource/create', 'menuindex', 'field', 'modx-resource-main-right-bottom', 'modx-panel-resource', '', 3),
(70, 'resource/create', 'modx-page-settings', 'tab', '', 'modx-panel-resource', '', 7),
(71, 'resource/create', 'modx-page-settings-left', 'tab', '', 'modx-panel-resource', '', 8),
(72, 'resource/create', 'class_key', 'field', 'modx-page-settings-left', 'modx-panel-resource', '', 0),
(73, 'resource/create', 'content_type', 'field', 'modx-page-settings-left', 'modx-panel-resource', '', 1),
(74, 'resource/create', 'modx-page-settings-right', 'tab', '', 'modx-panel-resource', '', 9),
(75, 'resource/create', 'parent-cmb', 'field', 'modx-page-settings-right', 'modx-panel-resource', '', 0),
(76, 'resource/create', 'content_dispo', 'field', 'modx-page-settings-right', 'modx-panel-resource', '', 1),
(77, 'resource/create', 'modx-page-settings-box-left', 'tab', '', 'modx-panel-resource', '', 10),
(78, 'resource/create', 'isfolder', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 0),
(79, 'resource/create', 'show_in_tree', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 1),
(80, 'resource/create', 'hide_children_in_tree', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 2),
(81, 'resource/create', 'alias_visible', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 3),
(82, 'resource/create', 'uri_override', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 4),
(83, 'resource/create', 'uri', 'field', 'modx-page-settings-box-left', 'modx-panel-resource', '', 5),
(84, 'resource/create', 'modx-page-settings-box-right', 'tab', '', 'modx-panel-resource', '', 11),
(85, 'resource/create', 'richtext', 'field', 'modx-page-settings-box-right', 'modx-panel-resource', '', 0),
(86, 'resource/create', 'cacheable', 'field', 'modx-page-settings-box-right', 'modx-panel-resource', '', 1),
(87, 'resource/create', 'searchable', 'field', 'modx-page-settings-box-right', 'modx-panel-resource', '', 2),
(88, 'resource/create', 'syncsite', 'field', 'modx-page-settings-box-right', 'modx-panel-resource', '', 3),
(89, 'resource/create', 'modx-panel-resource-tv', 'tab', '', 'modx-panel-resource', 'tv', 12),
(90, 'resource/create', 'modx-resource-access-permissions', 'tab', '', 'modx-panel-resource', '', 13);

-- --------------------------------------------------------

--
-- Table structure for table `modx_active_users`
--

CREATE TABLE `modx_active_users` (
  `internalKey` int(9) UNSIGNED NOT NULL DEFAULT '0',
  `username` varchar(50) NOT NULL DEFAULT '',
  `lasthit` int(20) NOT NULL DEFAULT '0',
  `id` int(10) DEFAULT NULL,
  `action` varchar(255) NOT NULL DEFAULT '',
  `ip` varchar(20) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_categories`
--

CREATE TABLE `modx_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent` int(10) UNSIGNED DEFAULT '0',
  `category` varchar(45) NOT NULL DEFAULT '',
  `rank` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_categories_closure`
--

CREATE TABLE `modx_categories_closure` (
  `ancestor` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `descendant` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `depth` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_content_type`
--

CREATE TABLE `modx_content_type` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` tinytext,
  `mime_type` tinytext,
  `file_extensions` tinytext,
  `icon` tinytext,
  `headers` mediumtext,
  `binary` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_content_type`
--

INSERT INTO `modx_content_type` (`id`, `name`, `description`, `mime_type`, `file_extensions`, `icon`, `headers`, `binary`) VALUES
(1, 'HTML', 'HTML content', 'text/html', '.html', '', NULL, 0),
(2, 'XML', 'XML content', 'text/xml', '.xml', 'icon-xml', NULL, 0),
(3, 'Text', 'Plain text content', 'text/plain', '.txt', 'icon-txt', NULL, 0),
(4, 'CSS', 'CSS content', 'text/css', '.css', 'icon-css', NULL, 0),
(5, 'JavaScript', 'JavaScript content', 'text/javascript', '.js', 'icon-js', NULL, 0),
(6, 'RSS', 'For RSS feeds', 'application/rss+xml', '.rss', 'icon-rss', NULL, 0),
(7, 'JSON', 'JSON', 'application/json', '.json', 'icon-json', NULL, 0),
(8, 'PDF', 'PDF Files', 'application/pdf', '.pdf', 'icon-pdf', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `modx_context`
--

CREATE TABLE `modx_context` (
  `key` varchar(100) NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `description` tinytext,
  `rank` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_context`
--

INSERT INTO `modx_context` (`key`, `name`, `description`, `rank`) VALUES
('mgr', 'Manager', 'The default manager or administration context for content management activity.', 0),
('web', 'Website', 'The default front-end context for your web site.', 0);

-- --------------------------------------------------------

--
-- Table structure for table `modx_context_resource`
--

CREATE TABLE `modx_context_resource` (
  `context_key` varchar(191) NOT NULL,
  `resource` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_context_setting`
--

CREATE TABLE `modx_context_setting` (
  `context_key` varchar(191) NOT NULL,
  `key` varchar(50) NOT NULL,
  `value` mediumtext,
  `xtype` varchar(75) NOT NULL DEFAULT 'textfield',
  `namespace` varchar(40) NOT NULL DEFAULT 'core',
  `area` varchar(255) NOT NULL DEFAULT '',
  `editedon` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_context_setting`
--

INSERT INTO `modx_context_setting` (`context_key`, `key`, `value`, `xtype`, `namespace`, `area`, `editedon`) VALUES
('mgr', 'allow_tags_in_post', '1', 'combo-boolean', 'core', 'system', NULL),
('mgr', 'modRequest.class', 'MODX\\Revolution\\modManagerRequest', 'textfield', 'core', 'system', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `modx_dashboard`
--

CREATE TABLE `modx_dashboard` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` text,
  `hide_trees` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `customizable` tinyint(1) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_dashboard`
--

INSERT INTO `modx_dashboard` (`id`, `name`, `description`, `hide_trees`, `customizable`) VALUES
(1, 'Default', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `modx_dashboard_widget`
--

CREATE TABLE `modx_dashboard_widget` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` text,
  `type` varchar(100) NOT NULL,
  `content` mediumtext,
  `properties` text,
  `namespace` varchar(191) NOT NULL DEFAULT '',
  `lexicon` varchar(191) NOT NULL DEFAULT 'core:dashboards',
  `size` varchar(255) NOT NULL DEFAULT 'half',
  `permission` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_dashboard_widget`
--

INSERT INTO `modx_dashboard_widget` (`id`, `name`, `description`, `type`, `content`, `properties`, `namespace`, `lexicon`, `size`, `permission`) VALUES
(1, 'w_newsfeed', 'w_newsfeed_desc', 'file', '[[++manager_path]]controllers/default/dashboard/widget.modx-news.php', NULL, 'core', 'core:dashboards', 'one-third', ''),
(2, 'w_securityfeed', 'w_securityfeed_desc', 'file', '[[++manager_path]]controllers/default/dashboard/widget.modx-security.php', NULL, 'core', 'core:dashboards', 'one-third', ''),
(3, 'w_whosonline', 'w_whosonline_desc', 'file', '[[++manager_path]]controllers/default/dashboard/widget.grid-online.php', NULL, 'core', 'core:dashboards', 'one-third', ''),
(4, 'w_recentlyeditedresources', 'w_recentlyeditedresources_desc', 'file', '[[++manager_path]]controllers/default/dashboard/widget.grid-rer.php', NULL, 'core', 'core:dashboards', 'two-thirds', 'view_document'),
(5, 'w_configcheck', 'w_configcheck_desc', 'file', '[[++manager_path]]controllers/default/dashboard/widget.configcheck.php', NULL, 'core', 'core:dashboards', 'full', ''),
(6, 'w_buttons', 'w_buttons_desc', 'file', '[[++manager_path]]controllers/default/dashboard/widget.buttons.php', '{\"create-resource\":{\"link\":\"[[++manager_url]]?a=resource\\/create\",\"icon\":\"file-o\",\"title\":\"[[%action_new_resource]]\",\"description\":\"[[%action_new_resource_desc]]\"},\"view-site\":{\"link\":\"[[++site_url]]\",\"icon\":\"eye\",\"title\":\"[[%action_view_website]]\",\"description\":\"[[%action_view_website_desc]]\",\"target\":\"_blank\"},\"advanced-search\":{\"link\":\"[[++manager_url]]?a=search\",\"icon\":\"search\",\"title\":\"[[%action_advanced_search]]\",\"description\":\"[[%action_advanced_search_desc]]\"},\"manage-users\":{\"link\":\"[[++manager_url]]?a=security\\/user\",\"icon\":\"user\",\"title\":\"[[%action_manage_users]]\",\"description\":\"[[%action_manage_users_desc]]\"}}', 'core', 'core:dashboards', 'full', ''),
(7, 'w_updates', 'w_updates_desc', 'file', '[[++manager_path]]controllers/default/dashboard/widget.updates.php', NULL, 'core', 'core:dashboards', 'one-third', 'workspaces');

-- --------------------------------------------------------

--
-- Table structure for table `modx_dashboard_widget_placement`
--

CREATE TABLE `modx_dashboard_widget_placement` (
  `user` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `dashboard` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `widget` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `rank` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `size` varchar(255) NOT NULL DEFAULT 'half'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_dashboard_widget_placement`
--

INSERT INTO `modx_dashboard_widget_placement` (`user`, `dashboard`, `widget`, `rank`, `size`) VALUES
(0, 1, 1, 2, 'one-third'),
(0, 1, 2, 3, 'one-third'),
(0, 1, 3, 5, 'one-third'),
(0, 1, 4, 6, 'two-thirds'),
(0, 1, 5, 1, 'full'),
(0, 1, 6, 0, 'full'),
(0, 1, 7, 4, 'one-third'),
(1, 1, 1, 2, 'one-third'),
(1, 1, 2, 3, 'one-third'),
(1, 1, 3, 5, 'one-third'),
(1, 1, 4, 6, 'two-thirds'),
(1, 1, 5, 1, 'full'),
(1, 1, 6, 0, 'full'),
(1, 1, 7, 4, 'one-third');

-- --------------------------------------------------------

--
-- Table structure for table `modx_deprecated_call`
--

CREATE TABLE `modx_deprecated_call` (
  `id` int(10) UNSIGNED NOT NULL,
  `method` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `call_count` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `caller` varchar(191) NOT NULL DEFAULT '',
  `caller_file` varchar(191) NOT NULL DEFAULT '',
  `caller_line` int(11) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_deprecated_call`
--

INSERT INTO `modx_deprecated_call` (`id`, `method`, `call_count`, `caller`, `caller_file`, `caller_line`) VALUES
(1, 1, 14, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\priemka-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(2, 1, 14, 'xPDO\\Om\\xPDOObject::load', 'D:\\Projects\\Hosts\\priemka-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\Om\\xPDOObject.php', 402),
(3, 2, 1, 'xPDO\\xPDO::newObject', 'D:\\Projects\\Hosts\\priemka-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 808),
(4, 3, 1, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\priemka-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(5, 3, 1, 'MODX\\Revolution\\modAccessibleObject::load', 'D:\\Projects\\Hosts\\priemka-modx.local\\release\\core\\src\\Revolution\\modAccessibleObject.php', 106),
(6, 4, 1, 'xPDO\\xPDO::newObject', 'D:\\Projects\\Hosts\\priemka-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 808),
(7, 5, 1, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\priemka-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(8, 5, 1, 'MODX\\Revolution\\modAccessibleObject::load', 'D:\\Projects\\Hosts\\priemka-modx.local\\release\\core\\src\\Revolution\\modAccessibleObject.php', 106),
(9, 6, 10, 'xPDO\\xPDO::newObject', 'D:\\Projects\\Hosts\\priemka-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 808),
(10, 6, 10, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\priemka-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(11, 6, 10, 'xPDO\\Om\\xPDOObject::load', 'D:\\Projects\\Hosts\\priemka-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\Om\\xPDOObject.php', 402),
(12, 7, 12, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\priemka-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(13, 7, 12, 'xPDO\\Om\\xPDOObject::load', 'D:\\Projects\\Hosts\\priemka-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\Om\\xPDOObject.php', 402),
(14, 8, 1, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\priemka-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(15, 8, 1, 'xPDO\\Om\\xPDOObject::load', 'D:\\Projects\\Hosts\\priemka-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\Om\\xPDOObject.php', 402),
(16, 9, 11, 'xPDO\\xPDO::newObject', 'D:\\Projects\\Hosts\\priemka-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 808),
(17, 10, 2, 'xPDO\\xPDO::getPKType', 'D:\\Projects\\Hosts\\priemka-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 1660),
(18, 10, 2, 'xPDO\\xPDO::getPK', 'D:\\Projects\\Hosts\\priemka-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 1598),
(19, 10, 2, 'xPDO\\xPDO::call', 'D:\\Projects\\Hosts\\priemka-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\xPDO.php', 774),
(20, 10, 2, 'xPDO\\Om\\xPDOObject::load', 'D:\\Projects\\Hosts\\priemka-modx.local\\release\\core\\vendor\\xpdo\\xpdo\\src\\xPDO\\Om\\xPDOObject.php', 402);

-- --------------------------------------------------------

--
-- Table structure for table `modx_deprecated_method`
--

CREATE TABLE `modx_deprecated_method` (
  `id` int(10) UNSIGNED NOT NULL,
  `definition` varchar(191) NOT NULL DEFAULT '',
  `since` varchar(191) NOT NULL DEFAULT '',
  `recommendation` varchar(1024) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_deprecated_method`
--

INSERT INTO `modx_deprecated_method` (`id`, `definition`, `since`, `recommendation`) VALUES
(1, 'modContextSetting', '3.0', 'Replace references to class modContextSetting with MODX\\Revolution\\modContextSetting to take advantage of PSR-4 autoloading.'),
(2, 'modx.modNamespace', '3.0', 'Replace references to class modx.modNamespace with MODX\\Revolution\\modNamespace to take advantage of PSR-4 autoloading.'),
(3, 'modNamespace', '3.0', 'Replace references to class modNamespace with MODX\\Revolution\\modNamespace to take advantage of PSR-4 autoloading.'),
(4, 'modx.modPlugin', '3.0', 'Replace references to class modx.modPlugin with MODX\\Revolution\\modPlugin to take advantage of PSR-4 autoloading.'),
(5, 'modPlugin', '3.0', 'Replace references to class modPlugin with MODX\\Revolution\\modPlugin to take advantage of PSR-4 autoloading.'),
(6, 'modPluginEvent', '3.0', 'Replace references to class modPluginEvent with MODX\\Revolution\\modPluginEvent to take advantage of PSR-4 autoloading.'),
(7, 'modSystemSetting', '3.0', 'Replace references to class modSystemSetting with MODX\\Revolution\\modSystemSetting to take advantage of PSR-4 autoloading.'),
(8, 'modEvent', '3.0', 'Replace references to class modEvent with MODX\\Revolution\\modEvent to take advantage of PSR-4 autoloading.'),
(9, 'modx.modSystemSetting', '3.0', 'Replace references to class modx.modSystemSetting with MODX\\Revolution\\modSystemSetting to take advantage of PSR-4 autoloading.'),
(10, 'modContentType', '3.0', 'Replace references to class modContentType with MODX\\Revolution\\modContentType to take advantage of PSR-4 autoloading.');

-- --------------------------------------------------------

--
-- Table structure for table `modx_documentgroup_names`
--

CREATE TABLE `modx_documentgroup_names` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `private_memgroup` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `private_webgroup` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_document_groups`
--

CREATE TABLE `modx_document_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `document_group` int(10) NOT NULL DEFAULT '0',
  `document` int(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_element_property_sets`
--

CREATE TABLE `modx_element_property_sets` (
  `element` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `element_class` varchar(100) NOT NULL DEFAULT '',
  `property_set` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_extension_packages`
--

CREATE TABLE `modx_extension_packages` (
  `id` int(10) UNSIGNED NOT NULL,
  `namespace` varchar(40) NOT NULL DEFAULT 'core',
  `name` varchar(100) NOT NULL DEFAULT 'core',
  `path` text,
  `table_prefix` varchar(255) NOT NULL DEFAULT '',
  `service_class` varchar(255) NOT NULL DEFAULT '',
  `service_name` varchar(255) NOT NULL DEFAULT '',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_fc_profiles`
--

CREATE TABLE `modx_fc_profiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `rank` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_fc_profiles_usergroups`
--

CREATE TABLE `modx_fc_profiles_usergroups` (
  `usergroup` int(11) NOT NULL DEFAULT '0',
  `profile` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_fc_sets`
--

CREATE TABLE `modx_fc_sets` (
  `id` int(10) UNSIGNED NOT NULL,
  `profile` int(11) NOT NULL DEFAULT '0',
  `action` varchar(191) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `template` int(11) NOT NULL DEFAULT '0',
  `constraint` varchar(255) NOT NULL DEFAULT '',
  `constraint_field` varchar(100) NOT NULL DEFAULT '',
  `constraint_class` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_lexicon_entries`
--

CREATE TABLE `modx_lexicon_entries` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  `topic` varchar(191) NOT NULL DEFAULT 'default',
  `namespace` varchar(40) NOT NULL DEFAULT 'core',
  `language` varchar(20) NOT NULL DEFAULT 'en',
  `createdon` datetime DEFAULT NULL,
  `editedon` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_manager_log`
--

CREATE TABLE `modx_manager_log` (
  `id` int(10) UNSIGNED NOT NULL,
  `user` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `occurred` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `action` varchar(100) NOT NULL DEFAULT '',
  `classKey` varchar(100) NOT NULL DEFAULT '',
  `item` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_manager_log`
--

INSERT INTO `modx_manager_log` (`id`, `user`, `occurred`, `action`, `classKey`, `item`) VALUES
(1, 1, '2026-06-08 09:29:34', 'login', 'MODX\\Revolution\\modContext', 'mgr'),
(2, 1, '2026-06-08 09:35:01', 'chunk_create', 'MODX\\Revolution\\modChunk', '1'),
(3, 1, '2026-06-08 09:35:25', 'chunk_create', 'MODX\\Revolution\\modChunk', '2'),
(4, 1, '2026-06-08 09:35:54', 'chunk_create', 'MODX\\Revolution\\modChunk', '3'),
(5, 1, '2026-06-08 09:36:20', 'chunk_create', 'MODX\\Revolution\\modChunk', '4'),
(6, 1, '2026-06-08 09:36:40', 'chunk_create', 'MODX\\Revolution\\modChunk', '5'),
(7, 1, '2026-06-08 09:36:58', 'chunk_create', 'MODX\\Revolution\\modChunk', '6'),
(8, 1, '2026-06-08 09:37:18', 'chunk_create', 'MODX\\Revolution\\modChunk', '7'),
(9, 1, '2026-06-08 09:37:35', 'chunk_create', 'MODX\\Revolution\\modChunk', '8'),
(10, 1, '2026-06-08 09:37:52', 'chunk_create', 'MODX\\Revolution\\modChunk', '9'),
(11, 1, '2026-06-08 09:38:10', 'chunk_create', 'MODX\\Revolution\\modChunk', '10'),
(12, 1, '2026-06-08 09:38:26', 'chunk_create', 'MODX\\Revolution\\modChunk', '11'),
(13, 1, '2026-06-08 09:39:29', 'chunk_create', 'MODX\\Revolution\\modChunk', '12'),
(14, 1, '2026-06-08 09:39:46', 'chunk_create', 'MODX\\Revolution\\modChunk', '13'),
(15, 1, '2026-06-08 09:40:09', 'chunk_create', 'MODX\\Revolution\\modChunk', '14'),
(16, 1, '2026-06-08 09:40:32', 'chunk_create', 'MODX\\Revolution\\modChunk', '15'),
(17, 1, '2026-06-08 09:40:51', 'chunk_create', 'MODX\\Revolution\\modChunk', '16'),
(18, 1, '2026-06-08 09:41:10', 'chunk_create', 'MODX\\Revolution\\modChunk', '17'),
(19, 1, '2026-06-08 09:47:32', 'template_update', 'MODX\\Revolution\\modTemplate', '1'),
(20, 1, '2026-06-08 09:47:32', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modTemplate 1 Default'),
(21, 1, '2026-06-08 10:09:52', 'chunk_update', 'MODX\\Revolution\\modChunk', '9'),
(22, 1, '2026-06-08 10:09:53', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 9 Default'),
(23, 1, '2026-06-08 10:52:16', 'chunk_update', 'MODX\\Revolution\\modChunk', '15'),
(24, 1, '2026-06-08 10:52:16', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 15 Default'),
(25, 1, '2026-06-08 10:53:59', 'template_update', 'MODX\\Revolution\\modTemplate', '1'),
(26, 1, '2026-06-08 10:53:59', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modTemplate 1 Default'),
(27, 1, '2026-06-08 10:55:35', 'chunk_update', 'MODX\\Revolution\\modChunk', '6'),
(28, 1, '2026-06-08 10:55:35', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 6 Default'),
(29, 1, '2026-06-08 10:57:02', 'chunk_update', 'MODX\\Revolution\\modChunk', '6'),
(30, 1, '2026-06-08 10:57:03', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 6 Default'),
(31, 1, '2026-06-08 10:58:51', 'chunk_update', 'MODX\\Revolution\\modChunk', '4'),
(32, 1, '2026-06-08 10:58:51', 'propertyset_update_from_element', 'MODX\\Revolution\\modPropertySet', 'MODX\\Revolution\\modChunk 4 Default');

-- --------------------------------------------------------

--
-- Table structure for table `modx_media_sources`
--

CREATE TABLE `modx_media_sources` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` text,
  `class_key` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\Sources\\modFileMediaSource',
  `properties` mediumtext,
  `is_stream` tinyint(1) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_media_sources`
--

INSERT INTO `modx_media_sources` (`id`, `name`, `description`, `class_key`, `properties`, `is_stream`) VALUES
(1, 'Filesystem', '', 'MODX\\Revolution\\Sources\\modFileMediaSource', 'a:0:{}', 1);

-- --------------------------------------------------------

--
-- Table structure for table `modx_media_sources_contexts`
--

CREATE TABLE `modx_media_sources_contexts` (
  `source` int(11) NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT 'web'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_media_sources_elements`
--

CREATE TABLE `modx_media_sources_elements` (
  `source` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `object_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modTemplateVar',
  `object` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `context_key` varchar(100) NOT NULL DEFAULT 'web'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_membergroup_names`
--

CREATE TABLE `modx_membergroup_names` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `description` text,
  `parent` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `rank` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `dashboard` int(10) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_membergroup_names`
--

INSERT INTO `modx_membergroup_names` (`id`, `name`, `description`, `parent`, `rank`, `dashboard`) VALUES
(1, 'Administrator', NULL, 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `modx_member_groups`
--

CREATE TABLE `modx_member_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_group` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `member` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `role` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `rank` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_member_groups`
--

INSERT INTO `modx_member_groups` (`id`, `user_group`, `member`, `role`, `rank`) VALUES
(1, 1, 1, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `modx_menus`
--

CREATE TABLE `modx_menus` (
  `text` varchar(191) NOT NULL DEFAULT '',
  `parent` varchar(191) NOT NULL DEFAULT '',
  `action` varchar(191) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `icon` varchar(255) NOT NULL DEFAULT '',
  `menuindex` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `handler` text NOT NULL,
  `permissions` text NOT NULL,
  `namespace` varchar(100) NOT NULL DEFAULT 'core'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_menus`
--

INSERT INTO `modx_menus` (`text`, `parent`, `action`, `description`, `icon`, `menuindex`, `params`, `handler`, `permissions`, `namespace`) VALUES
('about', 'usernav', 'help', 'about_desc', '<i class=\"icon-question-circle icon\"></i>', 3, '', '', 'help', 'core'),
('access', 'usernav', '', '', '<i class=\"icon-user-lock icon\"></i>', 1, '', '', 'access_permissions', 'core'),
('acls', 'access', 'security/permission', 'acls_desc', '', 2, '', '', 'access_permissions', 'core'),
('admin', 'usernav', '', '', '<i class=\"icon-gear icon\"></i>', 2, '', '', 'settings', 'core'),
('components', 'topnav', '', '', '<i class=\"icon-cube icon\"></i>', 2, '', '', 'components', 'core'),
('content_types', 'site', 'system/contenttype', 'content_types_desc', '', 4, '', '', 'content_types', 'core'),
('contexts', 'admin', 'context', 'contexts_desc', '', 4, '', '', 'view_context', 'core'),
('dashboards', 'admin', 'system/dashboards', 'dashboards_desc', '', 5, '', '', 'dashboards', 'core'),
('edit_menu', 'admin', 'system/action', 'edit_menu_desc', '', 3, '', '', 'actions', 'core'),
('eventlog_viewer', 'reports', 'system/event', 'eventlog_viewer_desc', '', 1, '', '', 'view_eventlog', 'core'),
('file_browser', 'media', 'media/browser', 'file_browser_desc', '', 0, '', '', 'file_manager', 'core'),
('flush_access', 'access', '', 'flush_access_desc', '', 3, '', 'MODx.msg.confirm({\n                            title: _(\'flush_access\')\n                            ,text: _(\'flush_access_confirm\')\n                            ,url: MODx.config.connector_url\n                            ,params: {\n                                action: \'security/access/flush\'\n                            }\n                            ,listeners: {\n                                \'success\': {fn:function() { location.href = \'./\'; },scope:this},\n                                \'failure\': {fn:function(response) { Ext.MessageBox.alert(\'failure\', response.responseText); },scope:this},\n                            }\n                        });', 'access_permissions', 'core'),
('flush_sessions', 'access', '', 'flush_sessions_desc', '', 4, '', 'MODx.msg.confirm({\n                            title: _(\'flush_sessions\')\n                            ,text: _(\'flush_sessions_confirm\')\n                            ,url: MODx.config.connector_url\n                            ,params: {\n                                action: \'security/flush\'\n                            }\n                            ,listeners: {\n                                \'success\': {fn:function() { location.href = \'./\'; },scope:this}\n                            }\n                        });', 'flush_sessions', 'core'),
('form_customization', 'admin', 'security/forms', 'form_customization_desc', '', 1, '', '', 'customize_forms', 'core'),
('installer', 'components', 'workspaces', 'installer_desc', '', 0, '', '', 'packages', 'core'),
('language', 'admin', '', 'language_desc', '', 8, '', '', 'language', 'core'),
('lexicon_management', 'admin', 'workspaces/lexicon', 'lexicon_management_desc', '', 7, '', '', 'lexicons', 'core'),
('logout', 'user', 'security/logout', 'logout_desc', '', 2, '', 'MODx.logout(); return false;', 'logout', 'core'),
('media', 'topnav', '', '', '<i class=\"icon-file-image-o icon\"></i>', 1, '', '', 'file_manager', 'core'),
('messages', 'user', 'security/message', 'messages_desc', '', 1, '', '', 'messages', 'core'),
('namespaces', 'admin', 'workspaces/namespace', 'namespaces_desc', '', 6, '', '', 'namespaces', 'core'),
('new_resource', 'site', 'resource/create', 'new_resource_desc', '', 0, '', '', 'new_document', 'core'),
('propertysets', 'admin', 'element/propertyset', 'propertysets_desc', '', 2, '', '', 'property_sets', 'core'),
('refreshuris', 'refresh_site', '', 'refreshuris_desc', '', 0, '', 'MODx.refreshURIs(); return false;', 'empty_cache', 'core'),
('refresh_site', 'site', '', 'refresh_site_desc', '', 1, '', 'MODx.clearCache(); return false;', 'empty_cache', 'core'),
('remove_locks', 'site', '', 'remove_locks_desc', '', 2, '', 'MODx.removeLocks();return false;', 'remove_locks', 'core'),
('reports', 'admin', '', 'reports_desc', '', 9, '', '', 'menu_reports', 'core'),
('resource_groups', 'access', 'security/resourcegroup', 'resource_groups_desc', '', 1, '', '', 'access_permissions', 'core'),
('site', 'topnav', '', '', '<i class=\"icon-file-text-o icon\"></i>', 0, '', '', 'menu_site', 'core'),
('site_schedule', 'site', 'resource/site_schedule', 'site_schedule_desc', '', 3, '', '', 'view_document', 'core'),
('sources', 'media', 'source', 'sources_desc', '', 1, '', '', 'sources', 'core'),
('system_settings', 'admin', 'system/settings', 'system_settings_desc', '', 0, '', '', 'settings', 'core'),
('topnav', '', '', 'topnav_desc', '', 0, '', '', '', 'core'),
('trash', 'site', 'resource/trash', 'trash_desc', '', 5, '', '', 'menu_trash', 'core'),
('user', 'usernav', '', '', '<span id=\"user-avatar\" title=\"{$username}\">{$userImage}</span> <span id=\"user-username\">{$username}</span>', 0, '', '', 'menu_user', 'core'),
('usernav', '', '', 'usernav_desc', '', 1, '', '', '', 'core'),
('users', 'access', 'security/user', 'user_management_desc', '', 0, '', '', 'view_user', 'core'),
('view_logging', 'reports', 'system/logs', 'view_logging_desc', '', 0, '', '', 'mgr_log_view', 'core'),
('view_sysinfo', 'reports', 'system/info', 'view_sysinfo_desc', '', 2, '', '', 'view_sysinfo', 'core'),
('{$username}', 'user', 'security/profile', 'profile_desc', '', 0, '', '', 'change_profile', 'core');

-- --------------------------------------------------------

--
-- Table structure for table `modx_namespaces`
--

CREATE TABLE `modx_namespaces` (
  `name` varchar(40) NOT NULL DEFAULT '',
  `path` text,
  `assets_path` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_namespaces`
--

INSERT INTO `modx_namespaces` (`name`, `path`, `assets_path`) VALUES
('ace', '{core_path}components/ace/', ''),
('core', '{core_path}', '{assets_path}');

-- --------------------------------------------------------

--
-- Table structure for table `modx_property_set`
--

CREATE TABLE `modx_property_set` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT '',
  `category` int(10) NOT NULL DEFAULT '0',
  `description` varchar(255) NOT NULL DEFAULT '',
  `properties` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_register_messages`
--

CREATE TABLE `modx_register_messages` (
  `topic` int(10) UNSIGNED NOT NULL,
  `id` varchar(191) NOT NULL,
  `created` datetime NOT NULL,
  `valid` datetime NOT NULL,
  `accessed` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `accesses` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `expires` int(20) NOT NULL DEFAULT '0',
  `payload` mediumtext NOT NULL,
  `kill` tinyint(1) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_register_queues`
--

CREATE TABLE `modx_register_queues` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `options` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_register_queues`
--

INSERT INTO `modx_register_queues` (`id`, `name`, `options`) VALUES
(1, 'locks', 'a:1:{s:9:\"directory\";s:5:\"locks\";}');

-- --------------------------------------------------------

--
-- Table structure for table `modx_register_topics`
--

CREATE TABLE `modx_register_topics` (
  `id` int(10) UNSIGNED NOT NULL,
  `queue` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `created` datetime NOT NULL,
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `options` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_register_topics`
--

INSERT INTO `modx_register_topics` (`id`, `queue`, `name`, `created`, `updated`, `options`) VALUES
(1, 1, '/resource/', '2026-06-08 09:29:52', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `modx_session`
--

CREATE TABLE `modx_session` (
  `id` varchar(191) NOT NULL DEFAULT '',
  `access` int(20) UNSIGNED NOT NULL,
  `data` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_session`
--

INSERT INTO `modx_session` (`id`, `access`, `data`) VALUES
('21af26bacb0627ce07d6868b2ae0907d', 1780905539, 'modx.user.contextTokens|a:0:{}modx.user.0.resourceGroups|a:1:{s:3:\"web\";a:0:{}}modx.user.0.attributes|a:1:{s:3:\"web\";a:5:{s:32:\"MODX\\Revolution\\modAccessContext\";a:1:{s:3:\"web\";a:1:{i:0;a:3:{s:9:\"principal\";i:0;s:9:\"authority\";i:0;s:6:\"policy\";a:1:{s:4:\"load\";b:1;}}}}s:38:\"MODX\\Revolution\\modAccessResourceGroup\";a:0:{}s:33:\"MODX\\Revolution\\modAccessCategory\";a:0:{}s:44:\"MODX\\Revolution\\Sources\\modAccessMediaSource\";a:0:{}s:34:\"MODX\\Revolution\\modAccessNamespace\";a:0:{}}}'),
('2f16116b41b4f316e797371d2e0a3dd4', 1780905242, 'modx.user.contextTokens|a:0:{}modx.user.0.resourceGroups|a:1:{s:3:\"web\";a:0:{}}modx.user.0.attributes|a:1:{s:3:\"web\";a:5:{s:32:\"MODX\\Revolution\\modAccessContext\";a:1:{s:3:\"web\";a:1:{i:0;a:3:{s:9:\"principal\";i:0;s:9:\"authority\";i:0;s:6:\"policy\";a:1:{s:4:\"load\";b:1;}}}}s:38:\"MODX\\Revolution\\modAccessResourceGroup\";a:0:{}s:33:\"MODX\\Revolution\\modAccessCategory\";a:0:{}s:44:\"MODX\\Revolution\\Sources\\modAccessMediaSource\";a:0:{}s:34:\"MODX\\Revolution\\modAccessNamespace\";a:0:{}}}'),
('445142ca3cc0bc41dad75b6e20b50a02', 1780901336, 'modx.user.contextTokens|a:0:{}'),
('451f5c7f53efa4281cfca262c79174e0', 1780904913, 'modx.user.contextTokens|a:0:{}'),
('545e1f8106c3b3382d0182a62b40f735', 1780905037, 'modx.user.contextTokens|a:0:{}'),
('710a81b0f459b4f290ee8d3ce7b5d7f0', 1780903703, 'modx.user.contextTokens|a:0:{}'),
('86fa20f423de3614293b406e774e1022', 1780905191, 'modx.user.contextTokens|a:1:{s:3:\"mgr\";i:1;}manager_language|s:2:\"ru\";modx.user.0.resourceGroups|a:1:{s:3:\"mgr\";a:0:{}}modx.user.0.attributes|a:1:{s:3:\"mgr\";a:5:{s:32:\"MODX\\Revolution\\modAccessContext\";a:1:{s:3:\"web\";a:1:{i:0;a:3:{s:9:\"principal\";i:0;s:9:\"authority\";i:0;s:6:\"policy\";a:1:{s:4:\"load\";b:1;}}}}s:38:\"MODX\\Revolution\\modAccessResourceGroup\";a:0:{}s:33:\"MODX\\Revolution\\modAccessCategory\";a:0:{}s:44:\"MODX\\Revolution\\Sources\\modAccessMediaSource\";a:0:{}s:34:\"MODX\\Revolution\\modAccessNamespace\";a:0:{}}}modx.mgr.user.token|s:52:\"modx6a2660ff4ffda2.66703613_16a26614ec7f3f0.19506468\";modx.mgr.session.cookie.lifetime|i:0;modx.mgr.user.config|a:0:{}newResourceTokens|a:3:{i:0;s:23:\"6a26640fbc9ef2.05749200\";i:1;s:23:\"6a2674e052aa40.37437676\";i:2;s:23:\"6a2674e7940de6.71117993\";}'),
('8c7a1bf11521cd1993a3644c1fcff7cb', 1780902619, 'modx.user.contextTokens|a:0:{}'),
('905c426ea1e3f6b5e2647dd919738c85', 1780905140, 'modx.user.contextTokens|a:0:{}modx.user.0.resourceGroups|a:1:{s:3:\"web\";a:0:{}}modx.user.0.attributes|a:1:{s:3:\"web\";a:5:{s:32:\"MODX\\Revolution\\modAccessContext\";a:1:{s:3:\"web\";a:1:{i:0;a:3:{s:9:\"principal\";i:0;s:9:\"authority\";i:0;s:6:\"policy\";a:1:{s:4:\"load\";b:1;}}}}s:38:\"MODX\\Revolution\\modAccessResourceGroup\";a:0:{}s:33:\"MODX\\Revolution\\modAccessCategory\";a:0:{}s:44:\"MODX\\Revolution\\Sources\\modAccessMediaSource\";a:0:{}s:34:\"MODX\\Revolution\\modAccessNamespace\";a:0:{}}}');

-- --------------------------------------------------------

--
-- Table structure for table `modx_site_content`
--

CREATE TABLE `modx_site_content` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(20) NOT NULL DEFAULT 'document',
  `pagetitle` varchar(191) NOT NULL DEFAULT '',
  `longtitle` varchar(191) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `alias` varchar(191) DEFAULT '',
  `link_attributes` varchar(255) NOT NULL DEFAULT '',
  `published` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `pub_date` int(20) NOT NULL DEFAULT '0',
  `unpub_date` int(20) NOT NULL DEFAULT '0',
  `parent` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `isfolder` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `introtext` text,
  `content` mediumtext,
  `richtext` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `template` int(10) NOT NULL DEFAULT '0',
  `menuindex` int(10) NOT NULL DEFAULT '0',
  `searchable` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `cacheable` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `createdby` int(10) NOT NULL DEFAULT '0',
  `createdon` int(20) NOT NULL DEFAULT '0',
  `editedby` int(10) NOT NULL DEFAULT '0',
  `editedon` int(20) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `deletedon` int(20) NOT NULL DEFAULT '0',
  `deletedby` int(10) NOT NULL DEFAULT '0',
  `publishedon` int(20) NOT NULL DEFAULT '0',
  `publishedby` int(10) NOT NULL DEFAULT '0',
  `menutitle` varchar(255) NOT NULL DEFAULT '',
  `content_dispo` tinyint(1) NOT NULL DEFAULT '0',
  `hidemenu` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `class_key` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modDocument',
  `context_key` varchar(100) NOT NULL DEFAULT 'web',
  `content_type` int(11) UNSIGNED NOT NULL DEFAULT '1',
  `uri` text,
  `uri_override` tinyint(1) NOT NULL DEFAULT '0',
  `hide_children_in_tree` tinyint(1) NOT NULL DEFAULT '0',
  `show_in_tree` tinyint(1) NOT NULL DEFAULT '1',
  `properties` mediumtext,
  `alias_visible` tinyint(1) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_site_content`
--

INSERT INTO `modx_site_content` (`id`, `type`, `pagetitle`, `longtitle`, `description`, `alias`, `link_attributes`, `published`, `pub_date`, `unpub_date`, `parent`, `isfolder`, `introtext`, `content`, `richtext`, `template`, `menuindex`, `searchable`, `cacheable`, `createdby`, `createdon`, `editedby`, `editedon`, `deleted`, `deletedon`, `deletedby`, `publishedon`, `publishedby`, `menutitle`, `content_dispo`, `hidemenu`, `class_key`, `context_key`, `content_type`, `uri`, `uri_override`, `hide_children_in_tree`, `show_in_tree`, `properties`, `alias_visible`) VALUES
(1, 'document', 'Главная', 'Поздравляем!', '', 'index', '', 1, 0, 0, 0, 0, NULL, '<p>You have successfully installed MODX Revolution&nbsp;[[++settings_version]]!</p>\n<p>Now that MODX is installed you can login to the manager to create your templates, manage content and install third party extras to add functionality to your&nbsp;website. </p>\n\n<h2>New to&nbsp;MODX?</h2>\n\n<p>Pages on a MODX site are called <a href=\"https://docs.modx.com/3.x/en/building-sites/resources\">Resources</a>, and are visible on the left-hand side of the manager in the Resources tab. Resources can be nested under other resources, making it easy to create a tree of resources. There are different types of resources for different use&nbsp;cases.</p>\n\n<p>Building your website is done through a combination of <b>Templates</b>, <b>Template Variables</b>, <b>Chunks</b>, <b>Snippets</b> and <b>Plugins</b>. Collectively these are known as <b>Elements</b>, and can also be found in the left-hand side of the manager, in the Elements&nbsp;tab.</p>\n\n<p><a href=\"https://docs.modx.com/3.x/en/building-sites/elements/templates\">Templates</a> contain the outer markup of any page. Each resource can only be assigned to a single template at a time. By adding <a href=\"https://docs.modx.com/3.x/en/building-sites/elements/template-variables\">Template Variables</a> to a template, you can add custom fields for any resource using that particular&nbsp;template.</p>\n\n<p>With <a href=\"https://docs.modx.com/3.x/en/building-sites/elements/chunks\">Chunks</a> you can share parts of the markup, such as a header, across different templates. <a href=\"https://docs.modx.com/3.x/en/building-sites/elements/snippets\">Snippets</a> are pieces of PHP that return dynamic content, such as summaries of other resources or the current date. With snippets, you will often use Chunks to mark up the pieces of content it returns, instead of mixing the PHP and&nbsp;HTML.</p>\n\n<p>Finally, <a href=\"https://docs.modx.com/3.x/en/building-sites/elements/plugins\">Plugins</a> enable more advanced features by hooking into the extensive events system provided by&nbsp;MODX.</p>\n\n<p>To learn more about MODX, be sure to check out the <a href=\"https://docs.modx.com/3.x/en/getting-started\">Getting Started</a> section in the official&nbsp;documentation.</p>\n', 1, 1, 0, 1, 1, 1, 1780900135, 0, 0, 0, 0, 0, 0, 0, '', 0, 0, 'MODX\\Revolution\\modDocument', 'web', 1, NULL, 0, 0, 1, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `modx_site_htmlsnippets`
--

CREATE TABLE `modx_site_htmlsnippets` (
  `id` int(10) UNSIGNED NOT NULL,
  `source` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `property_preprocess` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT 'Chunk',
  `editor_type` int(11) NOT NULL DEFAULT '0',
  `category` int(11) NOT NULL DEFAULT '0',
  `cache_type` tinyint(1) NOT NULL DEFAULT '0',
  `snippet` mediumtext,
  `locked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `properties` text,
  `static` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `static_file` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_site_htmlsnippets`
--

INSERT INTO `modx_site_htmlsnippets` (`id`, `source`, `property_preprocess`, `name`, `description`, `editor_type`, `category`, `cache_type`, `snippet`, `locked`, `properties`, `static`, `static_file`) VALUES
(1, 1, 0, 'head', '', 0, 0, 0, '<head>\n    <meta charset=\"UTF-8\" />\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n    <title>Приёмная комиссия КУБГАУ 2025</title>\n    <link rel=\"stylesheet\" href=\"./lpk-2025/css/master.css\" />\n    <!-- Favico -->\n    <link rel=\"icon\" type=\"image/svg+xml\" href=\"./lpk-2025/img/favico/favicon.svg\" />\n    <link rel=\"icon\" type=\"image/png\" href=\"./lpk-2025/img/favico/favicon.png\" />\n    <!-- /Favico -->\n</head>', 0, 'a:0:{}', 0, ''),
(2, 1, 0, 'header', '', 0, 0, 0, '    <!-- Навигация -->\n    <header>\n        <div class=\"container\">\n            <div class=\"left-links\">\n                <a href=\"#hero\" class=\"scroll-link logo\">\n                    <picture width=\"217\" height=\"46\">\n                        <img class=\"lazy\" id=\"logo-leaf\" data-src=\"./lpk-2025/img/logo_leaf.svg\" src=\"./lpk-2025/img/logo-image-loading.webp\" alt=\"КУБГАУ (лепесток)\" width=\"26px\" height=\"46px\">\n                        <img class=\"lazy\" id=\"logo-text\" data-src=\"./lpk-2025/img/logo_text.svg\" src=\"./lpk-2025/img/logo-text-loading.webp\" alt=\"КУБГАУ (лого)\" width=\"179\" height=\"28\">\n                    </picture>\n                </a>\n                <a href=\"https://kubsau.ru/index-main.php\" class=\"bttn-outline main-link\">\n                    <i class=\"bx bx-left-arrow-alt\"></i>\n                    <span>На основной сайт</span>\n                </a>\n            </div>\n            <div class=\"right-links\">\n                <nav>\n                    <ul>\n                        <li><a href=\"https://kubsau.ru/entrant/tselevoe-obuchenie/\">Целевое обучение</a></li>\n                        <li><a href=\"#about\" class=\"scroll-link\">О нас</a></li>\n                        <li><a href=\"#calculator\" class=\"scroll-link\">Направления</a></li>\n                        <li><a href=\"#bank\" class=\"scroll-link\">Кредит</a></li>\n                        <li><a href=\"#faq\" class=\"scroll-link\">Вопрос-ответ</a></li>\n                        <li><a href=\"#contacts\" class=\"scroll-link\">Контакты</a></li>\n                        <li><a href=\"#task\" class=\"bttn scroll-link\">Как поступить?</a></li>\n                        <li class=\"phone-cut\">\n                            <a href=\"tel:+78612215881\"><i class=\"bx bxs-phone\"></i><span>+7 (861) 221-58-81</span></a>\n                        </li>\n                    </ul>\n                </nav>\n                <a href=\"#task\" class=\"scroll-link bttn send-docs-mobile\">\n                    <i class=\"bx bxs-file\"></i>\n                    <span>Как поступить?</span>\n                </a>\n                <a href=\"tel:+78612215881\" class=\"icon phone\"><i class=\"bx bxs-phone bx-flip-horizontal\"></i></a>\n                <a href=\"#mobile-nav\" class=\"icon burger sidenav-trigger\"><i class=\"bx bx-menu\"></i></a>\n            </div>\n        </div>\n    </header>\n    <ul class=\"sidenav\" id=\"mobile-nav\">\n        <li><a href=\"https://kubsau.ru/entrant/tselevoe-obuchenie/\">Целевое обучение</a></li>\n        <li><a href=\"#about\" class=\"scroll-link\">О нас</a></li>\n        <li><a href=\"#calculator\" class=\"scroll-link\">Направления</a></li>\n        <li><a href=\"#bank\" class=\"scroll-link\">Кредит</a></li>\n        <li><a href=\"#faq\" class=\"scroll-link\">Вопрос-ответ</a></li>\n        <li><a href=\"#contacts\" class=\"scroll-link\">Контакты</a></li>\n        <li><a href=\"#task\" class=\"scroll-link\">Как поступить?</a></li>\n    </ul>', 0, 'a:0:{}', 0, ''),
(3, 1, 0, 'hero', '', 0, 0, 0, '        <!-- Герой -->\n        <section id=\"hero\" class=\"lazy\" data-bg=\"./lpk-2025/img/hero-back.webp\">\n            <div class=\"container\">\n                <div class=\"row flex vcenter\">\n                    <div class=\"col l7 m6 s8 offset-s2 xs12 hero-image\">\n                        <img data-src=\"./lpk-2025/img/hero-fore-new.webp\" class=\"lazy responsive-img\" alt=\"Построй своё будущее в КУБГАУ с 20 июня\">\n                    </div>\n                    <div class=\"col l5 m6 align-right-m-up align-center-m-down\">\n                        <h1>Выбирай с умом: агротех и земледелие, инженерия и IT, экономика и менеджмент, управление, юриспруденция и многое другое ждут тебя в КУБГАУ!</h1>\n                    </div>\n                </div>\n            </div>\n        </section>', 0, 'a:0:{}', 0, ''),
(4, 1, 0, 'about', '', 0, 0, 0, '        <!-- Давай знакомиться -->\n        <section id=\"about\">\n            <div class=\"container\">\n                <div class=\"row\">\n                    <div class=\"col xl4 l12\">\n                        <h2>Давай знакомиться!</h2>\n                    </div>\n                    <div class=\"col xl7 l12\">\n                        <p class=\"large\">\n                            Это КУБГАУ, университет современного образования\n                            с самым большим и удобным кампусом на Юге\n                            России! У наших студентов огромные возможности\n                            для всестороннего развития, а энергии хватает на\n                            всё. Как? Смотри сам:\n                        </p>\n                    </div>\n                </div>\n                <div class=\"row\">\n                    <div class=\"col\">\n                        <div class=\"cards-grid\">\n                            <div class=\"card\" id=\"territory-image\"></div>\n                            <div class=\"card\" id=\"territory-text\">\n                                <h3>Территория вуза</h3>\n                                <p>\n                                    168 га: как 4 Ватикана, 7.5 парков «Краснодар» или 235 футбольных полей\n                                </p>\n                            </div>\n                            <div class=\"card\" id=\"sport\">\n                                <h3>Спортивные возможности</h3>\n                                <p>\n                                    Стадион по стандартам УЕФА , игровые площадки и станции воркаута,\n                                    беговые треки, бассейн, зал киберспорта – качай и разум, и тело\n                                </p>\n                            </div>\n                            <div class=\"card\" id=\"teachers\">\n                                <h3>Про­фес­сор­ско-пре­по­да­ва­тель­ский состав</h3>\n                                <p>\n                                    Один из лучших в стране, и всегда открыт для студентов. Команда преподавателей\n                                    всегда готова проконсультировать, подсказать, поделиться личным опытом\n                                    и помочь определиться с вектором развития\n                                </p>\n                            </div>\n                            <div class=\"card\" id=\"digilab-text\">\n                                <h3>Уникальная Лаборатория цифрового контента</h3>\n                                <p>\n                                    Интерактивная студия для записи контента любой сложности.\n                                    Снимай блоги, пиши подкасты, готовь презентации как Илон Маск!\n                                </p>\n                            </div>\n                            <div class=\"card\" id=\"digilab-image\">\n                                <video data-src=\"./lpk-2025/video/circle-video.mp4\" autoplay autobuffer muted playsinline loop class=\"lazy\"></video>\n                            </div>\n                            <div class=\"card\" id=\"park-image\"></div>\n                            <div class=\"card\" id=\"park-text\">\n                                <h3>Прогулочный парк</h3>\n                                <p>\n                                    Свой, зелёный, с уникальными растениями и прямо на территории кампуса\n                                </p>\n                            </div>\n                        </div>\n                    </div>\n                </div>\n            </div>\n        </section>', 0, 'a:0:{}', 0, ''),
(5, 1, 0, 'features', '', 0, 0, 0, '        <!-- Возможности -->\n        <section id=\"features\">\n            <div class=\"container\">\n                <div class=\"row flex\">\n                    <div class=\"col s12\">\n                        <h2>После КУБГАУ хоть куда!</h2>\n                    </div>\n                    <div class=\"col l6\">\n                        <div class=\"icon-block\">\n                            <div class=\"icon-wrapper hide-m-down\">\n                                <div class=\"square\">\n                                    <img data-src=\"./lpk-2025/img/icons/harvester.webp\" width=\"100\" height=\"100\" alt=\"\" class=\"lazy responsive-img icon\" />\n                                </div>\n                            </div>\n                            <div class=\"content-wrapper\">\n                                <div class=\"feature-header\">\n                                    <div class=\"square mobile hide-m-up\">\n                                        <img data-src=\"./lpk-2025/img/icons/harvester.webp\" width=\"100\" height=\"100\" alt=\"\" class=\"lazy responsive-img icon\" />\n                                    </div>\n                                    <h3>Аграрный сектор</h3>\n                                    <div class=\"arrow-wrapper\">\n                                        <div class=\"arrow\"></div>\n                                    </div>\n                                </div>\n                                <div class=\"feature-content\">\n                                    <p class=\"large\">Фундаментально, инновационно, продуктивно, эстетично и перспективно финансово!</p>\n                                    <p>Селекция и генетика, общая ветеринария, современная агрономия и растениеводство, виноградарство и пищепром: у нас просторно для всех, кто мечтает накормить и сохранить мир! Для тех, кто хочет создавать новое и готов к мировым открытиям, в КУБГАУ развёрнута, пожалуй, лучшая лаборатория биотехнологий на Юге страны. Плюс своя конеферма, поголовье рогатого скота, зоны домашней птицы и многое другое!</p>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                    <div class=\"col l6\">\n                        <div class=\"icon-block\">\n                            <div class=\"icon-wrapper hide-m-down\">\n                                <div class=\"square\">\n                                    <img data-src=\"./lpk-2025/img/icons/helmet.webp\" width=\"100\" height=\"100\" alt=\"\" class=\"lazy responsive-img icon\" />\n                                </div>\n                            </div>\n                            <div class=\"content-wrapper\">\n                                <div class=\"feature-header\">\n                                    <div class=\"square mobile hide-m-up\">\n                                        <img data-src=\"./lpk-2025/img/icons/helmet.webp\" width=\"100\" height=\"100\" alt=\"\" class=\"lazy responsive-img icon\" />\n                                    </div>\n                                    <h3>Инженерия и архитектура</h3>\n                                    <div class=\"arrow-wrapper\">\n                                        <div class=\"arrow\"></div>\n                                    </div>\n                                </div>\n                                <div class=\"feature-content\">\n                                    <p class=\"large\">Созидать — это твоё? Поможем сделать из интереса карьеру!</p>\n                                    <p>Инженерные и архитектурно-строительные специальности — лучший выбор для всех, кто мечтает строить, настраивать и оптимизировать. Если тебе нравится функциональная эстетика, не боишься множества деталей и сложных схем, то в КУБГАУ точно почувствуешь себя на своём месте и получишь широкие возможности для реализации самых технологичных и смелых идей!</p>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                    <div class=\"col l6\">\n                        <div class=\"icon-block\">\n                            <div class=\"icon-wrapper hide-m-down\">\n                                <div class=\"square\">\n                                    <img data-src=\"./lpk-2025/img/icons/briefcase.webp\" width=\"100\" height=\"100\" alt=\"\" class=\"lazy responsive-img icon\" />\n                                </div>\n                            </div>\n                            <div class=\"content-wrapper\">\n                                <div class=\"feature-header\">\n                                    <div class=\"square mobile hide-m-up\">\n                                        <img data-src=\"./lpk-2025/img/icons/briefcase.webp\" width=\"100\" height=\"100\" alt=\"\" class=\"lazy responsive-img icon\" />\n                                    </div>\n                                    <h3>Своё дело</h3>\n                                    <div class=\"arrow-wrapper\">\n                                        <div class=\"arrow\"></div>\n                                    </div>\n                                </div>\n                                <div class=\"feature-content\">\n                                    <p class=\"large\">Любишь всё решать самостоятельно? Дадим возможность!</p>\n                                    <p>Знания и навыки, полученные в вузе, помогут грамотно вести бизнес: от технологических процессов до рекламного продвижения. Уже во время обучения мы даём студентам полезные практические навыки, а кто-то запускает бизнес еще до вручения диплома.</p>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                    <div class=\"col l6\">\n                        <div class=\"icon-block\">\n                            <div class=\"icon-wrapper hide-m-down\">\n                                <div class=\"square\">\n                                    <img data-src=\"./lpk-2025/img/icons/notebook.webp\" width=\"100\" height=\"100\" alt=\"\" class=\"lazy responsive-img icon\" />\n                                </div>\n                            </div>\n                            <div class=\"content-wrapper\">\n                                <div class=\"feature-header\">\n                                    <div class=\"square mobile hide-m-up\">\n                                        <img data-src=\"./lpk-2025/img/icons/notebook.webp\" width=\"100\" height=\"100\" alt=\"\" class=\"lazy responsive-img icon\" />\n                                    </div>\n                                    <h3>Сфера IT</h3>\n                                    <div class=\"arrow-wrapper\">\n                                        <div class=\"arrow\"></div>\n                                    </div>\n                                </div>\n                                <div class=\"feature-content\">\n                                    <p class=\"large\">Войти в IT можно и нужно как можно раньше!</p>\n                                    <p>Учись, набирайся знаний и опыта — база КУБГАУ позволяет делать это эффективно и по последнему слову технологий. Создавай игры и мобильные приложения, пиши программы и оптимизируй бизнес-процессы, работай с big data и не только — тебе всё по-плечу! А наши преподаватели обязательно помогут и поддержат.</p>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                    <div class=\"col l6\">\n                        <div class=\"icon-block\">\n                            <div class=\"icon-wrapper hide-m-down\">\n                                <div class=\"square\">\n                                    <img data-src=\"./lpk-2025/img/icons/globe.webp\" width=\"100\" height=\"100\" alt=\"\" class=\"lazy responsive-img icon\" />\n                                </div>\n                            </div>\n                            <div class=\"content-wrapper\">\n                                <div class=\"feature-header\">\n                                    <div class=\"square mobile hide-m-up\">\n                                        <img data-src=\"./lpk-2025/img/icons/globe.webp\" width=\"100\" height=\"100\" alt=\"\" class=\"lazy responsive-img icon\" />\n                                    </div>\n                                    <h3>Экологическая безопасность</h3>\n                                    <div class=\"arrow-wrapper\">\n                                        <div class=\"arrow\"></div>\n                                    </div>\n                                </div>\n                                <div class=\"feature-content\">\n                                    <p class=\"large\">Хочешь изменить мир? Ты по адресу!</p>\n                                    <p>Социально значимые профессии можно и нужно получать в КУБГАУ. Где, как не в аграрном вузе, получится по-настоящему понять экологию, защитные механизмы Земли и набраться знаний и опыта, чтобы сделать жизнь лучше, а планету чище и безопаснее.</p>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                    <div class=\"col l6\">\n                        <div class=\"icon-block\">\n                            <div class=\"icon-wrapper hide-m-down\">\n                                <div class=\"square\">\n                                    <img data-src=\"./lpk-2025/img/icons/coat-of-arms.webp\" width=\"100\" height=\"100\" alt=\"\" class=\"lazy responsive-img icon\" />\n                                </div>\n                            </div>\n                            <div class=\"content-wrapper\">\n                                <div class=\"feature-header\">\n                                    <div class=\"square mobile hide-m-up\">\n                                        <img data-src=\"./lpk-2025/img/icons/coat-of-arms.webp\" width=\"100\" height=\"100\" alt=\"\" class=\"lazy responsive-img icon\" />\n                                    </div>\n                                    <h3>Госслужба</h3>\n                                    <div class=\"arrow-wrapper\">\n                                        <div class=\"arrow\"></div>\n                                    </div>\n                                </div>\n                                <div class=\"feature-content\">\n                                    <p class=\"large\">Будущее страны в твоих руках!</p>\n                                    <p>Образование в КУБГАУ позволит выпускникам сразу по окончании обучения устроиться на работу в госсектор. Это отличный старт для большой общественной карьеры. Управляющие позиции, законодательные и исполнительные ветви: дороги открыты — мчи к мечте!</p>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                    <div class=\"col l6 offset-l3\">\n                        <div class=\"icon-block\">\n                            <div class=\"icon-wrapper hide-m-down\">\n                                <div class=\"square\">\n                                    <img data-src=\"./lpk-2025/img/icons/vr-helmet.webp\" width=\"100\" height=\"100\" alt=\"\" class=\"lazy responsive-img icon\" />\n                                </div>\n                            </div>\n                            <div class=\"content-wrapper\">\n                                <div class=\"feature-header\">\n                                    <div class=\"square mobile hide-m-up\">\n                                        <img data-src=\"./lpk-2025/img/icons/vr-helmet.webp\" width=\"100\" height=\"100\" alt=\"\" class=\"lazy responsive-img icon\" />\n                                    </div>\n                                    <h3>Передовые технологии</h3>\n                                    <div class=\"arrow-wrapper\">\n                                        <div class=\"arrow\"></div>\n                                    </div>\n                                </div>\n                                <div class=\"feature-content\">\n                                    <p class=\"large\">База для аграрно-технологического суверенитета страны!</p>\n                                    <p>Благодаря «Приоритет-2030» мощный импульс получили high-tech-ветви генетики и биотехнологий. Студенты КУБГАУ ведут исследования и разработки на самом современном и технологичном оборудовании, развивают не только аграрный сектор, но и научный потенциал нашей страны в целом. В КУБГАУ можно получить профессии будущего — присмотрись к ним уже сегодня.</p>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                </div>\n            </div>\n        </section>', 0, 'a:0:{}', 0, ''),
(6, 1, 0, 'networks', '', 0, 0, 0, '        <!-- Сетевые программы -->\n        <section id=\"networks\">\n            <div class=\"container\">\n                <div class=\"row\">\n                    <div class=\"col\">\n                        <h2>Только в КУБГАУ</h2>\n                        <div class=\"slider-wrapper\">\n                            <div class=\"slider-arrow-wrapper aw-prev\">\n                                <div class=\"program-arrow\" id=\"program-prev\"><svg width=\"72\" height=\"163\" viewBox=\"0 0 72 163\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n                                        <path class=\"arrow-bg\" d=\"M35.7598 0C35.7601 32.8784 71.5192 52.3078 71.5195 81.2012C71.5192 110.095 35.7598 129.524 35.7598 162.402C35.7598 129.524 0.000371439 110.095 0 81.2012C0.000371437 52.3078 35.7594 32.8784 35.7598 0Z\" />\n                                        <path class=\"arrow-body\" d=\"M39.6367 59.7941C38.6605 58.8179 37.0779 58.8181 36.1016 59.7941L20.1914 75.7043C19.2151 76.6806 19.2151 78.2631 20.1914 79.2394L36.1016 95.1496C37.0779 96.1256 38.6605 96.1258 39.6367 95.1496C40.6129 94.1734 40.6128 92.5908 39.6367 91.6144L27.9941 79.9718L49.543 79.9719C50.9237 79.9719 52.043 78.8526 52.043 77.4719C52.043 76.0911 50.9237 74.9719 49.543 74.9719L27.9941 74.9719L39.6367 63.3293C40.6128 62.3529 40.6129 60.7703 39.6367 59.7941Z\" />\n                                    </svg>\n                                </div>\n                            </div>\n                            <div class=\"slider-arrow-wrapper aw-next\">\n                                <div class=\"program-arrow\" id=\"program-next\"><svg width=\"72\" height=\"163\" viewBox=\"0 0 72 163\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n                                        <path class=\"arrow-bg\" d=\"M35.7598 0C35.7601 32.8784 71.5192 52.3078 71.5195 81.2012C71.5192 110.095 35.7598 129.524 35.7598 162.402C35.7598 129.524 0.000371439 110.095 0 81.2012C0.000371437 52.3078 35.7594 32.8784 35.7598 0Z\" />\n                                        <path class=\"arrow-body\" d=\"M31.8652 59.7941C32.8415 58.8179 34.4241 58.8181 35.4004 59.7941L51.3105 75.7043C52.2869 76.6806 52.2869 78.2631 51.3105 79.2394L35.4004 95.1496C34.4241 96.1256 32.8415 96.1258 31.8652 95.1496C30.889 94.1734 30.8892 92.5908 31.8652 91.6144L43.5078 79.9718L21.959 79.9719C20.5783 79.9719 19.459 78.8526 19.459 77.4719C19.459 76.0911 20.5783 74.9719 21.959 74.9719L43.5078 74.9719L31.8652 63.3293C30.8892 62.3529 30.889 60.7703 31.8652 59.7941Z\" />\n                                    </svg>\n                                </div>\n                            </div>\n                            <div id=\"programs-slider\" class=\"swiper\">\n                                <div class=\"swiper-wrapper\">\n                                    <div class=\"swiper-slide\">\n                                        <a class=\"image-wrapper card-trigger\" href=\"/?id=44&level=%D0%91%D0%B0%D0%BA%D0%B0%D0%BB%D0%B0%D0%B2%D1%80%D0%B8%D0%B0%D1%82&form=%D0%9E%D1%87%D0%BD%D0%B0%D1%8F\" target=\"_self\" id=\"biotech\">\n                                            <span class=\"name\">Прикладная биотехнология</span>\n\n\n                                            <img class=\"img\" src=\"./lpk-2025/img/programs/biotech.webp\" alt=\"Иллюстрация направления\">\n\n                                            <span class=\"button\">Подробнее</span>\n                                        </a>\n                                        <div class=\"labels-wrapper\">\n\n                                            <div class=\"label label-green\">Новая программа</div>\n\n                                        </div>\n                                        <a class=\"intro card-trigger\" href=\"/?id=44&level=%D0%91%D0%B0%D0%BA%D0%B0%D0%BB%D0%B0%D0%B2%D1%80%D0%B8%D0%B0%D1%82&form=%D0%9E%D1%87%D0%BD%D0%B0%D1%8F\" target=\"_self\">\n                                            Институт ветеринарной медицины, зоотехнии и биотехнологии\n                                        </a>\n                                    </div>\n                                    <div class=\"swiper-slide\">\n                                        <a class=\"image-wrapper card-trigger\" href=\"/?id=74&level=%D0%91%D0%B0%D0%BA%D0%B0%D0%BB%D0%B0%D0%B2%D1%80%D0%B8%D0%B0%D1%82&form=%D0%9E%D1%87%D0%BD%D0%B0%D1%8F\" target=\"_self\" id=\"vine\">\n                                            <span class=\"name\">Промышленное виноделие</span>\n\n\n                                            <img class=\"img\" src=\"./lpk-2025/img/programs/vine.webp\" alt=\"Иллюстрация направления\">\n\n                                            <span class=\"button\">Узнать больше</span>\n                                        </a>\n                                        <div class=\"labels-wrapper\">\n\n                                            <div class=\"label label-green\">Новая программа</div>\n\n                                        </div>\n                                        <a class=\"intro card-trigger\" href=\"/?id=74&level=%D0%91%D0%B0%D0%BA%D0%B0%D0%BB%D0%B0%D0%B2%D1%80%D0%B8%D0%B0%D1%82&form=%D0%9E%D1%87%D0%BD%D0%B0%D1%8F\" target=\"_self\">\n                                            Факультет пищевых технологий\n                                        </a>\n                                    </div>\n                                    <div class=\"swiper-slide\">\n                                        <a class=\"image-wrapper\" href=\"https://cifrek.kubsau.ru/\" target=\"_blank\" id=\"tourism\">\n                                            <span class=\"name\">Умный туризм и развитие территорий</span>\n\n\n                                            <img class=\"img\" src=\"./lpk-2025/img/programs/tourism.webp\" alt=\"Иллюстрация направления\">\n\n                                            <span class=\"button\">О программе</span>\n                                        </a>\n                                        <div class=\"labels-wrapper\">\n\n                                            <div class=\"label label-green\">Новая программа</div>\n\n                                            <div class=\"label label-orange\">Сетевая программа</div>\n\n                                        </div>\n                                        <a class=\"intro\" href=\"https://cifrek.kubsau.ru/\" target=\"_blank\">\n                                            Институт цифровой экономикии инноваций совместно с МГИМО\n                                        </a>\n                                    </div>\n                                    <div class=\"swiper-slide\">\n                                        <a class=\"image-wrapper\" href=\"https://kubsau.ru/finkred_guu/\" target=\"_blank\" id=\"moscow\">\n                                            <span class=\"name\">Финансы и управление бизнесом</span>\n\n\n                                            <img class=\"img\" src=\"./lpk-2025/img/programs/moscow.webp\" alt=\"Иллюстрация направления\">\n\n                                            <span class=\"button\">Подробнее</span>\n                                        </a>\n                                        <div class=\"labels-wrapper\">\n\n                                            <div class=\"label label-orange\">Сетевая программа</div>\n\n                                        </div>\n                                        <a class=\"intro\" href=\"https://kubsau.ru/finkred_guu/\" target=\"_blank\">\n                                            Факультет «Финансы и кредит» совместно с ГУУ\n                                        </a>\n                                    </div>\n                                    <div class=\"swiper-slide\">\n                                        <a class=\"image-wrapper\" href=\"https://kubsau.ru/finkred_spbgeu/\" target=\"_blank\" id=\"spb\">\n                                            <span class=\"name\">Финансы <br />и кредит</span>\n\n\n                                            <img class=\"img\" src=\"./lpk-2025/img/programs/spb.webp\" alt=\"Иллюстрация направления\">\n\n                                            <span class=\"button\">Узнать больше</span>\n                                        </a>\n                                        <div class=\"labels-wrapper\">\n\n                                            <div class=\"label label-orange\">Сетевая программа</div>\n\n                                        </div>\n                                        <a class=\"intro\" href=\"https://kubsau.ru/finkred_spbgeu/\" target=\"_blank\">\n                                            Факультет «Финансы и кредит» совместно с СпбГЭУ\n                                        </a>\n                                    </div>\n                                    <div class=\"swiper-slide\">\n                                        <a class=\"image-wrapper\" href=\"https://cifrek.kubsau.ru/cifrek-mgimo\" target=\"_blank\" id=\"world-agrarium-markets\">\n                                            <span class=\"name\">Цифровая экономика и мировые аграрные рынки</span>\n\n\n                                            <img class=\"img\" src=\"./lpk-2025/img/programs/world-agrarium-markets.webp\" alt=\"Иллюстрация направления\">\n\n                                            <span class=\"button\">О программе</span>\n                                        </a>\n                                        <div class=\"labels-wrapper\">\n\n                                            <div class=\"label label-orange\">Сетевая программа</div>\n\n                                        </div>\n                                        <a class=\"intro\" href=\"https://cifrek.kubsau.ru/cifrek-mgimo\" target=\"_blank\">\n                                            Институт цифровой экономики и инноваций совместно с МГИМО\n                                        </a>\n                                    </div>\n\n                                </div>\n                            </div>\n                        </div>\n                        <div class=\"swiper-pagination\" id=\"programs-pagination\"></div>\n                    </div>\n                </div>\n            </div>\n        </section>', 0, 'a:0:{}', 0, ''),
(7, 1, 0, 'calculator', '', 0, 0, 0, '        <section id=\"calculator\">\n            <div class=\"container\">\n                <div class=\"row\">\n                    <div class=\"col\">\n                        <h2>Узнай, куда поступишь на бюджет!</h2>\n                        <div class=\"calculator-app\" data-level=\"Бакалавриат/специалитет\">\n                            <div class=\"calculator-head\">\n                                <ul class=\"pseudo-tabs\">\n                                    <li class=\"pseudo-tab active\">\n                                        <input type=\"radio\" name=\"level\" id=\"l1\" checked value=\"Бакалавриат/специалитет\" />\n                                        <label for=\"l1\">Бакалавриат/специалитет</label>\n                                    </li>\n                                    <li class=\"pseudo-tab\">\n                                        <input type=\"radio\" name=\"level\" id=\"l2\" value=\"Магистратура\" />\n                                        <label for=\"l2\">Магистратура</label>\n                                    </li>\n                                    <li class=\"pseudo-tab disabled\">\n                                        <!-- <input type=\"radio\" name=\"level\" id=\"l3\" value=\"Аспирантура\"> -->\n                                        <label for=\"l3\">Аспирантура</label>\n                                    </li>\n                                </ul>\n                                <div class=\"quick-search\">\n                                    <input type=\"search\" name=\"search\" placeholder=\"Поиск\" />\n                                </div>\n                            </div>\n                            <div class=\"calculator-body\">\n                                <input type=\"search\" name=\"search\" placeholder=\"Поиск\" class=\"mobile-search\" />\n                                <p class=\"mt0 fogged intro\">\n                                    Выбери свои предметы ЕГЭ (минимум 3) и\n                                    нажми «Применить». Или воспользуйся\n                                    Поиском, если точно знаешь, что искать\n                                </p>\n                                <div class=\"tags\">\n                                    <label class=\"tag\">Русский язык</label><label class=\"tag\">Математика</label><label class=\"tag\">Биология</label><label class=\"tag\">География</label><label class=\"tag\">Обществознание</label><label class=\"tag\">Иностранный язык</label><label class=\"tag\">Информатика</label><label class=\"tag\">История</label><label class=\"tag\">Физика</label><label class=\"tag\">Химия</label>\n                                </div>\n                                <div class=\"actions\">\n                                    <a href=\"javascript:void(0);\" id=\"calc-reset\" class=\"bttn-outline\">Сброс</a>\n                                    <a href=\"javascript:void(0);\" id=\"calc-apply\" class=\"bttn\">Применить</a>\n                                </div>\n                                <h3>Факультеты:</h3>\n                                <div id=\"output\"></div>\n                            </div>\n                        </div>\n                    </div>\n                </div>\n            </div>\n        </section>', 0, 'a:0:{}', 0, ''),
(8, 1, 0, 'task', '', 0, 0, 0, '        <!-- Твоя задача -->\n        <section id=\"task\">\n            <div class=\"container\">\n                <div class=\"row flex\">\n                    <div class=\"col s12\">\n                        <h2>\n                            Твоё первое задание как студента – подать\n                            документы\n                        </h2>\n                    </div>\n                    <div class=\"col l6\">\n                        <h3>Ты можешь сделать это</h3>\n                        <div class=\"row\">\n                            <div class=\"col xl10 offset-xl2\">\n                                <div class=\"icon-block\">\n                                    <div class=\"icon-wrapper\">\n                                        <img data-src=\"./lpk-2025/img/icons/personal.webp\" alt=\"Лично\" class=\"lazy\">\n                                    </div>\n                                    <div class=\"data-wrapper\">\n                                        <div class=\"header\">\n                                            <h4>Лично</h4>\n                                        </div>\n                                        <div class=\"content\">Заглядывай с оригиналами и паспортом в гости! Если с тобой будут родители, то их паспорта тоже будут нужны на входе</div>\n                                    </div>\n                                </div>\n                                <div class=\"icon-block\">\n                                    <div class=\"icon-wrapper\">\n                                        <img data-src=\"./lpk-2025/img/icons/online.webp\" alt=\"Онлайн\" class=\"lazy\">\n                                    </div>\n                                    <div class=\"data-wrapper\">\n                                        <div class=\"header\">\n                                            <h4>Онлайн</h4>\n                                        </div>\n                                        <div class=\"content\">Способ для иностранных студентов поступить без сложностей: <a href=\"https://pk2025.kubsau.ru/registration\" target=\"_blank\">регистрируйся</a> на сайте, подавай документы через Личный кабинет</div>\n                                    </div>\n                                </div>\n                                <div class=\"icon-block\">\n                                    <div class=\"icon-wrapper\">\n                                        <img data-src=\"./lpk-2025/img/icons/mail.webp\" alt=\"По почте\" class=\"lazy\">\n                                    </div>\n                                    <div class=\"data-wrapper\">\n                                        <div class=\"header\">\n                                            <h4>По почте</h4>\n                                        </div>\n                                        <div class=\"content\">Можешь выбрать \"Почту России\", CDEK или любого другого удобного оператора</div>\n                                    </div>\n                                </div>\n                                <div class=\"icon-block\">\n                                    <div class=\"icon-wrapper\">\n                                        <img data-src=\"./lpk-2025/img/icons/gosuslugi.webp\" alt=\"Через Госуслуги\" class=\"lazy\">\n                                    </div>\n                                    <div class=\"data-wrapper\">\n                                        <div class=\"header\">\n                                            <h4>Через Госуслуги</h4>\n                                        </div>\n                                        <div class=\"content\">Быстро, удобно и хоть с мобильного — переходи в раздел <a href=\"https://www.gosuslugi.ru/vuzonline\" target=\"_blank\">«Поступление в вуз онлайн»</a></div>\n                                    </div>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                    <div class=\"col l6\">\n                        <h3>Тебе понадобятся</h3>\n                        <div class=\"col xl10 offset-xl2\">\n                            <div class=\"icon-block\">\n                                <div class=\"icon-wrapper\">\n                                    <img data-src=\"./lpk-2025/img/icons/passport.webp\" alt=\"Паспорт\" class=\"lazy\">\n                                </div>\n                                <div class=\"data-wrapper\">\n                                    <div class=\"header\">\n                                        <h4>Паспорт</h4>\n                                    </div>\n                                    <div class=\"content\">Паспорт гражданина Российской Федерации</div>\n                                </div>\n                            </div>\n                            <div class=\"icon-block\">\n                                <div class=\"icon-wrapper\">\n                                    <img data-src=\"./lpk-2025/img/icons/docs.webp\" alt=\"Документы об образовании\" class=\"lazy\">\n                                </div>\n                                <div class=\"data-wrapper\">\n                                    <div class=\"header\">\n                                        <h4>Документы об образовании</h4>\n                                    </div>\n                                    <div class=\"content\">Аттестат или диплом</div>\n                                </div>\n                            </div>\n                            <div class=\"icon-block\">\n                                <div class=\"icon-wrapper\">\n                                    <img data-src=\"./lpk-2025/img/icons/snils.webp\" alt=\"СНИЛС\" class=\"lazy\">\n                                </div>\n                                <div class=\"data-wrapper\">\n                                    <div class=\"header\">\n                                        <h4>СНИЛС</h4>\n                                    </div>\n                                    <div class=\"content\">Страховой номер индивидуального лицевого счёта</div>\n                                </div>\n                            </div>\n                            <div class=\"icon-block\">\n                                <div class=\"icon-wrapper\">\n                                    <img data-src=\"./lpk-2025/img/icons/photo.webp\" alt=\"Фотографии\" class=\"lazy\">\n                                </div>\n                                <div class=\"data-wrapper\">\n                                    <div class=\"header\">\n                                        <h4>Фотографии</h4>\n                                    </div>\n                                    <div class=\"content\">Фотокарточки 3х4 см (4 шт.)</div>\n                                </div>\n                            </div>\n                            <div class=\"icon-block\">\n                                <div class=\"icon-wrapper\">\n                                    <img data-src=\"./lpk-2025/img/icons/spravka.webp\" alt=\"Справка\" class=\"lazy\">\n                                </div>\n                                <div class=\"data-wrapper\">\n                                    <div class=\"header\">\n                                        <h4>Справка</h4>\n                                    </div>\n                                    <div class=\"content\">Медицинская справка по форме 086/У</div>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                </div>\n            </div>\n        </section>', 0, 'a:0:{}', 0, ''),
(9, 1, 0, 'phone', '', 0, 0, 0, '        <!-- На связи -->\n        <section id=\"phone\">\n            <div class=\"container\">\n                <div class=\"row\">\n                    <div class=\"col xl8 offset-xl2 l10 offset-l1\">\n                        <div class=\"phone-baner banner-section flex z-depth-1 hoverable\">\n                            <p>Многоканальный номер</p>\n                            <h2 class=\"hide-m-up\"><a href=\"tel:+78612215881\" class=\"phone\">+7 (861) 221-58-81</a></h2>\n                            <h2 class=\"hide-m-down\"><span class=\"phone\">+7 (861) 221-58-81</span></h2>\n                            <p class=\"large\">КУБГАУ всегда на связи</p>\n                        </div>\n                    </div>\n                </div>\n            </div>\n        </section>', 0, 'a:0:{}', 0, ''),
(10, 1, 0, 'calendar', '', 0, 0, 0, '        <!-- Календарь -->\n        <section id=\"calendar\">\n            <div class=\"container\">\n                <div class=\"row flex\">\n                    <div class=\"col xl4 l5 m12\">\n                        <div class=\"pin\">\n                            <h2>\n                                Приёмная кампания 2026 вот-вот начнётся!\n                            </h2>\n                            <p>Заскринь график, чтобы ничего не пропустить!</p>\n                            <ul class=\"tabs\">\n                                <li class=\"tab active\">\n                                    <input checked type=\"radio\" name=\"calendar\" value=\"Бакалавриат/специалитет\" id=\"bakalavr\" />\n                                    <label for=\"bakalavr\">Бакалавриат/специалитет</label>\n                                </li>\n                                <li class=\"tab\">\n                                    <input type=\"radio\" name=\"calendar\" value=\"Магистратура\" id=\"magistr\" />\n                                    <label for=\"magistr\">Магистратура</label>\n                                </li>\n                                <li class=\"tab\">\n                                    <input type=\"radio\" name=\"calendar\" value=\"Аспирантура\" id=\"aspirant\" />\n                                    <label for=\"aspirant\">Аспирантура</label>\n                                </li>\n                            </ul>\n                        </div>\n                    </div>\n                    <div class=\"col xl7 offset-xl1 l7 m12\">\n                        <div class=\"calendar-wrapper\" data-section=\"Бакалавриат/специалитет\">\n                            <ul class=\"subtabs\">\n                                <li class=\"tab active\">\n                                    <a href=\"javascript:void(0);\" data-section=\"Бакалавриат/специалитет\" data-form=\"free\">Бюджет</a>\n                                </li>\n                                <li class=\"tab\">\n                                    <a href=\"javascript:void(0);\" data-section=\"Бакалавриат/специалитет\" data-form=\"paid\">Договор\n                                        <i class=\"bx bx-ruble\"></i></a>\n                                </li>\n                            </ul>\n                            <div id=\"calendar-output\"></div>\n                        </div>\n                    </div>\n                </div>\n            </div>\n        </section>', 0, 'a:0:{}', 0, '');
INSERT INTO `modx_site_htmlsnippets` (`id`, `source`, `property_preprocess`, `name`, `description`, `editor_type`, `category`, `cache_type`, `snippet`, `locked`, `properties`, `static`, `static_file`) VALUES
(11, 1, 0, 'bank', '', 0, 0, 0, '        <!-- Кредит -->\n        <section id=\"bank\">\n            <div class=\"row flex vcenter\">\n                <div class=\"col xl7 l6 offset-xl1 offset-l1 m10 offset-m1\">\n                    <div class=\"big-card\">\n                        <div class=\"card-image hide-l-up\"></div>\n                        <div class=\"card-content\">\n                            <div class=\"row flex\">\n                                <div class=\"col\">\n                                    <h2>\n                                        Не упусти время и возможность получить образование!\n                                    </h2>\n                                    <p>\n                                        Если учиться хочется, но прямо сейчас нет возможности оплатить\n                                        обучение, воспользуйся Образовательным кредитом — льготной\n                                        программой с фиксированной ставкой 3% годовых.\n                                    </p>\n                                </div>\n                                <div class=\"col\">\n                                    <h3>Как это работает</h3>\n                                </div>\n                                <div class=\"col xl3 l6 m6 s6 xs12\">\n                                    <figure>\n                                        <img data-src=\"./lpk-2025/img/doc_icon.svg\" alt=\"\" class=\"responsive-img lazy\" />\n                                        <figcaption>\n                                            Ты подписываешь с вузом договор о платном образовании\n                                        </figcaption>\n                                    </figure>\n                                </div>\n                                <div class=\"col xl3 l6 m6 s6 xs12\">\n                                    <figure>\n                                        <img data-src=\"./lpk-2025/img/bank_icon.svg\" alt=\"\" class=\"responsive-img lazy\" />\n                                        <figcaption>\n                                            Выбираешь банк, связываешься с сотрудником\n                                        </figcaption>\n                                    </figure>\n                                </div>\n                                <div class=\"col xl3 l6 m6 s6 xs12\">\n                                    <figure>\n                                        <img data-src=\"./lpk-2025/img/handshake_icon.svg\" alt=\"\" class=\"responsive-img lazy\" />\n                                        <figcaption>Подписываешь кредитный договор</figcaption>\n                                    </figure>\n                                </div>\n                                <div class=\"col xl3 l6 m6 s6 xs12\">\n                                    <figure>\n                                        <img data-src=\"./lpk-2025/img/cash_icon.svg\" alt=\"\" class=\"responsive-img lazy\" />\n                                        <figcaption>\n                                            Банк сам перечислит деньги на счёт вуза\n                                        </figcaption>\n                                    </figure>\n                                </div>\n                                <div class=\"col\">\n                                    <div class=\"banks-wrapper\">\n                                        <p>\n                                            Ознакомься с официальными документами\n                                            нашего банка-партнёра\n                                        </p>\n                                        <div class=\"buttons-wrapper\">\n                                            <a class=\"bank-bttn\" target=\"_blank\" rel=\"nofollow\" href=\"./lpk-2025/files/sber-edu-credit.pdf\" id=\"sber\"><span>Скачать</span><i class=\"bx bxs-download\"></i></a>\n                                        </div>\n                                    </div>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                </div>\n                <div class=\"col xl4 l5 hide-l-down\"></div>\n            </div>\n        </section>', 0, 'a:0:{}', 0, ''),
(12, 1, 0, 'baner', '', 0, 0, 0, '        <!-- Банер -->\n        <section id=\"baner\">\n            <div class=\"container\">\n                <div class=\"banner-home\">\n                    <div class=\"mobile-header\">\n                        <h2>У нас уютно, как и должно быть дома</h2>\n                    </div>\n                    <div class=\"banner-content\">\n                        <div class=\"desktop-header\">\n                            <h2>У нас уютно, как и должно быть дома</h2>\n                        </div>\n                        <div class=\"points\">\n                            <div class=\"point\">\n                                <div class=\"point-image\">\n                                    <img data-src=\"./lpk-2025/img/home_icon-new.webp\" alt=\"\" class=\"lazy responsive-img hide-m-down\" />\n                                </div>\n                                <div class=\"point-content\">\n                                    <div class=\"point-header\">\n                                        <img data-src=\"./lpk-2025/img/home_icon-new.webp\" alt=\"\" class=\"lazy responsive-img hide-m-up\" />\n                                        <h3>Жилье</h3>\n                                    </div>\n                                    <p>\n                                        20 корпусов общежитий находятся на территории университета, а несколько\n                                        минут пешком по самому зелёному кампусу не только полезно, но и приятно.\n                                    </p>\n                                </div>\n                            </div>\n                            <div class=\"point\">\n                                <div class=\"point-image\">\n                                    <img data-src=\"./lpk-2025/img/health_icon-new.webp\" alt=\"\" class=\"lazy responsive-img hide-m-down\" />\n                                </div>\n                                <div class=\"point-content\">\n                                    <div class=\"point-header\">\n                                        <img data-src=\"./lpk-2025/img/health_icon-new.webp\" alt=\"\" class=\"lazy responsive-img hide-m-up\" />\n                                        <h3>Здоровье</h3>\n                                    </div>\n                                    <p>\n                                        Если простудишься, всё под контролем: на территории есть своя\n                                        студенческая поликлиника. Знай, но не болей!\n                                    </p>\n                                </div>\n                            </div>\n                            <div class=\"point\">\n                                <div class=\"point-image\">\n                                    <img data-src=\"./lpk-2025/img/service_icon-new.webp\" alt=\"\" class=\"lazy responsive-img hide-m-down\" />\n                                </div>\n                                <div class=\"point-content\">\n                                    <div class=\"point-header\">\n                                        <img data-src=\"./lpk-2025/img/service_icon-new.webp\" alt=\"\" class=\"lazy responsive-img hide-m-up\" />\n                                        <h3>Сервис</h3>\n                                    </div>\n                                    <p>\n                                        Прачечные и сушильные комнаты, двухэтажная столовая и десятки буфетов по всему\n                                        кампусу, оборудованные кухни в общежитиях: учитесь с комфортом!\n                                    </p>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                    <div class=\"banner-image lazy\" data-bg=\"./lpk-2025/img/students_bg.webp\">\n                        <img data-src=\"./lpk-2025/img/students_fg-new.webp\" alt=\"\" class=\"lazy\" />\n                    </div>\n                </div>\n            </div>\n        </section>', 0, 'a:0:{}', 0, ''),
(13, 1, 0, 'faq', '', 0, 0, 0, '        <!-- FAQ -->\n        <section id=\"faq\">\n            <div class=\"container\">\n                <div class=\"col\">\n                    <h2>Самые популярные вопросы</h2>\n                </div>\n                <div class=\"col\">\n                    <div class=\"faq-entry\">\n                        <div class=\"faq-header waves-effect\">\n                            <h3>Куда поступить на бюджет с моим набором ЕГЭ?</h3>\n                            <div class=\"folder-arrow\"></div>\n                        </div>\n                        <div class=\"faq-content\">\n                            <p class=\"large\">\n                                В КУБГАУ представлено такое большое количество образовательных программ, что в паре слов и не ответить! Лучше воспользуйся <a target=\"_blank\" rel=\"nofollow\" href=\"#calculator\" class=\"scroll-link\">калькулятором ЕГЭ</a> и выбирай не только умом, но и сердцем.\n                            </p>\n                        </div>\n                    </div>\n                    <div class=\"faq-entry\">\n                        <div class=\"faq-header waves-effect\">\n                            <h3>Какой минимальный проходной балл?</h3>\n                            <div class=\"folder-arrow\"></div>\n                        </div>\n                        <div class=\"faq-content\">\n                            <p class=\"large\">\n                                От года к году минимальные баллы разнятся. Самые актуальные (за прошлый год) можно посмотреть <a target=\"_blank\" rel=\"nofollow\" href=\"https://kubsau.ru/upload/iblock/797/wwa1pqzrnk7swaidb8m0jgxj3t21si05.pdf\">здесь</a>.\n                            </p>\n                        </div>\n                    </div>\n                    <div class=\"faq-entry\">\n                        <div class=\"faq-header waves-effect\">\n                            <h3>Что такое «Военная кафедра»?</h3>\n                            <div class=\"folder-arrow\"></div>\n                        </div>\n                        <div class=\"faq-content\">\n                            <p class=\"large\">\n                                Это старое название. У нас действует Военно-учебный Центр, где студенты могут получить военно-учётную специальность, ВУС, и обширный спектр военных навыков. Обучение здесь заменяет прохождение срочной службы.\n                            </p>\n                        </div>\n                    </div>\n                    <div class=\"faq-entry\">\n                        <div class=\"faq-header waves-effect\">\n                            <h3>Какие документы нужны для поступления?</h3>\n                            <div class=\"folder-arrow\"></div>\n                        </div>\n                        <div class=\"faq-content\">\n                            <p class=\"large\">\n                                Возьми с собой или прикрепи к электронному письму сканы паспорта, школьного аттестата или диплома колледжа/вуза, 4 фотографии 3х4 как на паспорт, СНИЛС и медицинскую справку №086/У — это полный пакет, больше ничего не нужно.\n                            </p>\n                        </div>\n                    </div>\n                    <div class=\"faq-entry\">\n                        <div class=\"faq-header waves-effect\">\n                            <h3>За что дают дополнительные баллы для поступления?</h3>\n                            <div class=\"folder-arrow\"></div>\n                        </div>\n                        <div class=\"faq-content\">\n                            <p class=\"large\">\n                                Очень много всего! От золотых медалей в спорте до волонтёрства — полный список читай <a target=\"_blank\" rel=\"nofollow\" href=\"https://kubsau.ru/upload/iblock/4d1/djkt7fhnpz9sdh6y22bpl47fslsvsnc0.pdf\">здесь</a>.\n                            </p>\n                        </div>\n                    </div>\n                    <div class=\"faq-entry\">\n                        <div class=\"faq-header waves-effect\">\n                            <h3>Как быть, если не хватит баллов для бюджета?</h3>\n                            <div class=\"folder-arrow\"></div>\n                        </div>\n                        <div class=\"faq-content\">\n                            <p class=\"large\">\n                                Точно не хватает? Перепроверь по Калькулятору и уточни данные прошлого года. И не забывай о коммерции: можно поступить на первый курс на коммерческой основе, а затем перевестись на бюджет по итогам успеваемости.\n                            </p>\n                        </div>\n                    </div>\n                    <div class=\"faq-entry\">\n                        <div class=\"faq-header waves-effect\">\n                            <h3>Когда можно заселиться в общежитие?</h3>\n                            <div class=\"folder-arrow\"></div>\n                        </div>\n                        <div class=\"faq-content\">\n                            <p class=\"large\">\n                                Практически сразу — комната в одном из 20 общежитий обязательно найдется. К слову, в КУБГАУ 100% студентов обеспечены жильём.\n                            </p>\n                        </div>\n                    </div>\n                    <div class=\"faq-entry\">\n                        <div class=\"faq-header waves-effect\">\n                            <h3>Можно ли работать во время обучения?</h3>\n                            <div class=\"folder-arrow\"></div>\n                        </div>\n                        <div class=\"faq-content\">\n                            <p class=\"large\">\n                                На заочной форме обучения — легко! Наши преподаватели только рады будут, если практика начнется одновременно с теорией. Часто студенты старших курсов заняты в компаниях, где продолжают работать после выпуска. И не беспокойся о «хвостах» — преподаватели идут навстречу усердным.\n                            </p>\n                        </div>\n                    </div>\n                    <div class=\"faq-entry\">\n                        <div class=\"faq-header waves-effect\">\n                            <h3>Что такое «целевые» и «квоты»?</h3>\n                            <div class=\"folder-arrow\"></div>\n                        </div>\n                        <div class=\"faq-content\">\n                            <p class=\"large\">\n                                Это места, закрепляемые заранее в определенном количестве для представителей жестко регламентированных правительством групп лиц с особым статусом и для предприятий, направляющих на обучение будущие кадры. Студенты в таком случае обучаются бесплатно, однако обязаны после получения диплома отработать определенное количество времени в направляющей на обучение организации. Подробнее можно почитать <a target=\"_blank\" rel=\"nofollow\" href=\"https://kubsau.ru/entrant/tselevoe-obuchenie/\">здесь</a>.\n                            </p>\n                        </div>\n                    </div>\n                    <div class=\"faq-entry\">\n                        <div class=\"faq-header waves-effect\">\n                            <h3>Если сдавал ЕГЭ год назад, можно ли поступить в КУБГАУ?</h3>\n                            <div class=\"folder-arrow\"></div>\n                        </div>\n                        <div class=\"faq-content\">\n                            <p class=\"large\">\n                                Конечно, если баллов достаточно! Результаты ЕГЭ действительны 4 года.\n                            </p>\n                        </div>\n                    </div>\n                </div>\n            </div>\n        </section>', 0, 'a:0:{}', 0, ''),
(14, 1, 0, 'docs', '', 0, 0, 0, '        <!-- Документы -->\n        <section id=\"docs-baner\">\n            <div class=\"container\">\n                <div class=\"row flex vcenter\">\n                    <div class=\"col l6 m7 s12\">\n                        <h2>Документы</h2>\n                        <p class=\"large\">\n                            Официальную нормативно-правовую базу можешь скачать\n                            и прочитать на основном сайте КУБГАУ по ссылке\n                        </p>\n                        <a class=\"bttn-white large\" href=\"https://kubsau.ru/entrant/docs/\" rel=\"nofollow\" target=\"_blank\">Cмотреть документы</a>\n                    </div>\n                    <div class=\"col l5 offset-l1 m4 offset-m1 s8 offset-s2 xs12\">\n                        <img class=\"lazy\" data-src=\"./lpk-2025/img/folder.webp\" alt=\"Смотреть документы\">\n                    </div>\n                </div>\n            </div>\n        </section>', 0, 'a:0:{}', 0, ''),
(15, 1, 0, 'contacts', '', 0, 0, 0, '        <!-- Контакты -->\n        <section id=\"contacts\">\n            <div class=\"container\">\n                <div class=\"row\">\n                    <div class=\"col\">\n                        <h2>До встречи в КУБГАУ!</h2>\n                        <p>\n                            Если у тебя остались вопросы, с удовольствием\n                            всё объясним и подробно расскажем: хоть лично,\n                            хоть по телефону или в мессенджере\n                        </p>\n                    </div>\n                    <div class=\"col l5\">\n                        <h4>Звоните</h4>\n                        <div class=\"contacts-wrapper\">\n                            <div class=\"contact\">\n                                <p class=\"title\">\n                                    Горячая линия по вопросам поступления\n                                </p>\n                                <a href=\"tel:+78612215881\"><i class=\"bx bxs-phone\"></i> +7 (861)\n                                    221-58-81</a>\n                            </div>\n                            <div class=\"contact\">\n                                <p class=\"title\">\n                                    Горячая линия по вопросам приёма лиц с\n                                    ограниченными возможностями здоровья и\n                                    инвалидов\n                                </p>\n                                <a href=\"tel:+78612215485\"><i class=\"bx bxs-phone\"></i> +7 (861)\n                                    221-54-85</a>\n                            </div>\n                            <div class=\"contact\">\n                                <p class=\"title\">\n                                    Деканат факультета заочного обучения\n                                </p>\n                                <a href=\"tel:+78612215857\"><i class=\"bx bxs-phone\"></i> +7 (861)\n                                    221-58-57</a>\n                            </div>\n                            <div class=\"contact\">\n                                <p class=\"title\">\n                                    Центр довузовской подготовки\n                                </p>\n                                <a href=\"tel:+78612215817\"><i class=\"bx bxs-phone\"></i>+7 (861)\n                                    221-58-17</a>\n                            </div>\n                        </div>\n                    </div>\n                    <div class=\"col xl2 l3 offset-xl1 m5 s4\">\n                        <h4>Пишите</h4>\n                        <div class=\"contact\">\n                            <p class=\"title\">\n                                Электронная почта приёмной комиссии\n                            </p>\n                            <a href=\"mailto:pk@kubsau.ru\"><i class=\"bx bxs-envelope-open\"></i>\n                                pk@kubsau.ru</a>\n                        </div>\n                    </div>\n                    <div class=\"col xl4 l4 m7 s8\">\n                        <h4>Приезжайте</h4>\n                        <div class=\"contact\">\n                            <p class=\"title\">Ждём вас по адресу</p>\n                            <a href=\"https://yandex.ru/maps/35/krasnodar/?ll=38.933176%2C45.045049&mode=routes&rtext=~45.046639%2C38.928455&rtt=auto&ruri=~&z=16\"><i class=\"bx bxs-map\"></i> 350044, Россия,\n                                г. Краснодар, ул. Калинина, д. 13</a>\n                        </div>\n                        <h5>График работы:</h5>\n                        <div class=\"time-wrapper\">\n                            <div class=\"time\">\n                                <small>пн-пт</small>\n                                <div class=\"time\">9:00 — 16:00</div>\n                            </div>\n                            <div class=\"time\">\n                                <small>сб</small>\n                                <div class=\"time\">9:00 — 12:00</div>\n                            </div>\n                        </div>\n                    </div>\n                </div>\n                <div class=\"row flex vcenter\">\n                    <div class=\"col s9\"></div>\n                    <div class=\"col s3\">\n                        <div class=\"align-right-s-up align-center-s-down\">\n                            <div class=\"social-links\">\n                                <a href=\"https://t.me/priemkubsau\" class=\"social-icon\"><i class=\"bx bxl-telegram\"></i></a>\n                                <a href=\"https://vk.com/priemkubsau?t2fs=c2c214e46fe71ded0f_3\" class=\"social-icon\"><i class=\"bx bxl-vk\"></i></a>\n                                <a href=\"https://max.ru/id2311014546_gos\" class=\"social-icon\"><img src=\"./lpk-2025/img/max.svg\" alt=\"\"></a>\n                            </div>\n                        </div>\n                    </div>\n                </div>\n            </div>\n        </section>', 0, 'a:0:{}', 0, ''),
(16, 1, 0, 'map', '', 0, 0, 0, '        <!-- Карта -->\n        <section id=\"map-section\">\n            <div id=\"map\"></div>\n        </section>', 0, 'a:0:{}', 0, ''),
(17, 1, 0, 'footer', '', 0, 0, 0, '    <!-- Подвал -->\n    <footer class=\"center-align\">\n        <div class=\"row\">\n            <div class=\"col s12\">\n                <a target=\"_blank\" rel=\"nofollow\" href=\"https://kubsau.ru/index-main.php\" class=\"bttn-white\">На основной сайт</a>\n                <a target=\"_blank\" rel=\"nofollow\" href=\"https://kubsau.ru/sveden/common/\" class=\"bttn-outline\"><i>Сведения</i> Об\n                    <span>образовательном </span>учреждении</a>\n            </div>\n        </div>\n        <div class=\"row\">\n            <div class=\"col xl4 offset-xl4 l6 offset-l3 m8 offset-m2 s10 offset-s1 xs12\">\n                <p>\n                    © <span id=\"year\"></span> ФГБОУ ВО «Кубанский\n                    государственный аграрный университет имени\n                    И. Т. Трубилина» 350044, Россия, г. Краснодар,\n                    ул. Калинина, 13\n                </p>\n            </div>\n        </div>\n        <div class=\"row\">\n            <div class=\"col s12\">\n                <a href=\"https://2br.agency\" rel=\"nofollow\" target=\"_blank\">\n                    <img data-src=\"./lpk-2025/img/2br.svg\" alt=\"Брендинг и коммуникации\" class=\"lazy responsive-img\" width=\"70\" />\n                </a>\n            </div>\n            <div class=\"col s12\">\n                <p>\n                    Дизайн страницы –\n                    <a href=\"https://2br.agency\" rel=\"nofollow\" target=\"_blank\" class=\"agency-link\">2br.agency</a>\n                </p>\n            </div>\n        </div>\n    </footer>', 0, 'a:0:{}', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `modx_site_plugins`
--

CREATE TABLE `modx_site_plugins` (
  `id` int(10) UNSIGNED NOT NULL,
  `source` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `property_preprocess` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `editor_type` int(11) NOT NULL DEFAULT '0',
  `category` int(11) NOT NULL DEFAULT '0',
  `cache_type` tinyint(1) NOT NULL DEFAULT '0',
  `plugincode` mediumtext NOT NULL,
  `locked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `properties` text,
  `disabled` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `moduleguid` varchar(32) NOT NULL DEFAULT '',
  `static` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `static_file` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_site_plugins`
--

INSERT INTO `modx_site_plugins` (`id`, `source`, `property_preprocess`, `name`, `description`, `editor_type`, `category`, `cache_type`, `plugincode`, `locked`, `properties`, `disabled`, `moduleguid`, `static`, `static_file`) VALUES
(1, 0, 0, 'Ace', 'Ace code editor plugin for MODx Revolution', 0, 0, 0, '/**\n * Ace Source Editor Plugin\n *\n * Events: OnManagerPageBeforeRender, OnRichTextEditorRegister, OnSnipFormPrerender,\n * OnTempFormPrerender, OnChunkFormPrerender, OnPluginFormPrerender,\n * OnFileCreateFormPrerender, OnFileEditFormPrerender, OnDocFormPrerender\n *\n * @author Danil Kostin <danya.postfactum(at)gmail.com>\n *\n * @package ace\n *\n * @var array $scriptProperties\n * @var Ace $ace\n */\nif ($modx->event->name == \'OnRichTextEditorRegister\') {\n    $modx->event->output(\'Ace\');\n    return;\n}\n\nif ($modx->getOption(\'which_element_editor\', null, \'Ace\') !== \'Ace\') {\n    return;\n}\n\n$corePath = $modx->getOption(\'ace.core_path\', null, $modx->getOption(\'core_path\') . \'components/ace/\');\n$ace = $modx->getService(\'ace\', \'Ace\', $corePath . \'model/ace/\');\n$ace->initialize();\n\n$extensionMap = array(\n    \'tpl\'   => \'text/x-smarty\',\n    \'htm\'   => \'text/html\',\n    \'html\'  => \'text/html\',\n    \'css\'   => \'text/css\',\n    \'scss\'  => \'text/x-scss\',\n    \'less\'  => \'text/x-less\',\n    \'svg\'   => \'image/svg+xml\',\n    \'xml\'   => \'application/xml\',\n    \'xsl\'   => \'application/xml\',\n    \'js\'    => \'application/javascript\',\n    \'json\'  => \'application/json\',\n    \'php\'   => \'application/x-php\',\n    \'sql\'   => \'text/x-sql\',\n    \'md\'    => \'text/x-markdown\',\n    \'txt\'   => \'text/plain\',\n    \'twig\'  => \'text/x-twig\'\n);\n\n// Define default mime for html elements(templates, chunks and html resources)\n$html_elements_mime = $modx->getOption(\'ace.html_elements_mime\', null, false);\nif (!$html_elements_mime) {\n    // this may deprecated in future because components may set ace.html_elements_mime option now\n    switch (true) {\n        case $modx->getOption(\'twiggy_class\'):\n            $html_elements_mime = \'text/x-twig\';\n            break;\n        case $modx->getOption(\'pdotools_fenom_parser\'):\n            $html_elements_mime = \'text/x-smarty\';\n            break;\n        default:\n            $html_elements_mime = \'text/html\';\n    }\n}\n\n// Defines wether we should highlight modx tags\n$modxTags = false;\nswitch ($modx->event->name) {\n    case \'OnSnipFormPrerender\':\n        $field = \'modx-snippet-snippet\';\n        $mimeType = \'application/x-php\';\n        break;\n    case \'OnTempFormPrerender\':\n        $field = \'modx-template-content\';\n        $modxTags = true;\n        $mimeType = $html_elements_mime;\n        break;\n    case \'OnChunkFormPrerender\':\n        $field = \'modx-chunk-snippet\';\n        if ($modx->controller->chunk && $modx->controller->chunk->isStatic()) {\n            $extension = pathinfo($modx->controller->chunk->name, PATHINFO_EXTENSION);\n            if (!$extension || !isset($extensionMap[$extension])) {\n                $extension = pathinfo($modx->controller->chunk->getSourceFile(), PATHINFO_EXTENSION);\n            }\n            $mimeType = isset($extensionMap[$extension]) ? $extensionMap[$extension] : \'text/plain\';\n        } else {\n            $mimeType = $html_elements_mime;\n        }\n        $modxTags = true;\n        break;\n    case \'OnPluginFormPrerender\':\n        $field = \'modx-plugin-plugincode\';\n        $mimeType = \'application/x-php\';\n        break;\n    case \'OnFileCreateFormPrerender\':\n        $field = \'modx-file-content\';\n        $mimeType = \'text/plain\';\n        break;\n    case \'OnFileEditFormPrerender\':\n        $field = \'modx-file-content\';\n        $extension = pathinfo($scriptProperties[\'file\'], PATHINFO_EXTENSION);\n        $mimeType = isset($extensionMap[$extension])\n            ? $extensionMap[$extension]\n            : (\'@FILE:\' . pathinfo($scriptProperties[\'file\'], PATHINFO_BASENAME));\n        $modxTags = $extension == \'tpl\';\n        break;\n    case \'OnDocFormPrerender\':\n        if (!$modx->controller || empty($modx->controller->resourceArray)) {\n            return;\n        }\n        $field = \'ta\';\n        $mimeType = $modx->getObject(\'modContentType\', $modx->controller->resourceArray[\'content_type\'])->get(\'mime_type\');\n\n        if ($mimeType == \'text/html\') {\n            $mimeType = $html_elements_mime;\n        }\n\n        if ($modx->getOption(\'use_editor\')) {\n            $richText = $modx->controller->resourceArray[\'richtext\'];\n            $classKey = $modx->controller->resourceArray[\'class_key\'];\n            if ($richText || in_array($classKey, array(\'modStaticResource\', \'modSymLink\', \'modWebLink\', \'modXMLRPCResource\'))) {\n                $field = false;\n            }\n        }\n        $modxTags = true;\n        break;\n    case \'OnTVInputRenderList\':\n        $modx->event->output($corePath . \'elements/tv/input/\');\n        break;\n    default:\n        return;\n}\n\n$modxTags = (int) $modxTags;\n$script = \'\';\nif (!empty($field)) {\n    $script .= \"MODx.ux.Ace.replaceComponent(\'$field\', \'$mimeType\', $modxTags);\";\n}\n\nif ($modx->event->name == \'OnDocFormPrerender\' && !$modx->getOption(\'use_editor\')) {\n    $script .= \"MODx.ux.Ace.replaceTextAreas(Ext.query(\'.modx-richtext\'));\";\n}\n\nif ($script) {\n    $modx->controller->addHtml(\'<script>Ext.onReady(function() {\' . $script . \'});</script>\');\n}', 0, NULL, 0, '', 0, 'ace/elements/plugins/ace.plugin.php');

-- --------------------------------------------------------

--
-- Table structure for table `modx_site_plugin_events`
--

CREATE TABLE `modx_site_plugin_events` (
  `pluginid` int(10) NOT NULL DEFAULT '0',
  `event` varchar(191) NOT NULL DEFAULT '',
  `priority` int(10) NOT NULL DEFAULT '0',
  `propertyset` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_site_plugin_events`
--

INSERT INTO `modx_site_plugin_events` (`pluginid`, `event`, `priority`, `propertyset`) VALUES
(1, 'OnChunkFormPrerender', 0, 0),
(1, 'OnDocFormPrerender', 0, 0),
(1, 'OnFileCreateFormPrerender', 0, 0),
(1, 'OnFileEditFormPrerender', 0, 0),
(1, 'OnManagerPageBeforeRender', 0, 0),
(1, 'OnPluginFormPrerender', 0, 0),
(1, 'OnRichTextEditorRegister', 0, 0),
(1, 'OnSnipFormPrerender', 0, 0),
(1, 'OnTempFormPrerender', 0, 0),
(1, 'OnTVInputRenderList', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `modx_site_snippets`
--

CREATE TABLE `modx_site_snippets` (
  `id` int(10) UNSIGNED NOT NULL,
  `source` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `property_preprocess` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `editor_type` int(11) NOT NULL DEFAULT '0',
  `category` int(11) NOT NULL DEFAULT '0',
  `cache_type` tinyint(1) NOT NULL DEFAULT '0',
  `snippet` mediumtext,
  `locked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `properties` text,
  `moduleguid` varchar(32) NOT NULL DEFAULT '',
  `static` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `static_file` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_site_templates`
--

CREATE TABLE `modx_site_templates` (
  `id` int(10) UNSIGNED NOT NULL,
  `source` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `property_preprocess` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `templatename` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `editor_type` int(11) NOT NULL DEFAULT '0',
  `category` int(11) NOT NULL DEFAULT '0',
  `icon` varchar(255) NOT NULL DEFAULT '',
  `template_type` int(11) NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  `locked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `properties` text,
  `static` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `static_file` varchar(255) NOT NULL DEFAULT '',
  `preview_file` varchar(191) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_site_templates`
--

INSERT INTO `modx_site_templates` (`id`, `source`, `property_preprocess`, `templatename`, `description`, `editor_type`, `category`, `icon`, `template_type`, `content`, `locked`, `properties`, `static`, `static_file`, `preview_file`) VALUES
(1, 0, 0, 'Начальный шаблон', '', 0, 0, '', 0, '<!doctype html>\n<html lang=\"en\">\n[[$head]]\n<body>\n[[$header]]\n<main>\n[[$hero]]\n[[$about]]\n[[$baner]]\n[[$features]]\n[[$networks]]\n[[$calculator]]\n[[$task]]\n[[$phone]]\n[[$calendar]]\n[[$bank]]\n[[$faq]]\n[[$docs]]\n[[$contacts]]\n[[$map]]\n</main>\n[[$footer]]\n<script src=\"./lpk-2025/js/master.js\"></script>\n</body>\n</html>', 0, 'a:0:{}', 0, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `modx_site_tmplvars`
--

CREATE TABLE `modx_site_tmplvars` (
  `id` int(10) UNSIGNED NOT NULL,
  `source` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `property_preprocess` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `type` varchar(20) NOT NULL DEFAULT '',
  `name` varchar(50) NOT NULL DEFAULT '',
  `caption` varchar(80) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `editor_type` int(11) NOT NULL DEFAULT '0',
  `category` int(11) NOT NULL DEFAULT '0',
  `locked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `elements` text,
  `rank` int(11) NOT NULL DEFAULT '0',
  `display` varchar(20) NOT NULL DEFAULT '',
  `default_text` mediumtext,
  `properties` text,
  `input_properties` text,
  `output_properties` text,
  `static` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `static_file` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_site_tmplvar_access`
--

CREATE TABLE `modx_site_tmplvar_access` (
  `id` int(10) UNSIGNED NOT NULL,
  `tmplvarid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `documentgroup` int(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_site_tmplvar_contentvalues`
--

CREATE TABLE `modx_site_tmplvar_contentvalues` (
  `id` int(10) UNSIGNED NOT NULL,
  `tmplvarid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `contentid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `value` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_site_tmplvar_templates`
--

CREATE TABLE `modx_site_tmplvar_templates` (
  `tmplvarid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `templateid` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `rank` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_system_eventnames`
--

CREATE TABLE `modx_system_eventnames` (
  `name` varchar(50) NOT NULL,
  `service` tinyint(4) UNSIGNED NOT NULL DEFAULT '0',
  `groupname` varchar(20) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_system_eventnames`
--

INSERT INTO `modx_system_eventnames` (`name`, `service`, `groupname`) VALUES
('OnBeforeCacheUpdate', 4, 'System'),
('OnBeforeChunkFormDelete', 1, 'Chunks'),
('OnBeforeChunkFormSave', 1, 'Chunks'),
('OnBeforeDocFormDelete', 1, 'Resources'),
('OnBeforeDocFormSave', 1, 'Resources'),
('OnBeforeEmptyTrash', 1, 'Resources'),
('OnBeforeManagerLogin', 2, 'Security'),
('OnBeforeManagerLogout', 2, 'Security'),
('OnBeforeManagerPageInit', 2, 'System'),
('OnBeforePluginFormDelete', 1, 'Plugins'),
('OnBeforePluginFormSave', 1, 'Plugins'),
('OnBeforeRegisterClientScripts', 5, 'System'),
('OnBeforeSaveWebPageCache', 4, 'System'),
('OnBeforeSnipFormDelete', 1, 'Snippets'),
('OnBeforeSnipFormSave', 1, 'Snippets'),
('OnBeforeTempFormDelete', 1, 'Templates'),
('OnBeforeTempFormSave', 1, 'Templates'),
('OnBeforeTVFormDelete', 1, 'Template Variables'),
('OnBeforeTVFormSave', 1, 'Template Variables'),
('OnBeforeUserActivate', 1, 'Users'),
('OnBeforeUserDeactivate', 1, 'Users'),
('OnBeforeUserDuplicate', 1, 'Users'),
('OnBeforeUserFormDelete', 1, 'Users'),
('OnBeforeUserFormSave', 1, 'Users'),
('OnBeforeUserGroupFormRemove', 1, 'User Groups'),
('OnBeforeUserGroupFormSave', 1, 'User Groups'),
('OnBeforeWebLogin', 3, 'Security'),
('OnBeforeWebLogout', 3, 'Security'),
('OnCacheUpdate', 4, 'System'),
('OnCategoryBeforeRemove', 1, 'Categories'),
('OnCategoryBeforeSave', 1, 'Categories'),
('OnCategoryRemove', 1, 'Categories'),
('OnCategorySave', 1, 'Categories'),
('OnChunkBeforeRemove', 1, 'Chunks'),
('OnChunkBeforeSave', 1, 'Chunks'),
('OnChunkFormDelete', 1, 'Chunks'),
('OnChunkFormPrerender', 1, 'Chunks'),
('OnChunkFormRender', 1, 'Chunks'),
('OnChunkFormSave', 1, 'Chunks'),
('OnChunkRemove', 1, 'Chunks'),
('OnChunkSave', 1, 'Chunks'),
('OnContextBeforeRemove', 1, 'Contexts'),
('OnContextBeforeSave', 1, 'Contexts'),
('OnContextFormPrerender', 2, 'Contexts'),
('OnContextFormRender', 2, 'Contexts'),
('OnContextInit', 1, 'Contexts'),
('OnContextRemove', 1, 'Contexts'),
('OnContextSave', 1, 'Contexts'),
('OnDocFormDelete', 1, 'Resources'),
('OnDocFormPrerender', 1, 'Resources'),
('OnDocFormRender', 1, 'Resources'),
('OnDocFormSave', 1, 'Resources'),
('OnDocPublished', 5, 'Resources'),
('OnDocUnPublished', 5, 'Resources'),
('OnElementNotFound', 1, 'System'),
('OnEmptyTrash', 1, 'Resources'),
('OnFileCreateFormPrerender', 1, 'System'),
('OnFileEditFormPrerender', 1, 'System'),
('OnFileManagerBeforeUpload', 1, 'System'),
('OnFileManagerDirCreate', 1, 'System'),
('OnFileManagerDirRemove', 1, 'System'),
('OnFileManagerDirRename', 1, 'System'),
('OnFileManagerFileCreate', 1, 'System'),
('OnFileManagerFileRemove', 1, 'System'),
('OnFileManagerFileRename', 1, 'System'),
('OnFileManagerFileUpdate', 1, 'System'),
('OnFileManagerMoveObject', 1, 'System'),
('OnFileManagerUpload', 1, 'System'),
('OnHandleRequest', 5, 'System'),
('OnInitCulture', 1, 'Internationalization'),
('OnLoadWebDocument', 5, 'System'),
('OnLoadWebPageCache', 4, 'System'),
('OnManagerAuthentication', 2, 'Security'),
('OnManagerLogin', 2, 'Security'),
('OnManagerLoginFormPrerender', 2, 'Security'),
('OnManagerLoginFormRender', 2, 'Security'),
('OnManagerLogout', 2, 'Security'),
('OnManagerPageAfterRender', 2, 'System'),
('OnManagerPageBeforeRender', 2, 'System'),
('OnManagerPageInit', 2, 'System'),
('OnMediaSourceBeforeFormDelete', 1, 'Media Sources'),
('OnMediaSourceBeforeFormSave', 1, 'Media Sources'),
('OnMediaSourceDuplicate', 1, 'Media Sources'),
('OnMediaSourceFormDelete', 1, 'Media Sources'),
('OnMediaSourceFormSave', 1, 'Media Sources'),
('OnMediaSourceGetProperties', 1, 'Media Sources'),
('OnMODXInit', 5, 'System'),
('OnPackageInstall', 2, 'Package Manager'),
('OnPackageRemove', 2, 'Package Manager'),
('OnPackageUninstall', 2, 'Package Manager'),
('OnPageNotFound', 1, 'System'),
('OnPageUnauthorized', 1, 'Security'),
('OnParseDocument', 5, 'System'),
('OnPluginBeforeRemove', 1, 'Plugins'),
('OnPluginBeforeSave', 1, 'Plugins'),
('OnPluginEventBeforeRemove', 1, 'Plugin Events'),
('OnPluginEventBeforeSave', 1, 'Plugin Events'),
('OnPluginEventRemove', 1, 'Plugin Events'),
('OnPluginEventSave', 1, 'Plugin Events'),
('OnPluginFormDelete', 1, 'Plugins'),
('OnPluginFormPrerender', 1, 'Plugins'),
('OnPluginFormRender', 1, 'Plugins'),
('OnPluginFormSave', 1, 'Plugins'),
('OnPluginRemove', 1, 'Plugins'),
('OnPluginSave', 1, 'Plugins'),
('OnPropertySetBeforeRemove', 1, 'Property Sets'),
('OnPropertySetBeforeSave', 1, 'Property Sets'),
('OnPropertySetRemove', 1, 'Property Sets'),
('OnPropertySetSave', 1, 'Property Sets'),
('OnResourceAddToResourceGroup', 1, 'Resources'),
('OnResourceAutoPublish', 1, 'Resources'),
('OnResourceBeforeSort', 1, 'Resources'),
('OnResourceCacheUpdate', 1, 'Resources'),
('OnResourceDelete', 1, 'Resources'),
('OnResourceDuplicate', 1, 'Resources'),
('OnResourceGroupBeforeRemove', 1, 'Security'),
('OnResourceGroupBeforeSave', 1, 'Security'),
('OnResourceGroupRemove', 1, 'Security'),
('OnResourceGroupSave', 1, 'Security'),
('OnResourceRemoveFromResourceGroup', 1, 'Resources'),
('OnResourceSort', 1, 'Resources'),
('OnResourceToolbarLoad', 1, 'Resources'),
('OnResourceTVFormPrerender', 1, 'Resources'),
('OnResourceTVFormRender', 1, 'Resources'),
('OnResourceUndelete', 1, 'Resources'),
('OnRichTextBrowserInit', 1, 'RichText Editor'),
('OnRichTextEditorInit', 1, 'RichText Editor'),
('OnRichTextEditorRegister', 1, 'RichText Editor'),
('OnSiteRefresh', 1, 'System'),
('OnSiteSettingsRender', 1, 'Settings'),
('OnSnipFormDelete', 1, 'Snippets'),
('OnSnipFormPrerender', 1, 'Snippets'),
('OnSnipFormRender', 1, 'Snippets'),
('OnSnipFormSave', 1, 'Snippets'),
('OnSnippetBeforeRemove', 1, 'Snippets'),
('OnSnippetBeforeSave', 1, 'Snippets'),
('OnSnippetRemove', 1, 'Snippets'),
('OnSnippetSave', 1, 'Snippets'),
('OnTempFormDelete', 1, 'Templates'),
('OnTempFormPrerender', 1, 'Templates'),
('OnTempFormRender', 1, 'Templates'),
('OnTempFormSave', 1, 'Templates'),
('OnTemplateBeforeRemove', 1, 'Templates'),
('OnTemplateBeforeSave', 1, 'Templates'),
('OnTemplateRemove', 1, 'Templates'),
('OnTemplateSave', 1, 'Templates'),
('OnTemplateVarBeforeRemove', 1, 'Template Variables'),
('OnTemplateVarBeforeSave', 1, 'Template Variables'),
('OnTemplateVarRemove', 1, 'Template Variables'),
('OnTemplateVarSave', 1, 'Template Variables'),
('OnTVFormDelete', 1, 'Template Variables'),
('OnTVFormPrerender', 1, 'Template Variables'),
('OnTVFormRender', 1, 'Template Variables'),
('OnTVFormSave', 1, 'Template Variables'),
('OnTVInputPropertiesList', 1, 'Template Variables'),
('OnTVInputRenderList', 1, 'Template Variables'),
('OnTVOutputRenderList', 1, 'Template Variables'),
('OnTVOutputRenderPropertiesList', 1, 'Template Variables'),
('OnUserActivate', 1, 'Users'),
('OnUserAddToGroup', 1, 'User Groups'),
('OnUserBeforeAddToGroup', 1, 'User Groups'),
('OnUserBeforeRemove', 1, 'Users'),
('OnUserBeforeRemoveFromGroup', 1, 'User Groups'),
('OnUserBeforeSave', 1, 'Users'),
('OnUserChangePassword', 1, 'Users'),
('OnUserDeactivate', 1, 'Users'),
('OnUserDuplicate', 1, 'Users'),
('OnUserFormDelete', 1, 'Users'),
('OnUserFormPrerender', 1, 'Users'),
('OnUserFormRender', 1, 'Users'),
('OnUserFormSave', 1, 'Users'),
('OnUserGroupBeforeRemove', 1, 'User Groups'),
('OnUserGroupBeforeSave', 1, 'User Groups'),
('OnUserGroupFormSave', 1, 'User Groups'),
('OnUserGroupRemove', 1, 'User Groups'),
('OnUserGroupSave', 1, 'User Groups'),
('OnUserNotFound', 1, 'Users'),
('OnUserProfileBeforeRemove', 1, 'User Profiles'),
('OnUserProfileBeforeSave', 1, 'User Profiles'),
('OnUserProfileRemove', 1, 'User Profiles'),
('OnUserProfileSave', 1, 'User Profiles'),
('OnUserRemove', 1, 'Users'),
('OnUserRemoveFromGroup', 1, 'User Groups'),
('OnUserSave', 1, 'Users'),
('OnWebAuthentication', 3, 'Security'),
('OnWebLogin', 3, 'Security'),
('OnWebLogout', 3, 'Security'),
('OnWebPageComplete', 5, 'System'),
('OnWebPageInit', 5, 'System'),
('OnWebPagePrerender', 5, 'System');

-- --------------------------------------------------------

--
-- Table structure for table `modx_system_settings`
--

CREATE TABLE `modx_system_settings` (
  `key` varchar(50) NOT NULL DEFAULT '',
  `value` text NOT NULL,
  `xtype` varchar(75) NOT NULL DEFAULT 'textfield',
  `namespace` varchar(40) NOT NULL DEFAULT 'core',
  `area` varchar(255) NOT NULL DEFAULT '',
  `editedon` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_system_settings`
--

INSERT INTO `modx_system_settings` (`key`, `value`, `xtype`, `namespace`, `area`, `editedon`) VALUES
('access_category_enabled', '1', 'combo-boolean', 'core', 'authentication', NULL),
('access_context_enabled', '1', 'combo-boolean', 'core', 'authentication', NULL),
('access_resource_group_enabled', '1', 'combo-boolean', 'core', 'authentication', NULL),
('ace.fold_widgets', '1', 'combo-boolean', 'ace', 'general', NULL),
('ace.font_size', '13px', 'textfield', 'ace', 'general', NULL),
('ace.grow', '', 'textfield', 'ace', 'general', NULL),
('ace.height', '', 'textfield', 'ace', 'general', NULL),
('ace.html_elements_mime', '', 'textfield', 'ace', 'general', NULL),
('ace.show_invisibles', '0', 'combo-boolean', 'ace', 'general', NULL),
('ace.snippets', '', 'textarea', 'ace', 'general', NULL),
('ace.soft_tabs', '1', 'combo-boolean', 'ace', 'general', NULL),
('ace.tab_size', '4', 'textfield', 'ace', 'general', NULL),
('ace.theme', 'chrome', 'textfield', 'ace', 'general', NULL),
('ace.word_wrap', '', 'combo-boolean', 'ace', 'general', NULL),
('allow_forward_across_contexts', '', 'combo-boolean', 'core', 'system', NULL),
('allow_manager_login_forgot_password', '1', 'combo-boolean', 'core', 'authentication', NULL),
('allow_multiple_emails', '1', 'combo-boolean', 'core', 'authentication', NULL),
('allow_tags_in_post', '', 'combo-boolean', 'core', 'system', NULL),
('anonymous_sessions', '1', 'combo-boolean', 'core', 'session', NULL),
('archive_with', '', 'combo-boolean', 'core', 'system', NULL),
('automatic_alias', '1', 'combo-boolean', 'core', 'furls', NULL),
('automatic_template_assignment', 'sibling', 'textfield', 'core', 'site', NULL),
('auto_check_pkg_updates', '1', 'combo-boolean', 'core', 'system', NULL),
('auto_check_pkg_updates_cache_expire', '15', 'numberfield', 'core', 'system', NULL),
('auto_isfolder', '1', 'combo-boolean', 'core', 'site', NULL),
('auto_menuindex', '1', 'combo-boolean', 'core', 'site', NULL),
('base_help_url', '//docs.modx.com/help/', 'textfield', 'core', 'manager', NULL),
('blocked_minutes', '60', 'numberfield', 'core', 'authentication', NULL),
('cache_alias_map', '1', 'combo-boolean', 'core', 'caching', NULL),
('cache_context_settings', '1', 'combo-boolean', 'core', 'caching', NULL),
('cache_db', '', 'combo-boolean', 'core', 'caching', NULL),
('cache_db_expires', '0', 'numberfield', 'core', 'caching', NULL),
('cache_db_session', '', 'combo-boolean', 'core', 'caching', NULL),
('cache_db_session_lifetime', '', 'numberfield', 'core', 'caching', NULL),
('cache_default', '1', 'combo-boolean', 'core', 'caching', NULL),
('cache_expires', '0', 'numberfield', 'core', 'caching', NULL),
('cache_format', '0', 'numberfield', 'core', 'caching', NULL),
('cache_handler', 'xPDO\\Cache\\xPDOFileCache', 'textfield', 'core', 'caching', NULL),
('cache_lang_js', '1', 'combo-boolean', 'core', 'caching', NULL),
('cache_lexicon_topics', '1', 'combo-boolean', 'core', 'caching', NULL),
('cache_noncore_lexicon_topics', '1', 'combo-boolean', 'core', 'caching', NULL),
('cache_resource', '1', 'combo-boolean', 'core', 'caching', NULL),
('cache_resource_clear_partial', '', 'combo-boolean', 'core', 'caching', NULL),
('cache_resource_expires', '0', 'numberfield', 'core', 'caching', NULL),
('cache_scripts', '1', 'combo-boolean', 'core', 'caching', NULL),
('clear_cache_refresh_trees', '', 'combo-boolean', 'core', 'caching', NULL),
('compress_css', '1', 'combo-boolean', 'core', 'manager', NULL),
('compress_js', '1', 'combo-boolean', 'core', 'manager', NULL),
('confirm_navigation', '1', 'combo-boolean', 'core', 'manager', NULL),
('container_suffix', '/', 'textfield', 'core', 'furls', NULL),
('context_tree_sort', '1', 'combo-boolean', 'core', 'manager', NULL),
('context_tree_sortby', 'rank', 'textfield', 'core', 'manager', NULL),
('context_tree_sortdir', 'ASC', 'textfield', 'core', 'manager', NULL),
('cultureKey', 'ru', 'modx-combo-language', 'core', 'language', '2026-06-08 06:28:56'),
('date_timezone', '', 'textfield', 'core', 'system', NULL),
('debug', '', 'numberfield', 'core', 'system', NULL),
('default_content_type', '1', 'modx-combo-content-type', 'core', 'site', NULL),
('default_context', 'web', 'modx-combo-context', 'core', 'site', NULL),
('default_duplicate_publish_option', 'preserve', 'textfield', 'core', 'manager', NULL),
('default_media_source', '1', 'modx-combo-source', 'core', 'manager', NULL),
('default_media_source_type', 'MODX\\Revolution\\Sources\\modFileMediaSource', 'modx-combo-source-type', 'core', 'manager', NULL),
('default_per_page', '20', 'textfield', 'core', 'manager', NULL),
('default_template', '1', 'modx-combo-template', 'core', 'site', NULL),
('default_username', '(anonymous)', 'textfield', 'core', 'session', NULL),
('emailsender', 'masterkadaj@gmail.com', 'textfield', 'core', 'authentication', '2026-06-08 06:28:54'),
('enable_dragdrop', '1', 'combo-boolean', 'core', 'manager', NULL),
('enable_gravatar', '', 'combo-boolean', 'core', 'manager', NULL),
('enable_template_picker_in_tree', '1', 'combo-boolean', 'core', 'manager', NULL),
('error_log_filename', 'error.log', 'textfield', 'core', 'system', NULL),
('error_log_filepath', '', 'textfield', 'core', 'system', NULL),
('error_page', '1', 'numberfield', 'core', 'site', NULL),
('failed_login_attempts', '5', 'numberfield', 'core', 'authentication', NULL),
('feed_modx_news', 'https://feeds.feedburner.com/modx-announce', 'textfield', 'core', 'system', NULL),
('feed_modx_news_enabled', '1', 'combo-boolean', 'core', 'system', NULL),
('feed_modx_security', 'https://forums.modx.com/board.xml?board=294', 'textfield', 'core', 'system', NULL),
('feed_modx_security_enabled', '1', 'combo-boolean', 'core', 'system', NULL),
('form_customization_use_all_groups', '', 'combo-boolean', 'core', 'manager', NULL),
('forward_merge_excludes', 'type,published,class_key', 'textfield', 'core', 'system', NULL),
('friendly_alias_lowercase_only', '1', 'combo-boolean', 'core', 'furls', NULL),
('friendly_alias_max_length', '0', 'numberfield', 'core', 'furls', NULL),
('friendly_alias_realtime', '', 'combo-boolean', 'core', 'furls', NULL),
('friendly_alias_restrict_chars', 'pattern', 'textfield', 'core', 'furls', NULL),
('friendly_alias_restrict_chars_pattern', '/[\\0\\x0B\\t\\n\\r\\f\\a&=+%#<>\"~:`@\\?\\[\\]\\{\\}\\|\\^\'\\\\]/', 'textfield', 'core', 'furls', NULL),
('friendly_alias_strip_element_tags', '1', 'combo-boolean', 'core', 'furls', NULL),
('friendly_alias_translit', 'none', 'textfield', 'core', 'furls', NULL),
('friendly_alias_translit_class', 'translit.modTransliterate', 'textfield', 'core', 'furls', NULL),
('friendly_alias_translit_class_path', '{core_path}components/', 'textfield', 'core', 'furls', NULL),
('friendly_alias_trim_chars', '/.-_', 'textfield', 'core', 'furls', NULL),
('friendly_alias_word_delimiter', '-', 'textfield', 'core', 'furls', NULL),
('friendly_alias_word_delimiters', '-_', 'textfield', 'core', 'furls', NULL),
('friendly_urls', '', 'combo-boolean', 'core', 'furls', NULL),
('friendly_urls_strict', '', 'combo-boolean', 'core', 'furls', NULL),
('global_duplicate_uri_check', '', 'combo-boolean', 'core', 'furls', NULL),
('hidemenu_default', '', 'combo-boolean', 'core', 'site', NULL),
('inline_help', '1', 'combo-boolean', 'core', 'manager', NULL),
('link_tag_scheme', '-1', 'textfield', 'core', 'site', NULL),
('locale', '', 'textfield', 'core', 'language', NULL),
('lock_ttl', '360', 'numberfield', 'core', 'system', NULL),
('login_background_image', '', 'textfield', 'core', 'authentication', NULL),
('login_help_button', '', 'combo-boolean', 'core', 'authentication', NULL),
('login_logo', '', 'textfield', 'core', 'authentication', NULL),
('log_deprecated', '1', 'combo-boolean', 'core', 'system', NULL),
('log_level', '1', 'numberfield', 'core', 'system', NULL),
('log_snippet_not_found', '1', 'combo-boolean', 'core', 'site', NULL),
('log_target', 'FILE', 'textfield', 'core', 'system', NULL),
('mail_charset', 'UTF-8', 'modx-combo-charset', 'core', 'mail', NULL),
('mail_dkim_domain', '', 'textfield', 'core', 'mail', NULL),
('mail_dkim_identity', '', 'textfield', 'core', 'mail', NULL),
('mail_dkim_passphrase', '', 'text-password', 'core', 'mail', NULL),
('mail_dkim_privatekeyfile', '', 'textfield', 'core', 'mail', NULL),
('mail_dkim_privatekeystring', '', 'textfield', 'core', 'mail', NULL),
('mail_dkim_selector', '', 'textfield', 'core', 'mail', NULL),
('mail_encoding', '8bit', 'textfield', 'core', 'mail', NULL),
('mail_inlinestyle_inline', '1', 'combo-boolean', 'core', 'mail', NULL),
('mail_inlinestyle_remove_style_tags', '', 'combo-boolean', 'core', 'mail', NULL),
('mail_smtp_auth', '', 'combo-boolean', 'core', 'mail', NULL),
('mail_smtp_autotls', '1', 'combo-boolean', 'core', 'mail', NULL),
('mail_smtp_helo', '', 'textfield', 'core', 'mail', NULL),
('mail_smtp_hosts', 'localhost', 'textfield', 'core', 'mail', NULL),
('mail_smtp_keepalive', '', 'combo-boolean', 'core', 'mail', NULL),
('mail_smtp_pass', '', 'text-password', 'core', 'mail', NULL),
('mail_smtp_port', '587', 'numberfield', 'core', 'mail', NULL),
('mail_smtp_secure', '', 'textfield', 'core', 'mail', NULL),
('mail_smtp_single_to', '', 'combo-boolean', 'core', 'mail', NULL),
('mail_smtp_timeout', '10', 'numberfield', 'core', 'mail', NULL),
('mail_smtp_user', '', 'textfield', 'core', 'mail', NULL),
('mail_use_smtp', '', 'combo-boolean', 'core', 'mail', NULL),
('main_nav_parent', 'topnav', 'textfield', 'core', 'manager', NULL),
('manager_datetime_empty_value', '—', 'textfield', 'core', 'manager', NULL),
('manager_datetime_separator', ', ', 'textfield', 'core', 'manager', NULL),
('manager_date_format', 'Y-m-d', 'textfield', 'core', 'manager', NULL),
('manager_direction', 'ltr', 'textfield', 'core', 'language', NULL),
('manager_favicon_url', 'favicon.ico', 'textfield', 'core', 'manager', NULL),
('manager_login_url_alternate', '', 'textfield', 'core', 'authentication', NULL),
('manager_logo', '', 'textfield', 'core', 'manager', NULL),
('manager_theme', 'default', 'modx-combo-manager-theme', 'core', 'manager', NULL),
('manager_time_format', 'H:i', 'textfield', 'core', 'manager', NULL),
('manager_tooltip_delay', '2300', 'numberfield', 'core', 'manager', NULL),
('manager_tooltip_enable', '1', 'combo-boolean', 'core', 'manager', NULL),
('manager_use_fullname', '', 'combo-boolean', 'core', 'manager', NULL),
('manager_week_start', '0', 'numberfield', 'core', 'manager', NULL),
('mgr_source_icon', 'icon-folder-open-o', 'textfield', 'core', 'manager', NULL),
('mgr_tree_icon_context', 'tree-context', 'textfield', 'core', 'manager', NULL),
('modx_browser_default_sort', 'name', 'textfield', 'core', 'manager', NULL),
('modx_browser_default_viewmode', 'grid', 'textfield', 'core', 'manager', NULL),
('modx_browser_tree_hide_files', '1', 'combo-boolean', 'core', 'manager', NULL),
('modx_browser_tree_hide_tooltips', '1', 'combo-boolean', 'core', 'manager', NULL),
('modx_charset', 'UTF-8', 'modx-combo-charset', 'core', 'language', NULL),
('package_installer_at_top', '1', 'combo-boolean', 'core', 'manager', NULL),
('parser_recurse_uncacheable', '1', 'combo-boolean', 'core', 'system', NULL),
('passwordless_activated', '', 'combo-boolean', 'core', 'authentication', NULL),
('passwordless_expiration', '3600', 'textfield', 'core', 'authentication', NULL),
('password_generated_length', '16', 'numberfield', 'core', 'authentication', NULL),
('password_min_length', '12', 'numberfield', 'core', 'authentication', NULL),
('phpthumb_allow_src_above_docroot', '', 'combo-boolean', 'core', 'phpthumb', NULL),
('phpthumb_cache_maxage', '30', 'numberfield', 'core', 'phpthumb', NULL),
('phpthumb_cache_maxfiles', '10000', 'numberfield', 'core', 'phpthumb', NULL),
('phpthumb_cache_maxsize', '100', 'numberfield', 'core', 'phpthumb', NULL),
('phpthumb_cache_source_enabled', '', 'combo-boolean', 'core', 'phpthumb', NULL),
('phpthumb_document_root', '', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_error_bgcolor', 'CCCCFF', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_error_fontsize', '1', 'numberfield', 'core', 'phpthumb', NULL),
('phpthumb_error_textcolor', 'FF0000', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_far', 'C', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_imagemagick_path', '', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_nohotlink_enabled', '1', 'combo-boolean', 'core', 'phpthumb', NULL),
('phpthumb_nohotlink_erase_image', '1', 'combo-boolean', 'core', 'phpthumb', NULL),
('phpthumb_nohotlink_text_message', 'Off-server thumbnailing is not allowed', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_nohotlink_valid_domains', '{http_host}', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_nooffsitelink_enabled', '', 'combo-boolean', 'core', 'phpthumb', NULL),
('phpthumb_nooffsitelink_erase_image', '1', 'combo-boolean', 'core', 'phpthumb', NULL),
('phpthumb_nooffsitelink_require_refer', '', 'combo-boolean', 'core', 'phpthumb', NULL),
('phpthumb_nooffsitelink_text_message', 'Off-server linking is not allowed', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_nooffsitelink_valid_domains', '{http_host}', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_nooffsitelink_watermark_src', '', 'textfield', 'core', 'phpthumb', NULL),
('phpthumb_zoomcrop', '0', 'textfield', 'core', 'phpthumb', NULL),
('preserve_menuindex', '', 'combo-boolean', 'core', 'manager', NULL),
('principal_targets', 'MODX\\Revolution\\modAccessContext,MODX\\Revolution\\modAccessResourceGroup,MODX\\Revolution\\modAccessCategory,MODX\\Revolution\\Sources\\modAccessMediaSource,MODX\\Revolution\\modAccessNamespace', 'textfield', 'core', 'authentication', NULL),
('proxy_auth_type', 'BASIC', 'textfield', 'core', 'proxy', NULL),
('proxy_host', '', 'textfield', 'core', 'proxy', NULL),
('proxy_password', '', 'text-password', 'core', 'proxy', NULL),
('proxy_port', '', 'numberfield', 'core', 'proxy', NULL),
('proxy_username', '', 'textfield', 'core', 'proxy', NULL),
('publish_default', '', 'combo-boolean', 'core', 'site', NULL),
('quick_search_in_content', '1', 'combo-boolean', 'core', 'manager', NULL),
('quick_search_result_max', '10', 'numberfield', 'core', 'manager', NULL),
('request_controller', 'index.php', 'textfield', 'core', 'gateway', NULL),
('request_method_strict', '', 'combo-boolean', 'core', 'gateway', NULL),
('request_param_alias', 'q', 'textfield', 'core', 'gateway', NULL),
('request_param_id', 'id', 'textfield', 'core', 'gateway', NULL),
('resource_static_allow_absolute', '0', 'combo-boolean', 'core', 'static_resources', NULL),
('resource_static_path', '{assets_path}', 'textfield', 'core', 'static_resources', NULL),
('resource_tree_node_name', 'pagetitle', 'textfield', 'core', 'manager', NULL),
('resource_tree_node_name_fallback', 'alias', 'textfield', 'core', 'manager', NULL),
('resource_tree_node_tooltip', '', 'textfield', 'core', 'manager', NULL),
('richtext_default', '1', 'combo-boolean', 'core', 'manager', NULL),
('search_default', '1', 'combo-boolean', 'core', 'site', NULL),
('send_poweredby_header', '1', 'combo-boolean', 'core', 'system', '2026-06-08 06:28:56'),
('server_offset_time', '0', 'numberfield', 'core', 'system', NULL),
('session_cookie_domain', '', 'textfield', 'core', 'session', NULL),
('session_cookie_httponly', '1', 'combo-boolean', 'core', 'session', NULL),
('session_cookie_lifetime', '604800', 'numberfield', 'core', 'session', NULL),
('session_cookie_path', '', 'textfield', 'core', 'session', NULL),
('session_cookie_samesite', '', 'textfield', 'core', 'session', NULL),
('session_cookie_secure', '', 'combo-boolean', 'core', 'session', NULL),
('session_gc_maxlifetime', '604800', 'textfield', 'core', 'session', NULL),
('session_handler_class', 'MODX\\Revolution\\modSessionHandler', 'textfield', 'core', 'session', NULL),
('session_name', '', 'textfield', 'core', 'session', NULL),
('settings_distro', 'traditional', 'textfield', 'core', 'system', NULL),
('settings_version', '3.2.1-pl', 'textfield', 'core', 'system', NULL),
('set_header', '1', 'combo-boolean', 'core', 'system', NULL),
('show_tv_categories_header', '1', 'combo-boolean', 'core', 'manager', NULL),
('site_name', 'MODX Revolution', 'textfield', 'core', 'site', NULL),
('site_start', '1', 'numberfield', 'core', 'site', NULL),
('site_status', '1', 'combo-boolean', 'core', 'site', NULL),
('site_unavailable_message', '[[%site_unavailable_message]]', 'textfield', 'core', 'site', NULL),
('site_unavailable_page', '0', 'numberfield', 'core', 'site', NULL),
('static_elements_automate_chunks', '', 'combo-boolean', 'core', 'static_elements', NULL),
('static_elements_automate_plugins', '', 'combo-boolean', 'core', 'static_elements', NULL),
('static_elements_automate_snippets', '', 'combo-boolean', 'core', 'static_elements', NULL),
('static_elements_automate_templates', '', 'combo-boolean', 'core', 'static_elements', NULL),
('static_elements_automate_tvs', '', 'combo-boolean', 'core', 'static_elements', NULL),
('static_elements_basepath', '', 'textfield', 'core', 'static_elements', NULL),
('static_elements_default_category', '0', 'modx-combo-category', 'core', 'static_elements', NULL),
('static_elements_default_mediasource', '0', 'modx-combo-source', 'core', 'static_elements', NULL),
('static_elements_html_extension', '.tpl', 'textfield', 'core', 'static_elements', NULL),
('symlink_merge_fields', '1', 'combo-boolean', 'core', 'site', NULL),
('syncsite_default', '1', 'combo-boolean', 'core', 'caching', NULL),
('topmenu_show_descriptions', '1', 'combo-boolean', 'core', 'manager', NULL),
('tree_default_sort', 'menuindex', 'textfield', 'core', 'manager', NULL),
('tree_root_id', '0', 'numberfield', 'core', 'manager', NULL),
('tvs_below_content', '', 'combo-boolean', 'core', 'manager', NULL),
('unauthorized_page', '1', 'numberfield', 'core', 'site', NULL),
('upload_files', 'aac,au,avi,bmp,css,css.map,doc,docx,eot,gif,gz,htm,html,ico,jpeg,jpg,js,js.map,less,md,mp3,mp4,mpeg,mpg,odb,odf,odg,odp,ods,odt,pdf,png,ppt,pptx,psd,rar,scss,svg,svgz,tar,tgz,tiff,ttf,txt,wav,webp,wmv,woff,woff2,xls,xlsx,xml,z,zip', 'textfield', 'core', 'file', NULL),
('upload_file_exists', '1', 'combo-boolean', 'core', 'file', NULL),
('upload_maxsize', '67108864', 'numberfield', 'core', 'file', '2026-06-08 06:28:56'),
('upload_translit', '1', 'combo-boolean', 'core', 'file', NULL),
('upload_translit_restrict_chars_pattern', '/[\\0\\x0B\\t\\n\\r\\f\\a&=+%#<>\"~:`@\\?\\[\\]\\{\\}\\|\\^\'\\\\]/', 'textfield', 'core', 'file', NULL),
('user_nav_parent', 'usernav', 'textfield', 'core', 'manager', NULL),
('use_alias_path', '', 'combo-boolean', 'core', 'furls', NULL),
('use_context_resource_table', '1', 'combo-boolean', 'core', 'caching', NULL),
('use_editor', '1', 'combo-boolean', 'core', 'editor', NULL),
('use_frozen_parent_uris', '', 'combo-boolean', 'core', 'furls', NULL),
('use_multibyte', '1', 'combo-boolean', 'core', 'language', '2026-06-08 06:28:56'),
('use_weblink_target', '', 'combo-boolean', 'core', 'site', NULL),
('welcome_action', 'welcome', 'textfield', 'core', 'manager', NULL),
('welcome_namespace', 'core', 'textfield', 'core', 'manager', NULL),
('welcome_screen', '', 'combo-boolean', 'core', 'manager', '2026-06-08 06:29:35'),
('welcome_screen_url', '//misc.modx.com/revolution/welcome.32.html', 'textfield', 'core', 'manager', NULL),
('which_editor', '', 'modx-combo-rte', 'core', 'editor', NULL),
('which_element_editor', 'Ace', 'modx-combo-rte', 'core', 'editor', '2026-06-08 06:44:26'),
('xhtml_urls', '1', 'combo-boolean', 'core', 'site', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `modx_transport_packages`
--

CREATE TABLE `modx_transport_packages` (
  `signature` varchar(191) NOT NULL,
  `created` datetime NOT NULL,
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `installed` datetime DEFAULT NULL,
  `state` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `workspace` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `provider` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `disabled` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `source` tinytext,
  `manifest` text,
  `attributes` mediumtext,
  `package_name` varchar(191) NOT NULL,
  `metadata` text,
  `version_major` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `version_minor` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `version_patch` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `release` varchar(100) NOT NULL DEFAULT '',
  `release_index` smallint(5) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_transport_packages`
--

INSERT INTO `modx_transport_packages` (`signature`, `created`, `updated`, `installed`, `state`, `workspace`, `provider`, `disabled`, `source`, `manifest`, `attributes`, `package_name`, `metadata`, `version_major`, `version_minor`, `version_patch`, `release`, `release_index`) VALUES
('ace-1.9.8-pl', '2026-06-08 09:42:03', '2026-06-08 06:44:26', '2026-06-08 09:44:26', 0, 1, 1, 0, 'ace-1.9.8-pl.transport.zip', NULL, 'a:8:{s:7:\"license\";s:15218:\"GNU GENERAL PUBLIC LICENSE\n   Version 2, June 1991\n--------------------------\n\nCopyright (C) 1989, 1991 Free Software Foundation, Inc.\n59 Temple Place, Suite 330, Boston, MA  02111-1307  USA\n\nEveryone is permitted to copy and distribute verbatim copies\nof this license document, but changing it is not allowed.\n\nPreamble\n--------\n\n  The licenses for most software are designed to take away your\nfreedom to share and change it.  By contrast, the GNU General Public\nLicense is intended to guarantee your freedom to share and change free\nsoftware--to make sure the software is free for all its users.  This\nGeneral Public License applies to most of the Free Software\nFoundation\'s software and to any other program whose authors commit to\nusing it.  (Some other Free Software Foundation software is covered by\nthe GNU Library General Public License instead.)  You can apply it to\nyour programs, too.\n\n  When we speak of free software, we are referring to freedom, not\nprice.  Our General Public Licenses are designed to make sure that you\nhave the freedom to distribute copies of free software (and charge for\nthis service if you wish), that you receive source code or can get it\nif you want it, that you can change the software or use pieces of it\nin new free programs; and that you know you can do these things.\n\n  To protect your rights, we need to make restrictions that forbid\nanyone to deny you these rights or to ask you to surrender the rights.\nThese restrictions translate to certain responsibilities for you if you\ndistribute copies of the software, or if you modify it.\n\n  For example, if you distribute copies of such a program, whether\ngratis or for a fee, you must give the recipients all the rights that\nyou have.  You must make sure that they, too, receive or can get the\nsource code.  And you must show them these terms so they know their\nrights.\n\n  We protect your rights with two steps: (1) copyright the software, and\n(2) offer you this license which gives you legal permission to copy,\ndistribute and/or modify the software.\n\n  Also, for each author\'s protection and ours, we want to make certain\nthat everyone understands that there is no warranty for this free\nsoftware.  If the software is modified by someone else and passed on, we\nwant its recipients to know that what they have is not the original, so\nthat any problems introduced by others will not reflect on the original\nauthors\' reputations.\n\n  Finally, any free program is threatened constantly by software\npatents.  We wish to avoid the danger that redistributors of a free\nprogram will individually obtain patent licenses, in effect making the\nprogram proprietary.  To prevent this, we have made it clear that any\npatent must be licensed for everyone\'s free use or not licensed at all.\n\n  The precise terms and conditions for copying, distribution and\nmodification follow.\n\n\nGNU GENERAL PUBLIC LICENSE\nTERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION\n---------------------------------------------------------------\n\n  0. This License applies to any program or other work which contains\na notice placed by the copyright holder saying it may be distributed\nunder the terms of this General Public License.  The \"Program\", below,\nrefers to any such program or work, and a \"work based on the Program\"\nmeans either the Program or any derivative work under copyright law:\nthat is to say, a work containing the Program or a portion of it,\neither verbatim or with modifications and/or translated into another\nlanguage.  (Hereinafter, translation is included without limitation in\nthe term \"modification\".)  Each licensee is addressed as \"you\".\n\nActivities other than copying, distribution and modification are not\ncovered by this License; they are outside its scope.  The act of\nrunning the Program is not restricted, and the output from the Program\nis covered only if its contents constitute a work based on the\nProgram (independent of having been made by running the Program).\nWhether that is true depends on what the Program does.\n\n  1. You may copy and distribute verbatim copies of the Program\'s\nsource code as you receive it, in any medium, provided that you\nconspicuously and appropriately publish on each copy an appropriate\ncopyright notice and disclaimer of warranty; keep intact all the\nnotices that refer to this License and to the absence of any warranty;\nand give any other recipients of the Program a copy of this License\nalong with the Program.\n\nYou may charge a fee for the physical act of transferring a copy, and\nyou may at your option offer warranty protection in exchange for a fee.\n\n  2. You may modify your copy or copies of the Program or any portion\nof it, thus forming a work based on the Program, and copy and\ndistribute such modifications or work under the terms of Section 1\nabove, provided that you also meet all of these conditions:\n\n    a) You must cause the modified files to carry prominent notices\n    stating that you changed the files and the date of any change.\n\n    b) You must cause any work that you distribute or publish, that in\n    whole or in part contains or is derived from the Program or any\n    part thereof, to be licensed as a whole at no charge to all third\n    parties under the terms of this License.\n\n    c) If the modified program normally reads commands interactively\n    when run, you must cause it, when started running for such\n    interactive use in the most ordinary way, to print or display an\n    announcement including an appropriate copyright notice and a\n    notice that there is no warranty (or else, saying that you provide\n    a warranty) and that users may redistribute the program under\n    these conditions, and telling the user how to view a copy of this\n    License.  (Exception: if the Program itself is interactive but\n    does not normally print such an announcement, your work based on\n    the Program is not required to print an announcement.)\n\nThese requirements apply to the modified work as a whole.  If\nidentifiable sections of that work are not derived from the Program,\nand can be reasonably considered independent and separate works in\nthemselves, then this License, and its terms, do not apply to those\nsections when you distribute them as separate works.  But when you\ndistribute the same sections as part of a whole which is a work based\non the Program, the distribution of the whole must be on the terms of\nthis License, whose permissions for other licensees extend to the\nentire whole, and thus to each and every part regardless of who wrote it.\n\nThus, it is not the intent of this section to claim rights or contest\nyour rights to work written entirely by you; rather, the intent is to\nexercise the right to control the distribution of derivative or\ncollective works based on the Program.\n\nIn addition, mere aggregation of another work not based on the Program\nwith the Program (or with a work based on the Program) on a volume of\na storage or distribution medium does not bring the other work under\nthe scope of this License.\n\n  3. You may copy and distribute the Program (or a work based on it,\nunder Section 2) in object code or executable form under the terms of\nSections 1 and 2 above provided that you also do one of the following:\n\n    a) Accompany it with the complete corresponding machine-readable\n    source code, which must be distributed under the terms of Sections\n    1 and 2 above on a medium customarily used for software interchange; or,\n\n    b) Accompany it with a written offer, valid for at least three\n    years, to give any third party, for a charge no more than your\n    cost of physically performing source distribution, a complete\n    machine-readable copy of the corresponding source code, to be\n    distributed under the terms of Sections 1 and 2 above on a medium\n    customarily used for software interchange; or,\n\n    c) Accompany it with the information you received as to the offer\n    to distribute corresponding source code.  (This alternative is\n    allowed only for noncommercial distribution and only if you\n    received the program in object code or executable form with such\n    an offer, in accord with Subsection b above.)\n\nThe source code for a work means the preferred form of the work for\nmaking modifications to it.  For an executable work, complete source\ncode means all the source code for all modules it contains, plus any\nassociated interface definition files, plus the scripts used to\ncontrol compilation and installation of the executable.  However, as a\nspecial exception, the source code distributed need not include\nanything that is normally distributed (in either source or binary\nform) with the major components (compiler, kernel, and so on) of the\noperating system on which the executable runs, unless that component\nitself accompanies the executable.\n\nIf distribution of executable or object code is made by offering\naccess to copy from a designated place, then offering equivalent\naccess to copy the source code from the same place counts as\ndistribution of the source code, even though third parties are not\ncompelled to copy the source along with the object code.\n\n  4. You may not copy, modify, sublicense, or distribute the Program\nexcept as expressly provided under this License.  Any attempt\notherwise to copy, modify, sublicense or distribute the Program is\nvoid, and will automatically terminate your rights under this License.\nHowever, parties who have received copies, or rights, from you under\nthis License will not have their licenses terminated so long as such\nparties remain in full compliance.\n\n  5. You are not required to accept this License, since you have not\nsigned it.  However, nothing else grants you permission to modify or\ndistribute the Program or its derivative works.  These actions are\nprohibited by law if you do not accept this License.  Therefore, by\nmodifying or distributing the Program (or any work based on the\nProgram), you indicate your acceptance of this License to do so, and\nall its terms and conditions for copying, distributing or modifying\nthe Program or works based on it.\n\n  6. Each time you redistribute the Program (or any work based on the\nProgram), the recipient automatically receives a license from the\noriginal licensor to copy, distribute or modify the Program subject to\nthese terms and conditions.  You may not impose any further\nrestrictions on the recipients\' exercise of the rights granted herein.\nYou are not responsible for enforcing compliance by third parties to\nthis License.\n\n  7. If, as a consequence of a court judgment or allegation of patent\ninfringement or for any other reason (not limited to patent issues),\nconditions are imposed on you (whether by court order, agreement or\notherwise) that contradict the conditions of this License, they do not\nexcuse you from the conditions of this License.  If you cannot\ndistribute so as to satisfy simultaneously your obligations under this\nLicense and any other pertinent obligations, then as a consequence you\nmay not distribute the Program at all.  For example, if a patent\nlicense would not permit royalty-free redistribution of the Program by\nall those who receive copies directly or indirectly through you, then\nthe only way you could satisfy both it and this License would be to\nrefrain entirely from distribution of the Program.\n\nIf any portion of this section is held invalid or unenforceable under\nany particular circumstance, the balance of the section is intended to\napply and the section as a whole is intended to apply in other\ncircumstances.\n\nIt is not the purpose of this section to induce you to infringe any\npatents or other property right claims or to contest validity of any\nsuch claims; this section has the sole purpose of protecting the\nintegrity of the free software distribution system, which is\nimplemented by public license practices.  Many people have made\ngenerous contributions to the wide range of software distributed\nthrough that system in reliance on consistent application of that\nsystem; it is up to the author/donor to decide if he or she is willing\nto distribute software through any other system and a licensee cannot\nimpose that choice.\n\nThis section is intended to make thoroughly clear what is believed to\nbe a consequence of the rest of this License.\n\n  8. If the distribution and/or use of the Program is restricted in\ncertain countries either by patents or by copyrighted interfaces, the\noriginal copyright holder who places the Program under this License\nmay add an explicit geographical distribution limitation excluding\nthose countries, so that distribution is permitted only in or among\ncountries not thus excluded.  In such case, this License incorporates\nthe limitation as if written in the body of this License.\n\n  9. The Free Software Foundation may publish revised and/or new versions\nof the General Public License from time to time.  Such new versions will\nbe similar in spirit to the present version, but may differ in detail to\naddress new problems or concerns.\n\nEach version is given a distinguishing version number.  If the Program\nspecifies a version number of this License which applies to it and \"any\nlater version\", you have the option of following the terms and conditions\neither of that version or of any later version published by the Free\nSoftware Foundation.  If the Program does not specify a version number of\nthis License, you may choose any version ever published by the Free Software\nFoundation.\n\n  10. If you wish to incorporate parts of the Program into other free\nprograms whose distribution conditions are different, write to the author\nto ask for permission.  For software which is copyrighted by the Free\nSoftware Foundation, write to the Free Software Foundation; we sometimes\nmake exceptions for this.  Our decision will be guided by the two goals\nof preserving the free status of all derivatives of our free software and\nof promoting the sharing and reuse of software generally.\n\nNO WARRANTY\n-----------\n\n  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY\nFOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN\nOTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES\nPROVIDE THE PROGRAM \"AS IS\" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED\nOR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF\nMERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS\nTO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE\nPROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,\nREPAIR OR CORRECTION.\n\n  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING\nWILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR\nREDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,\nINCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING\nOUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED\nTO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY\nYOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER\nPROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE\nPOSSIBILITY OF SUCH DAMAGES.\n\n---------------------------\nEND OF TERMS AND CONDITIONS\";s:6:\"readme\";s:793:\"--------------------\nExtra: Ace\nGitHub: https://github.com/modx-pro/modx-ace\n--------------------\nSince: March 29th, 2012\nAuthor: Danil Kostin <danya.postfactum@gmail.com>\nLicense: GNU GPLv2 (or later at your option)\n\nIntegrates Ace Code Editor into MODX Revolution.\n\nBuilding the package\n-------------------\nRun _build/build.transport.php from the component root (e.g. in browser or CLI with MODX_BASE_PATH set). The script works with both MODX 2 and MODX 3. If you need to install the resulting package on MODX 2, you can either build from a MODX 2 installation (set MODX_BASE_PATH to your MODX 2 root) so the transport uses MODX 2 vehicle class names, or build from MODX 3 — the build script then patches the zip for MODX 2 compatibility.\n\nPress Ctrl+Alt+H to see all available shortcuts.\";s:9:\"changelog\";s:5822:\"# Changelog\n\nAll notable changes to this project will be documented in this file.\n\nThe format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),\nand this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).\n\n## [1.9.8] - 2026-03-05\n\n### Fixed\n- Fix fatal error when the resource does not exist\n ([#23](https://github.com/modx-pro/modx-ace/pull/23))\n\n## [1.9.7] - 2026-02-21\n\n### Fixed\n- Installation/upgrade failing with \"The location specified does not exist\" and \"Invalid or uninitialized Zip object\" when preserving existing files (e.g. on MODX 3, SiteDash): set PREEXISTING_MODE to REMOVE_PREEXISTING so .preserved.zip is not created ([#22](https://github.com/modx-pro/modx-ace/issues/22))\n\n## [1.9.6] - 2026-02-16\n\n### Added\n- Build script for MODX 2 and MODX 3 (Transport, auto-install, ClearCache)\n- Readable install log: [Ace] sections, ✓/✅ messages in resolver and build output\n- MODX root detection via `core/config/config.inc.php` when building from Extras/\n- Readme: building from MODX 2 for MODX 2 installs (optional; avoids post-pack patch)\n\n### Changed\n- PHP 8.1–8.5: null-safe array_merge, array key and file_get_contents handling in completions processors\n- Build config: 4-space indent, search order MODX_BASE_PATH → config.inc.php → modx.class.php\n- Resolver: PSR-12, structured log, recursive rmdir via closure\n- Package attributes and build output use [Ace] prefix and checkmarks\n\n### Fixed\n- Unable to load processor \"getResourceFields\" in MODX 3 (issue #16): processors path and CamelCase file names\n- Auto-install in MODX 3: full class name `MODX\\Revolution\\Transport\\modTransportPackage` for xPDO\n- E_DEPRECATED suppressed during CLI build (dynamic property in MODX core)\n- Package built on MODX 3 failing to install on MODX 2 (xPDOObjectVehicle could not be loaded): manifest vehicle class names patched to MODX 2 format (xpdo.transport.*) after pack; double-backslash and serialized manifest supported, array keys patched\n\n## [1.9.5] - 2025-10-18\n\n### Added\n- Format code by Ctrl-Shift-B\n\n## [1.9.4] - 2024-02-23\n\n### Added\n- Links on GitHub [#13]\n- Alt+z keyboard shortcut to toggle word wrap [#15]\n\n### Fixed\n- focus() triggering for undefined [#14]\n\n## [1.9.3] - 2022-05-15\n\n### Changed\n- Move settings into an own file [#12]\n\n### Fixed\n- Ace TV input [#11]\n- PHP warning: Undefined variable $field [#10]\n\n## [1.9.2] - 2022\n\n### Added\n- TV input Ace field [#9]\n\n### Changed\n- Corrected search form [#8]\n\n## [1.9.1]\n\n### Fixed\n- Changed fonts\n\n### Changed\n- emmet.js with the support flex css styles and many other combinations\n\n## [1.9.0]\n\n### Added\n- Autodetecting file mode by modelist.js [#7]\n- New modes from ace-builds for version 1.2.0\n\n## [1.8.0]\n\n### Added\n- Autocompletion for php functions\n\n## [1.7.0]\n\n### Added\n- System setting \"ace.grow\"\n- System setting \"ace.html_elements_mime\"\n\n## [1.6.5]\n\n### Added\n- \"Twig\" syntax for support of Twig in chunks\n\n### Changed\n- Plugin is not static anymore\n\n## [1.6.4]\n\n### Fixed\n- Support of emmet in smarty mode. Again.\n\n## [1.6.3]\n\n### Fixed\n- Support of emmet in smarty mode\n\n## [1.6.2]\n\n### Added\n- \"Markdown\" syntax for mime type \"text/x-markdown\"\n\n### Fixed\n- Editor mode handling\n\n## [1.6.1]\n\n### Fixed\n- Work with enabled system setting \"compress_js\"\n\n## [1.6.0]\n\n### Added\n- \"Smarty\" syntax for support of Fenom in chunks\n\n### Changed\n- Ace updated to version 1.2.0\n\n## [1.5.1]\n\n### Fixed\n- Bug with narrowing of the textarea\n\n## [1.5.0]\n\n### Added\n- Editor height setting\n\n### Changed\n- Assets moved back to /assets/\n\n### Fixed\n- MODx tag completions (was completely broken)\n\n## [1.4.3]\n\n### Added\n- MODx tag completions (Ctrl+Space)\n\n### Fixed\n- Issue caused AjaxManager (MODx Manager speed booster plugin) tree drag\'n\'drop bug\n\n## [1.4.2]\n\n### Added\n- Undo coalescing\n- Drag delay for Mac (allow to start new selection inside current one)\n\n### Changed\n- Mac fullscreen command bound to Command+F12\n\n### Fixed\n- Use file extension of static chunks to detect code syntax\n\n## [1.4.1]\n\n### Added\n- Expandable snippets support (see ace.snippets setting)\n- Emmet wrap_with_abbreviation command (Alt+W)\n\n### Fixed\n- Tab handling\n- Emmet shortcut listing by Ctrl+Alt+H\n\n## [1.4.0]\n\n### Added\n- Emmet (Zen Coding) support\n- Terminal dark theme\n- Hotkey table (Ctrl+Alt+H)\n\n### Changed\n- Assets moved to /manager/assets/components/\n\n### Fixed\n- Resource overview fatal error\n\n## [1.3.3]\n\n### Added\n- PHP live syntax check\n- Chaos dark theme\n- Setting show_invisibles\n\n## [1.3.2]\n\n### Added\n- Tab settings (tab size, soft tab)\n- Full compatibility with AjaxManager extra\n\n### Fixed\n- Bug while installing Ace\n- Broken word_wrap setting\n\n## [1.3.1]\n\n### Changed\n- Plugin content now stored in static file\n\n## [1.3.0]\n\n### Added\n- German translation\n- MODx tags highlighting\n- Ambiance and xcode themes\n- less/scss syntax highlighting\n- Fullwindow mode (Ctrl+F11)\n\n### Changed\n- Editor now ignores `wich_editor` setting. Set `use_editor` to false to use ACE for Resources.\n\n## [1.2.1]\n\n### Added\n- Font size setting\n- \"GitHub\" theme\n- Support of html5 drag\'n\'drop (accepting dropped text)\n- XML/HTML tag autoclosing\n\n### Changed\n- Assets moved to manager folder\n\n### Fixed\n- Broken en lexicon and PHP 5.3 incompatibility\n\n## [1.2.0]\n\n### Added\n- Add missing \"OnFileEditFormPrerender\" event to MODx\n- Multiline editing\n- Advanced find/replace window\n\n### Changed\n- Editor options moved to system settings\n- Removed some unnecessary options\n\n### Fixed\n- Multiple little editor bugs\n\n## [1.1.0]\n\n### Added\n- File edition support\n- MODx tree elements drag\'n\'drop support\n- Auto-assigning which_element_editor to Ace\n\n### Fixed\n- Fatal error on document create event\n- Changing of properties has no effect\n\n## [1.0.0]\n\n### Added\n- Plugin properties to adjust how Ace behaves\n- Initial release\n\";s:9:\"signature\";s:12:\"ace-1.9.8-pl\";s:6:\"action\";s:26:\"Workspace/Packages/Install\";s:8:\"register\";s:3:\"mgr\";s:5:\"topic\";s:40:\"/workspace/package/install/ace-1.9.8-pl/\";s:14:\"package_action\";i:0;}', 'Ace', 'a:38:{s:2:\"id\";s:36:\"a13a0608-557b-4260-b33a-16da7f3a5e08\";s:7:\"package\";s:36:\"9906673c-127f-4765-ad53-d741a99978c1\";s:12:\"display_name\";s:12:\"ace-1.9.8-pl\";s:4:\"name\";s:3:\"Ace\";s:7:\"version\";s:5:\"1.9.8\";s:13:\"version_major\";s:1:\"1\";s:13:\"version_minor\";s:1:\"9\";s:13:\"version_patch\";s:1:\"8\";s:7:\"release\";s:2:\"pl\";s:8:\"vrelease\";s:2:\"pl\";s:14:\"vrelease_index\";s:0:\"\";s:6:\"author\";s:16:\"danya_postfactum\";s:11:\"description\";s:1339:\"<p></p><p></p><p style=\"margin: 10px 0px 20px; padding: 0px; border-width: 0px; outline: 0px; font-size: 16px; vertical-align: baseline; background-color: rgb(255, 255, 255); line-height: 1.5; color: rgb(68, 68, 68); font-family: \'Helvetica Neue\', helvetica, arial, sans-serif; \">Ace (Ajax.org Cloud9 Editor) integration for MODx Revolution. Ace Provides best syntax highlighting and desktop-editors behavior (Sublime, Vim, Textmate) in your Elements, Files and Resources (when wysiwyg is disabled). It comes with 28 color schemes.</p><p style=\"margin: 10px 0px 20px; padding: 0px; border-width: 0px; outline: 0px; font-size: 16px; vertical-align: baseline; background-color: rgb(255, 255, 255); line-height: 1.5; color: rgb(68, 68, 68); font-family: \'Helvetica Neue\', helvetica, arial, sans-serif; \">This editor is used in GitHub, Cloud9 IDE, Acebug and other projects.</p><p></p><p>For now the editor supports drag\'n\'drop of chunks, snippets, resources and files from MODx Tree.</p><p>This project is hosted on github <a href=\"http://github.com/danyaPostfactum/modx-ace\" title=\"\" target=\"\">here</a>. Please feel free to leave comments/suggestions.</p><p><a href=\"http://forums.modx.com/thread/81257/ace-code-editor-for-modx-revolution---support-thread\" title=\"\" target=\"\">Here</a> is the support forum thread for Ace.</p><p></p><p></p>\";s:12:\"instructions\";s:341:\"<p></p><p>Install via Package Management.</p><p>Set editor theme you wish in system settings (change namespace to \"ace\").</p><p>If you want to use this editor for resources, just set system option <i>use_editor</i> to <b>false</b> (global usage), or <i>richtext</i> setting of certain resource to <b>false</b> (specific usage).</p><p></p>\";s:9:\"changelog\";s:5822:\"# Changelog\n\nAll notable changes to this project will be documented in this file.\n\nThe format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),\nand this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).\n\n## [1.9.8] - 2026-03-05\n\n### Fixed\n- Fix fatal error when the resource does not exist\n ([#23](https://github.com/modx-pro/modx-ace/pull/23))\n\n## [1.9.7] - 2026-02-21\n\n### Fixed\n- Installation/upgrade failing with \"The location specified does not exist\" and \"Invalid or uninitialized Zip object\" when preserving existing files (e.g. on MODX 3, SiteDash): set PREEXISTING_MODE to REMOVE_PREEXISTING so .preserved.zip is not created ([#22](https://github.com/modx-pro/modx-ace/issues/22))\n\n## [1.9.6] - 2026-02-16\n\n### Added\n- Build script for MODX 2 and MODX 3 (Transport, auto-install, ClearCache)\n- Readable install log: [Ace] sections, ✓/✅ messages in resolver and build output\n- MODX root detection via `core/config/config.inc.php` when building from Extras/\n- Readme: building from MODX 2 for MODX 2 installs (optional; avoids post-pack patch)\n\n### Changed\n- PHP 8.1–8.5: null-safe array_merge, array key and file_get_contents handling in completions processors\n- Build config: 4-space indent, search order MODX_BASE_PATH → config.inc.php → modx.class.php\n- Resolver: PSR-12, structured log, recursive rmdir via closure\n- Package attributes and build output use [Ace] prefix and checkmarks\n\n### Fixed\n- Unable to load processor \"getResourceFields\" in MODX 3 (issue #16): processors path and CamelCase file names\n- Auto-install in MODX 3: full class name `MODX\\Revolution\\Transport\\modTransportPackage` for xPDO\n- E_DEPRECATED suppressed during CLI build (dynamic property in MODX core)\n- Package built on MODX 3 failing to install on MODX 2 (xPDOObjectVehicle could not be loaded): manifest vehicle class names patched to MODX 2 format (xpdo.transport.*) after pack; double-backslash and serialized manifest supported, array keys patched\n\n## [1.9.5] - 2025-10-18\n\n### Added\n- Format code by Ctrl-Shift-B\n\n## [1.9.4] - 2024-02-23\n\n### Added\n- Links on GitHub [#13]\n- Alt+z keyboard shortcut to toggle word wrap [#15]\n\n### Fixed\n- focus() triggering for undefined [#14]\n\n## [1.9.3] - 2022-05-15\n\n### Changed\n- Move settings into an own file [#12]\n\n### Fixed\n- Ace TV input [#11]\n- PHP warning: Undefined variable $field [#10]\n\n## [1.9.2] - 2022\n\n### Added\n- TV input Ace field [#9]\n\n### Changed\n- Corrected search form [#8]\n\n## [1.9.1]\n\n### Fixed\n- Changed fonts\n\n### Changed\n- emmet.js with the support flex css styles and many other combinations\n\n## [1.9.0]\n\n### Added\n- Autodetecting file mode by modelist.js [#7]\n- New modes from ace-builds for version 1.2.0\n\n## [1.8.0]\n\n### Added\n- Autocompletion for php functions\n\n## [1.7.0]\n\n### Added\n- System setting \"ace.grow\"\n- System setting \"ace.html_elements_mime\"\n\n## [1.6.5]\n\n### Added\n- \"Twig\" syntax for support of Twig in chunks\n\n### Changed\n- Plugin is not static anymore\n\n## [1.6.4]\n\n### Fixed\n- Support of emmet in smarty mode. Again.\n\n## [1.6.3]\n\n### Fixed\n- Support of emmet in smarty mode\n\n## [1.6.2]\n\n### Added\n- \"Markdown\" syntax for mime type \"text/x-markdown\"\n\n### Fixed\n- Editor mode handling\n\n## [1.6.1]\n\n### Fixed\n- Work with enabled system setting \"compress_js\"\n\n## [1.6.0]\n\n### Added\n- \"Smarty\" syntax for support of Fenom in chunks\n\n### Changed\n- Ace updated to version 1.2.0\n\n## [1.5.1]\n\n### Fixed\n- Bug with narrowing of the textarea\n\n## [1.5.0]\n\n### Added\n- Editor height setting\n\n### Changed\n- Assets moved back to /assets/\n\n### Fixed\n- MODx tag completions (was completely broken)\n\n## [1.4.3]\n\n### Added\n- MODx tag completions (Ctrl+Space)\n\n### Fixed\n- Issue caused AjaxManager (MODx Manager speed booster plugin) tree drag\'n\'drop bug\n\n## [1.4.2]\n\n### Added\n- Undo coalescing\n- Drag delay for Mac (allow to start new selection inside current one)\n\n### Changed\n- Mac fullscreen command bound to Command+F12\n\n### Fixed\n- Use file extension of static chunks to detect code syntax\n\n## [1.4.1]\n\n### Added\n- Expandable snippets support (see ace.snippets setting)\n- Emmet wrap_with_abbreviation command (Alt+W)\n\n### Fixed\n- Tab handling\n- Emmet shortcut listing by Ctrl+Alt+H\n\n## [1.4.0]\n\n### Added\n- Emmet (Zen Coding) support\n- Terminal dark theme\n- Hotkey table (Ctrl+Alt+H)\n\n### Changed\n- Assets moved to /manager/assets/components/\n\n### Fixed\n- Resource overview fatal error\n\n## [1.3.3]\n\n### Added\n- PHP live syntax check\n- Chaos dark theme\n- Setting show_invisibles\n\n## [1.3.2]\n\n### Added\n- Tab settings (tab size, soft tab)\n- Full compatibility with AjaxManager extra\n\n### Fixed\n- Bug while installing Ace\n- Broken word_wrap setting\n\n## [1.3.1]\n\n### Changed\n- Plugin content now stored in static file\n\n## [1.3.0]\n\n### Added\n- German translation\n- MODx tags highlighting\n- Ambiance and xcode themes\n- less/scss syntax highlighting\n- Fullwindow mode (Ctrl+F11)\n\n### Changed\n- Editor now ignores `wich_editor` setting. Set `use_editor` to false to use ACE for Resources.\n\n## [1.2.1]\n\n### Added\n- Font size setting\n- \"GitHub\" theme\n- Support of html5 drag\'n\'drop (accepting dropped text)\n- XML/HTML tag autoclosing\n\n### Changed\n- Assets moved to manager folder\n\n### Fixed\n- Broken en lexicon and PHP 5.3 incompatibility\n\n## [1.2.0]\n\n### Added\n- Add missing \"OnFileEditFormPrerender\" event to MODx\n- Multiline editing\n- Advanced find/replace window\n\n### Changed\n- Editor options moved to system settings\n- Removed some unnecessary options\n\n### Fixed\n- Multiple little editor bugs\n\n## [1.1.0]\n\n### Added\n- File edition support\n- MODx tree elements drag\'n\'drop support\n- Auto-assigning which_element_editor to Ace\n\n### Fixed\n- Fatal error on document create event\n- Changing of properties has no effect\n\n## [1.0.0]\n\n### Added\n- Plugin properties to adjust how Ace behaves\n- Initial release\n\";s:9:\"createdon\";s:25:\"2026-03-05T10:16:53+00:00\";s:9:\"createdby\";s:10:\"ibochkarev\";s:8:\"editedon\";s:25:\"2026-03-17T08:52:03+00:00\";s:10:\"releasedon\";s:25:\"2026-03-17T08:52:03+00:00\";s:9:\"downloads\";s:6:\"376679\";s:8:\"approved\";s:4:\"true\";s:7:\"audited\";s:4:\"true\";s:8:\"featured\";s:5:\"false\";s:10:\"deprecated\";s:5:\"false\";s:7:\"license\";s:5:\"GPLv2\";s:7:\"smf_url\";s:0:\"\";s:10:\"repository\";s:36:\"9861b09b-7176-455b-a9c1-bb7728924ad8\";s:8:\"supports\";s:3:\"2.0\";s:8:\"location\";s:120:\"https://rest.modx.com/extras/download/?id=a13a0608-557b-4260-b33a-16da7f3a5e08&uuid=60f6e113-c851-4e1d-8285-6d5bd95cec78\";s:9:\"signature\";s:12:\"ace-1.9.8-pl\";s:11:\"supports_db\";s:0:\"\";s:16:\"minimum_supports\";s:3:\"2.0\";s:9:\"breaks_at\";s:5:\"100.0\";s:10:\"screenshot\";s:0:\"\";s:4:\"file\";a:7:{s:2:\"id\";s:36:\"a13a0608-557b-4260-b33a-16da7f3a5e08\";s:7:\"version\";s:36:\"a13a0608-557b-4260-b33a-16da7f3a5e08\";s:8:\"filename\";s:26:\"ace-1.9.8-pl.transport.zip\";s:9:\"downloads\";s:4:\"4238\";s:6:\"lastip\";s:0:\"\";s:9:\"transport\";s:4:\"true\";s:8:\"location\";s:120:\"https://rest.modx.com/extras/download/?id=a13a0608-557b-4260-b33a-16da7f3a5e08&uuid=60f6e113-c851-4e1d-8285-6d5bd95cec78\";}s:17:\"package-signature\";s:12:\"ace-1.9.8-pl\";s:10:\"categories\";s:15:\"richtexteditors\";s:4:\"tags\";s:0:\"\";}', 1, 9, 8, 'pl', 0);

-- --------------------------------------------------------

--
-- Table structure for table `modx_transport_providers`
--

CREATE TABLE `modx_transport_providers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` mediumtext,
  `service_url` tinytext,
  `username` varchar(191) NOT NULL DEFAULT '',
  `api_key` varchar(191) NOT NULL DEFAULT '',
  `created` datetime NOT NULL,
  `updated` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `priority` tinyint(4) NOT NULL DEFAULT '10',
  `properties` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_transport_providers`
--

INSERT INTO `modx_transport_providers` (`id`, `name`, `description`, `service_url`, `username`, `api_key`, `created`, `updated`, `active`, `priority`, `properties`) VALUES
(1, 'modx.com', 'The official MODX transport provider for 3rd party components.', 'https://rest.modx.com/extras/', '', '', '2026-05-13 09:35:48', NULL, 1, 10, '');

-- --------------------------------------------------------

--
-- Table structure for table `modx_users`
--

CREATE TABLE `modx_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `cachepwd` varchar(255) NOT NULL DEFAULT '',
  `class_key` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\modUser',
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '1',
  `remote_key` varchar(191) DEFAULT NULL,
  `remote_data` text,
  `hash_class` varchar(100) NOT NULL DEFAULT 'MODX\\Revolution\\Hashing\\modNative',
  `salt` varchar(100) NOT NULL DEFAULT '',
  `primary_group` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `session_stale` text,
  `sudo` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `createdon` int(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_users`
--

INSERT INTO `modx_users` (`id`, `username`, `password`, `cachepwd`, `class_key`, `active`, `remote_key`, `remote_data`, `hash_class`, `salt`, `primary_group`, `session_stale`, `sudo`, `createdon`) VALUES
(1, 'masterkadaj', '$2y$10$oAd49GyeIkC1aOLNT4EHJOodoNU/TVhmfh9edYh.SWHwuW13o1HPO', '', 'MODX\\Revolution\\modUser', 1, NULL, NULL, 'MODX\\Revolution\\Hashing\\modNative', '004ccb3cd33597e599b97bc0689fb7ea', 1, NULL, 1, 1780900134);

-- --------------------------------------------------------

--
-- Table structure for table `modx_user_attributes`
--

CREATE TABLE `modx_user_attributes` (
  `id` int(10) UNSIGNED NOT NULL,
  `internalKey` int(10) UNSIGNED NOT NULL,
  `fullname` varchar(100) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `phone` varchar(100) NOT NULL DEFAULT '',
  `mobilephone` varchar(100) NOT NULL DEFAULT '',
  `blocked` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `blockeduntil` int(11) NOT NULL DEFAULT '0',
  `blockedafter` int(11) NOT NULL DEFAULT '0',
  `logincount` int(11) NOT NULL DEFAULT '0',
  `lastlogin` int(11) NOT NULL DEFAULT '0',
  `thislogin` int(11) NOT NULL DEFAULT '0',
  `failedlogincount` int(10) NOT NULL DEFAULT '0',
  `sessionid` varchar(100) NOT NULL DEFAULT '',
  `dob` int(10) NOT NULL DEFAULT '0',
  `gender` tinyint(1) NOT NULL DEFAULT '0',
  `address` text NOT NULL,
  `country` varchar(255) NOT NULL DEFAULT '',
  `city` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(25) NOT NULL DEFAULT '',
  `zip` varchar(25) NOT NULL DEFAULT '',
  `fax` varchar(100) NOT NULL DEFAULT '',
  `photo` varchar(255) NOT NULL DEFAULT '',
  `comment` text NOT NULL,
  `website` varchar(255) NOT NULL DEFAULT '',
  `extended` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_user_attributes`
--

INSERT INTO `modx_user_attributes` (`id`, `internalKey`, `fullname`, `email`, `phone`, `mobilephone`, `blocked`, `blockeduntil`, `blockedafter`, `logincount`, `lastlogin`, `thislogin`, `failedlogincount`, `sessionid`, `dob`, `gender`, `address`, `country`, `city`, `state`, `zip`, `fax`, `photo`, `comment`, `website`, `extended`) VALUES
(1, 1, 'Администратор по умолчанию', 'masterkadaj@gmail.com', '', '', 0, 0, 0, 1, 0, 1780900174, 0, '', 0, 0, '', '', '', '', '', '', '', '', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `modx_user_group_roles`
--

CREATE TABLE `modx_user_group_roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` mediumtext,
  `authority` int(10) UNSIGNED NOT NULL DEFAULT '9999'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_user_group_roles`
--

INSERT INTO `modx_user_group_roles` (`id`, `name`, `description`, `authority`) VALUES
(1, 'Member', NULL, 9999),
(2, 'Super User', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `modx_user_group_settings`
--

CREATE TABLE `modx_user_group_settings` (
  `group` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `key` varchar(50) NOT NULL,
  `value` text,
  `xtype` varchar(75) NOT NULL DEFAULT 'textfield',
  `namespace` varchar(40) NOT NULL DEFAULT 'core',
  `area` varchar(255) NOT NULL DEFAULT '',
  `editedon` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_user_messages`
--

CREATE TABLE `modx_user_messages` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(15) NOT NULL DEFAULT '',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` text NOT NULL,
  `sender` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `recipient` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `private` tinyint(4) NOT NULL DEFAULT '0',
  `date_sent` datetime DEFAULT NULL,
  `read` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_user_settings`
--

CREATE TABLE `modx_user_settings` (
  `user` int(11) UNSIGNED NOT NULL DEFAULT '0',
  `key` varchar(50) NOT NULL DEFAULT '',
  `value` text,
  `xtype` varchar(75) NOT NULL DEFAULT 'textfield',
  `namespace` varchar(40) NOT NULL DEFAULT 'core',
  `area` varchar(255) NOT NULL DEFAULT '',
  `editedon` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `modx_workspaces`
--

CREATE TABLE `modx_workspaces` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL DEFAULT '',
  `path` varchar(191) NOT NULL DEFAULT '',
  `created` datetime NOT NULL,
  `active` tinyint(1) UNSIGNED NOT NULL DEFAULT '0',
  `attributes` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `modx_workspaces`
--

INSERT INTO `modx_workspaces` (`id`, `name`, `path`, `created`, `active`, `attributes`) VALUES
(1, 'Default MODX workspace', '{core_path}', '2026-06-08 09:28:25', 1, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `modx_access_actiondom`
--
ALTER TABLE `modx_access_actiondom`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`);

--
-- Indexes for table `modx_access_category`
--
ALTER TABLE `modx_access_category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`),
  ADD KEY `context_key` (`context_key`);

--
-- Indexes for table `modx_access_context`
--
ALTER TABLE `modx_access_context`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`);

--
-- Indexes for table `modx_access_elements`
--
ALTER TABLE `modx_access_elements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`),
  ADD KEY `context_key` (`context_key`);

--
-- Indexes for table `modx_access_media_source`
--
ALTER TABLE `modx_access_media_source`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`),
  ADD KEY `context_key` (`context_key`);

--
-- Indexes for table `modx_access_menus`
--
ALTER TABLE `modx_access_menus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`);

--
-- Indexes for table `modx_access_namespace`
--
ALTER TABLE `modx_access_namespace`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`),
  ADD KEY `context_key` (`context_key`);

--
-- Indexes for table `modx_access_permissions`
--
ALTER TABLE `modx_access_permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `template` (`template`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `modx_access_policies`
--
ALTER TABLE `modx_access_policies`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `parent` (`parent`),
  ADD KEY `class` (`class`),
  ADD KEY `template` (`template`);

--
-- Indexes for table `modx_access_policy_templates`
--
ALTER TABLE `modx_access_policy_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `modx_access_policy_template_groups`
--
ALTER TABLE `modx_access_policy_template_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `modx_access_resources`
--
ALTER TABLE `modx_access_resources`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`),
  ADD KEY `context_key` (`context_key`);

--
-- Indexes for table `modx_access_resource_groups`
--
ALTER TABLE `modx_access_resource_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`,`target`,`principal`,`authority`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`),
  ADD KEY `context_key` (`context_key`);

--
-- Indexes for table `modx_access_templatevars`
--
ALTER TABLE `modx_access_templatevars`
  ADD PRIMARY KEY (`id`),
  ADD KEY `target` (`target`),
  ADD KEY `principal_class` (`principal_class`),
  ADD KEY `principal` (`principal`),
  ADD KEY `authority` (`authority`),
  ADD KEY `policy` (`policy`),
  ADD KEY `context_key` (`context_key`);

--
-- Indexes for table `modx_actiondom`
--
ALTER TABLE `modx_actiondom`
  ADD PRIMARY KEY (`id`),
  ADD KEY `set` (`set`),
  ADD KEY `action` (`action`),
  ADD KEY `name` (`name`),
  ADD KEY `active` (`active`),
  ADD KEY `for_parent` (`for_parent`),
  ADD KEY `rank` (`rank`);

--
-- Indexes for table `modx_actions_fields`
--
ALTER TABLE `modx_actions_fields`
  ADD PRIMARY KEY (`id`),
  ADD KEY `action` (`action`),
  ADD KEY `type` (`type`),
  ADD KEY `tab` (`tab`);

--
-- Indexes for table `modx_active_users`
--
ALTER TABLE `modx_active_users`
  ADD PRIMARY KEY (`internalKey`);

--
-- Indexes for table `modx_categories`
--
ALTER TABLE `modx_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `category` (`parent`,`category`),
  ADD KEY `parent` (`parent`),
  ADD KEY `rank` (`rank`);

--
-- Indexes for table `modx_categories_closure`
--
ALTER TABLE `modx_categories_closure`
  ADD PRIMARY KEY (`ancestor`,`descendant`);

--
-- Indexes for table `modx_content_type`
--
ALTER TABLE `modx_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `modx_context`
--
ALTER TABLE `modx_context`
  ADD PRIMARY KEY (`key`),
  ADD KEY `name` (`name`),
  ADD KEY `rank` (`rank`);

--
-- Indexes for table `modx_context_resource`
--
ALTER TABLE `modx_context_resource`
  ADD PRIMARY KEY (`context_key`,`resource`);

--
-- Indexes for table `modx_context_setting`
--
ALTER TABLE `modx_context_setting`
  ADD PRIMARY KEY (`context_key`,`key`);

--
-- Indexes for table `modx_dashboard`
--
ALTER TABLE `modx_dashboard`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `hide_trees` (`hide_trees`);

--
-- Indexes for table `modx_dashboard_widget`
--
ALTER TABLE `modx_dashboard_widget`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `type` (`type`),
  ADD KEY `namespace` (`namespace`),
  ADD KEY `lexicon` (`lexicon`);

--
-- Indexes for table `modx_dashboard_widget_placement`
--
ALTER TABLE `modx_dashboard_widget_placement`
  ADD PRIMARY KEY (`user`,`dashboard`,`widget`),
  ADD KEY `rank` (`rank`);

--
-- Indexes for table `modx_deprecated_call`
--
ALTER TABLE `modx_deprecated_call`
  ADD PRIMARY KEY (`id`),
  ADD KEY `method` (`method`),
  ADD KEY `call_count` (`call_count`),
  ADD KEY `caller` (`caller`),
  ADD KEY `caller_file` (`caller_file`),
  ADD KEY `caller_line` (`caller_line`);

--
-- Indexes for table `modx_deprecated_method`
--
ALTER TABLE `modx_deprecated_method`
  ADD PRIMARY KEY (`id`),
  ADD KEY `definition` (`definition`);

--
-- Indexes for table `modx_documentgroup_names`
--
ALTER TABLE `modx_documentgroup_names`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `modx_document_groups`
--
ALTER TABLE `modx_document_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `document_group` (`document_group`),
  ADD KEY `document` (`document`);

--
-- Indexes for table `modx_element_property_sets`
--
ALTER TABLE `modx_element_property_sets`
  ADD PRIMARY KEY (`element`,`element_class`,`property_set`);

--
-- Indexes for table `modx_extension_packages`
--
ALTER TABLE `modx_extension_packages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `namespace` (`namespace`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `modx_fc_profiles`
--
ALTER TABLE `modx_fc_profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `rank` (`rank`),
  ADD KEY `active` (`active`);

--
-- Indexes for table `modx_fc_profiles_usergroups`
--
ALTER TABLE `modx_fc_profiles_usergroups`
  ADD PRIMARY KEY (`usergroup`,`profile`);

--
-- Indexes for table `modx_fc_sets`
--
ALTER TABLE `modx_fc_sets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `profile` (`profile`),
  ADD KEY `action` (`action`),
  ADD KEY `active` (`active`),
  ADD KEY `template` (`template`);

--
-- Indexes for table `modx_lexicon_entries`
--
ALTER TABLE `modx_lexicon_entries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `topic` (`topic`),
  ADD KEY `namespace` (`namespace`),
  ADD KEY `language` (`language`);

--
-- Indexes for table `modx_manager_log`
--
ALTER TABLE `modx_manager_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_occurred` (`user`,`occurred`);

--
-- Indexes for table `modx_media_sources`
--
ALTER TABLE `modx_media_sources`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`),
  ADD KEY `class_key` (`class_key`),
  ADD KEY `is_stream` (`is_stream`);

--
-- Indexes for table `modx_media_sources_contexts`
--
ALTER TABLE `modx_media_sources_contexts`
  ADD PRIMARY KEY (`source`,`context_key`);

--
-- Indexes for table `modx_media_sources_elements`
--
ALTER TABLE `modx_media_sources_elements`
  ADD PRIMARY KEY (`source`,`object`,`object_class`,`context_key`);

--
-- Indexes for table `modx_membergroup_names`
--
ALTER TABLE `modx_membergroup_names`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `parent` (`parent`),
  ADD KEY `rank` (`rank`),
  ADD KEY `dashboard` (`dashboard`);

--
-- Indexes for table `modx_member_groups`
--
ALTER TABLE `modx_member_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role` (`role`),
  ADD KEY `rank` (`rank`);

--
-- Indexes for table `modx_menus`
--
ALTER TABLE `modx_menus`
  ADD PRIMARY KEY (`text`),
  ADD KEY `parent` (`parent`),
  ADD KEY `action` (`action`),
  ADD KEY `namespace` (`namespace`);

--
-- Indexes for table `modx_namespaces`
--
ALTER TABLE `modx_namespaces`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `modx_property_set`
--
ALTER TABLE `modx_property_set`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `category` (`category`);

--
-- Indexes for table `modx_register_messages`
--
ALTER TABLE `modx_register_messages`
  ADD PRIMARY KEY (`topic`,`id`),
  ADD KEY `created` (`created`),
  ADD KEY `valid` (`valid`),
  ADD KEY `accessed` (`accessed`),
  ADD KEY `accesses` (`accesses`),
  ADD KEY `expires` (`expires`);

--
-- Indexes for table `modx_register_queues`
--
ALTER TABLE `modx_register_queues`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `modx_register_topics`
--
ALTER TABLE `modx_register_topics`
  ADD PRIMARY KEY (`id`),
  ADD KEY `queue` (`queue`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `modx_session`
--
ALTER TABLE `modx_session`
  ADD PRIMARY KEY (`id`),
  ADD KEY `access` (`access`);

--
-- Indexes for table `modx_site_content`
--
ALTER TABLE `modx_site_content`
  ADD PRIMARY KEY (`id`),
  ADD KEY `alias` (`alias`),
  ADD KEY `published` (`published`),
  ADD KEY `pub_date` (`pub_date`),
  ADD KEY `unpub_date` (`unpub_date`),
  ADD KEY `parent` (`parent`),
  ADD KEY `isfolder` (`isfolder`),
  ADD KEY `template` (`template`),
  ADD KEY `menuindex` (`menuindex`),
  ADD KEY `searchable` (`searchable`),
  ADD KEY `cacheable` (`cacheable`),
  ADD KEY `hidemenu` (`hidemenu`),
  ADD KEY `class_key` (`class_key`),
  ADD KEY `context_key` (`context_key`),
  ADD KEY `uri` (`uri`(191)),
  ADD KEY `uri_override` (`uri_override`),
  ADD KEY `hide_children_in_tree` (`hide_children_in_tree`),
  ADD KEY `show_in_tree` (`show_in_tree`),
  ADD KEY `cache_refresh_idx` (`parent`,`menuindex`,`id`);
ALTER TABLE `modx_site_content` ADD FULLTEXT KEY `content_ft_idx` (`pagetitle`,`longtitle`,`description`,`introtext`,`content`);

--
-- Indexes for table `modx_site_htmlsnippets`
--
ALTER TABLE `modx_site_htmlsnippets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `category` (`category`),
  ADD KEY `locked` (`locked`),
  ADD KEY `static` (`static`);

--
-- Indexes for table `modx_site_plugins`
--
ALTER TABLE `modx_site_plugins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `category` (`category`),
  ADD KEY `locked` (`locked`),
  ADD KEY `disabled` (`disabled`),
  ADD KEY `static` (`static`);

--
-- Indexes for table `modx_site_plugin_events`
--
ALTER TABLE `modx_site_plugin_events`
  ADD PRIMARY KEY (`pluginid`,`event`),
  ADD KEY `priority` (`priority`);

--
-- Indexes for table `modx_site_snippets`
--
ALTER TABLE `modx_site_snippets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `category` (`category`),
  ADD KEY `locked` (`locked`),
  ADD KEY `moduleguid` (`moduleguid`),
  ADD KEY `static` (`static`);

--
-- Indexes for table `modx_site_templates`
--
ALTER TABLE `modx_site_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `templatename` (`templatename`),
  ADD KEY `category` (`category`),
  ADD KEY `locked` (`locked`),
  ADD KEY `static` (`static`);

--
-- Indexes for table `modx_site_tmplvars`
--
ALTER TABLE `modx_site_tmplvars`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `category` (`category`),
  ADD KEY `locked` (`locked`),
  ADD KEY `rank` (`rank`),
  ADD KEY `static` (`static`);

--
-- Indexes for table `modx_site_tmplvar_access`
--
ALTER TABLE `modx_site_tmplvar_access`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tmplvar_template` (`tmplvarid`,`documentgroup`);

--
-- Indexes for table `modx_site_tmplvar_contentvalues`
--
ALTER TABLE `modx_site_tmplvar_contentvalues`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tv_cnt` (`tmplvarid`,`contentid`),
  ADD KEY `tmplvarid` (`tmplvarid`),
  ADD KEY `contentid` (`contentid`);

--
-- Indexes for table `modx_site_tmplvar_templates`
--
ALTER TABLE `modx_site_tmplvar_templates`
  ADD PRIMARY KEY (`tmplvarid`,`templateid`);

--
-- Indexes for table `modx_system_eventnames`
--
ALTER TABLE `modx_system_eventnames`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `modx_system_settings`
--
ALTER TABLE `modx_system_settings`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `modx_transport_packages`
--
ALTER TABLE `modx_transport_packages`
  ADD PRIMARY KEY (`signature`),
  ADD KEY `workspace` (`workspace`),
  ADD KEY `provider` (`provider`),
  ADD KEY `disabled` (`disabled`),
  ADD KEY `package_name` (`package_name`),
  ADD KEY `version_major` (`version_major`),
  ADD KEY `version_minor` (`version_minor`),
  ADD KEY `version_patch` (`version_patch`),
  ADD KEY `release` (`release`),
  ADD KEY `release_index` (`release_index`);

--
-- Indexes for table `modx_transport_providers`
--
ALTER TABLE `modx_transport_providers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `api_key` (`api_key`),
  ADD KEY `username` (`username`),
  ADD KEY `active` (`active`),
  ADD KEY `priority` (`priority`);

--
-- Indexes for table `modx_users`
--
ALTER TABLE `modx_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `class_key` (`class_key`),
  ADD KEY `remote_key` (`remote_key`),
  ADD KEY `primary_group` (`primary_group`);

--
-- Indexes for table `modx_user_attributes`
--
ALTER TABLE `modx_user_attributes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `internalKey` (`internalKey`);

--
-- Indexes for table `modx_user_group_roles`
--
ALTER TABLE `modx_user_group_roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `authority` (`authority`);

--
-- Indexes for table `modx_user_group_settings`
--
ALTER TABLE `modx_user_group_settings`
  ADD PRIMARY KEY (`group`,`key`);

--
-- Indexes for table `modx_user_messages`
--
ALTER TABLE `modx_user_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `modx_user_settings`
--
ALTER TABLE `modx_user_settings`
  ADD PRIMARY KEY (`user`,`key`);

--
-- Indexes for table `modx_workspaces`
--
ALTER TABLE `modx_workspaces`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `path` (`path`),
  ADD KEY `name` (`name`),
  ADD KEY `active` (`active`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `modx_access_actiondom`
--
ALTER TABLE `modx_access_actiondom`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_access_category`
--
ALTER TABLE `modx_access_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_access_context`
--
ALTER TABLE `modx_access_context`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `modx_access_elements`
--
ALTER TABLE `modx_access_elements`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_access_media_source`
--
ALTER TABLE `modx_access_media_source`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_access_menus`
--
ALTER TABLE `modx_access_menus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_access_namespace`
--
ALTER TABLE `modx_access_namespace`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_access_permissions`
--
ALTER TABLE `modx_access_permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=229;

--
-- AUTO_INCREMENT for table `modx_access_policies`
--
ALTER TABLE `modx_access_policies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `modx_access_policy_templates`
--
ALTER TABLE `modx_access_policy_templates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `modx_access_policy_template_groups`
--
ALTER TABLE `modx_access_policy_template_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `modx_access_resources`
--
ALTER TABLE `modx_access_resources`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_access_resource_groups`
--
ALTER TABLE `modx_access_resource_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_access_templatevars`
--
ALTER TABLE `modx_access_templatevars`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_actiondom`
--
ALTER TABLE `modx_actiondom`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_actions_fields`
--
ALTER TABLE `modx_actions_fields`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `modx_categories`
--
ALTER TABLE `modx_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_content_type`
--
ALTER TABLE `modx_content_type`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `modx_dashboard`
--
ALTER TABLE `modx_dashboard`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modx_dashboard_widget`
--
ALTER TABLE `modx_dashboard_widget`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `modx_deprecated_call`
--
ALTER TABLE `modx_deprecated_call`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `modx_deprecated_method`
--
ALTER TABLE `modx_deprecated_method`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `modx_documentgroup_names`
--
ALTER TABLE `modx_documentgroup_names`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_document_groups`
--
ALTER TABLE `modx_document_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_extension_packages`
--
ALTER TABLE `modx_extension_packages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_fc_profiles`
--
ALTER TABLE `modx_fc_profiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_fc_sets`
--
ALTER TABLE `modx_fc_sets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_lexicon_entries`
--
ALTER TABLE `modx_lexicon_entries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_manager_log`
--
ALTER TABLE `modx_manager_log`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `modx_media_sources`
--
ALTER TABLE `modx_media_sources`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modx_membergroup_names`
--
ALTER TABLE `modx_membergroup_names`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modx_member_groups`
--
ALTER TABLE `modx_member_groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modx_property_set`
--
ALTER TABLE `modx_property_set`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_register_queues`
--
ALTER TABLE `modx_register_queues`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modx_register_topics`
--
ALTER TABLE `modx_register_topics`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modx_site_content`
--
ALTER TABLE `modx_site_content`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modx_site_htmlsnippets`
--
ALTER TABLE `modx_site_htmlsnippets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `modx_site_plugins`
--
ALTER TABLE `modx_site_plugins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modx_site_snippets`
--
ALTER TABLE `modx_site_snippets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_site_templates`
--
ALTER TABLE `modx_site_templates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modx_site_tmplvars`
--
ALTER TABLE `modx_site_tmplvars`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_site_tmplvar_access`
--
ALTER TABLE `modx_site_tmplvar_access`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_site_tmplvar_contentvalues`
--
ALTER TABLE `modx_site_tmplvar_contentvalues`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_transport_providers`
--
ALTER TABLE `modx_transport_providers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modx_users`
--
ALTER TABLE `modx_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modx_user_attributes`
--
ALTER TABLE `modx_user_attributes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `modx_user_group_roles`
--
ALTER TABLE `modx_user_group_roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `modx_user_messages`
--
ALTER TABLE `modx_user_messages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `modx_workspaces`
--
ALTER TABLE `modx_workspaces`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
